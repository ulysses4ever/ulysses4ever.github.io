/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Textgraphic2.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:51 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import java.util.Iterator;
import java.util.Collection;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Document;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.OpenDocumentFactory;
import org.openoffice.odf.schema.Namespaces;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.Element;

import org.openoffice.odf.graphics.*;

import org.openoffice.odf.text.List;
import org.openoffice.odf.text.ListItem;
import org.openoffice.odf.text.Paragraph;



import junit.framework.TestCase;
/**
 *
 * @author duyunfen
 */
public class Textgraphic2 extends TestCase{
    
    private GraphicsDocument doc = null;
    private OdfPackage odfPackage = null;
    private String path = "c:/t0.odg";
    /** Creates a new instance of Textgraphic2 */
    public Textgraphic2(String testname) {
        super(testname);
    }
    
    protected void setUp() throws Exception {
        System.out.println("setup");
        try{
            odfPackage = OpenDocumentFactory.load(path);
            doc  = (GraphicsDocument)odfPackage;
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }

    protected void tearDown() throws Exception {
        odfPackage.close();
    }     
    
    public void testNewGraphicList(){
        try{
            Body body = doc.getBody();
            Iterator iterator = body.iterator();
            while(iterator.hasNext()){
                Element e = (Element)iterator.next();
                if (e instanceof Page) {
                    Page p = (Page)e;        
                    if(p.getPageName().equals("page1")){
                        Page p2 = new Page(doc);
                        p2.setPageName("p2");
                        body.add(p2);
                        Line line = new Line(doc);
                        p2.add(line);

                        List l1 = new List(doc,
                            new ListItem(doc, "list item 1"),
                            new ListItem(doc, "list item 2"),
                            new ListItem(doc, "list item 3"),
                            new ListItem(doc, "list item 4"));

                        line.add(l1);
                        break;
                    }
                }
            }
         doc.save(path);            
        }catch(IOException ex){
             ex.printStackTrace();
        }
    }
    
    public void testNewGraphicParagraph(){
        try{
            Body body = doc.getBody();
            Iterator iterator = body.iterator();
            while(iterator.hasNext()){
                Element e = (Element)iterator.next();
                if (e instanceof Page) {
                    Page p = (Page)e;        
                    if(p.getPageName().equals("page1")){
                        Page p3 = new Page(doc);
                        p3.setPageName("p4");
                        body.add(p3);
                        Line line = new Line(doc);
                        p3.add(line);
                        Paragraph paph = new Paragraph(doc,"test");
                        line.add(paph);
                        break;
                    }
                }
            }
         doc.save(path);            
        }catch(IOException ex){
             ex.printStackTrace();
        }
    }
    
     public void testNewImageDelete(){
        try{
            Body body = doc.getBody();
            Iterator iterator = body.iterator();
            while(iterator.hasNext()){
                Element e = (Element)iterator.next();
                if (e instanceof Page) {
                    Page p = (Page)e;        
                    if(p.getPageName().equals("page7")){
                        Iterator it = p.iterator(); 
                        while(it.hasNext()){
                            Element ec = (Element)it.next();
                            String sd = ec.getDescription();
                            if(ec instanceof Frame){
                                Frame f = (Frame)ec;
                                if (f.getChildElement() instanceof Image){
                                    p.remove(ec);
                                    break;
                                }
                            }
                        }
                        break;
                    }
                }
            }
         doc.save(path);            
        }catch(IOException ex){
             ex.printStackTrace();
        }
    }   
     
     public void testNewImageAdd(){
        try{
            Body body = doc.getBody();
            Iterator iterator = body.iterator();
            while(iterator.hasNext()){
                Element e = (Element)iterator.next();
                if (e instanceof Page) {
                    Page p = (Page)e;        
                    if(p.getPageName().equals("page7")){
                            Frame f = new Frame(doc);
                            p.add(f);
                            Image image = new Image(doc);
                            f.add(image);
                            f.setChildElement(image);
                        }
                     break;
                 }
           }
         doc.save(path);            
        }catch(IOException ex){
             ex.printStackTrace();
        }
    }       
}
