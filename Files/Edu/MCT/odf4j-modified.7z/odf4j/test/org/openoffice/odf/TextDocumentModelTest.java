/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: TextDocumentModelTest.java,v $
 *
 *  $Revision: 1.5 $
 *
 *  last change: $Author: lo $ $Date: 2007/10/30 13:43:12 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf;

import java.io.IOException;
import java.util.Iterator;
import junit.framework.*;
import org.openoffice.odf.text.Body;
import org.openoffice.odf.text.List;
import org.openoffice.odf.text.ListItem;
import org.openoffice.odf.text.Paragraph;
import org.openoffice.odf.text.Portion;
import org.openoffice.odf.text.Style;
import org.openoffice.odf.text.TextDocument;

/**
 *
 * @author lo119109
 */
public class TextDocumentModelTest extends TestCase {
    
    public TextDocumentModelTest(String testName) {
        super(testName);
    }
    
    private OpenDocument odf;
    
    protected void setUp() throws Exception {
        System.out.println("setup");
        odf = OpenDocumentFactory.load("test/testdocument1.odt");
    }

    protected void tearDown() throws Exception {
        odf.close();
    }
        
    public void testMapping()
    {
        TextDocument td = (TextDocument) odf;
        Body body = td.getBody();
        System.out.println("body structure:");
        Iterator it = body.iterator();
        while (it.hasNext()) {
            Object obj = it.next();
            System.out.println(" -> " + obj.getClass().getName());
            if (obj instanceof Paragraph) {
                Paragraph p = (Paragraph) obj;
                Iterator it2 = p.iterator();
                while (it2.hasNext()) {
                    System.out.println("    portion: {" + it2.next()+"}");
                }
            }
        }
    }
    
    public void testCreateContent() {        
        try {
            TextDocument textdoc = new TextDocument();
            Body body = textdoc.getBody();
            body.add(new Paragraph(textdoc, "Hello World!"));

            Paragraph p2 = new Paragraph(textdoc, "Foo");
            p2.addText(" Bar!", new Style("Text Body"));            
            body.add(p2);
           
            p2.insertText(3, "<INSERT1> ");
            p2.insertText(0, "<INSERT2> ");
           
            List l1 = new List(textdoc,
                new ListItem(textdoc, "list item 1"),
                new ListItem(textdoc, "list item 2"),
                new ListItem(textdoc, "list item 3"),
                new ListItem(textdoc, "list item 4"));
           
            body.add(l1);
           
            textdoc.save("out_testCreateContent.odt");
           
        } catch (Exception ex) {
            ex.printStackTrace();
            fail();
        }
    }
}
