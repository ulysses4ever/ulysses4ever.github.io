/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: SpreadsheetTest.java,v $
 *
 *  $Revision: 1.3 $
 *
 *  last change: $Author: lo $ $Date: 2007/07/12 11:36:25 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf;

import org.w3c.dom.Document;
import java.util.Date;
import java.sql.Time;

import org.openoffice.odf.xml.OdfXMLHelper;
import org.openoffice.odf.spreadsheet.SpreadsheetDocument;
import org.openoffice.odf.util.Link;
import javax.swing.table.DefaultTableModel;

import org.xml.sax.InputSource;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;

public class SpreadsheetTest extends TestCase {
    
    public void testSpreadsheet()  {

        try{
            SpreadsheetDocument calc=new SpreadsheetDocument();

            DefaultTableModel tableModel=new DefaultTableModel();
            tableModel.addColumn("Column A");
            tableModel.addColumn("Column B");
            tableModel.addColumn("Column C");
            String[] data={"A2","B2","C2"};
            tableModel.addRow(data);
            Integer[] dataInt={new Integer(12),new Integer(13),new Integer(14)};
            tableModel.addRow(dataInt);
            Long[] dataLong={new Long(12132),new Long(113453),new Long(12351234)};
            tableModel.addRow(dataLong);
            Boolean[] dataBool={Boolean.TRUE,Boolean.FALSE,Boolean.TRUE};
            tableModel.addRow(dataBool);
            Date[] dateData={new Date(),new Date(),new Date()};
            tableModel.addRow(dateData);

            Time[] timeData={new Time((new Date()).getTime()), new Time((new Date()).getTime()), new Time((new Date()).getTime())};
            tableModel.addRow(timeData);

            Link[] linkData={new Link("http://www.openoffice.org","openoffice"),new Link("http://www.sun.com","sun"),new Link("http://eis.services.openoffice.org","eis")};

            tableModel.addRow(linkData);

            calc.addSpreadsheet("Test1",tableModel,true);
            calc.deleteSpreadsheet("Sheet1");

            calc.addSpreadsheet("Test2",null,true);

            Document doc=calc.getDocument("content.xml");
            OdfXMLHelper xmlHelper=new OdfXMLHelper();
            InputSource is=calc.getEntityResolver().resolveEntity(null,"resource:/org/openoffice/odf/xml/transform/identity.xsl");
            StreamSource trans=new StreamSource(is.getByteStream(),is.getSystemId());

            xmlHelper.transform(calc,"content.xml",trans,"content.xml");

            calc.save("calc.ods");
        } catch (Exception e) {
            fail("plonk!");
        }
    }
}

