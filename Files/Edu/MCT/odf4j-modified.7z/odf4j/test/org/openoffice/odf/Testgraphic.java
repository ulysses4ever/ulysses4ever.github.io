/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Testgraphic.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:51 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/


package org.openoffice.odf;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import java.util.Iterator;
import java.util.Collection;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.OpenDocumentFactory;
import org.openoffice.odf.schema.Namespaces;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.Element;

import org.openoffice.odf.graphics.*;

import org.openoffice.odf.text.List;
import org.openoffice.odf.text.ListItem;
import org.openoffice.odf.text.Paragraph;

import junit.framework.TestCase;
/**
 *
 * @author duyunfen
 */
public class Testgraphic extends TestCase{
    
    private GraphicsDocument doc = null;
    private OdfPackage odfPackage = null;
    private String path = "c:/t0.odg";
    /** Creates a new instance of Testgraphic */
    public Testgraphic(String testname) {
        super(testname);
    }

    protected void setUp() throws Exception {
        System.out.println("setup");
        try{
            odfPackage = OpenDocumentFactory.load(path);
            doc  = (GraphicsDocument)odfPackage;
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }

    protected void tearDown() throws Exception {
        odfPackage.close();
    } 
    
    public Page testInsertPage(BlockElement blockElement){
        Page page = null;
        try{
            page = (Page)doc.createGraphics("draw:page");
            //page.setAttribute("draw:name","page4");
            blockElement.add(page);
        }catch(Exception ex){
            System.out.print("insert page failed!");
        }
        return page;
    }
    public Forms testInsertforms(BlockElement blockElement){
        Forms form = null;
        try{
            form = (Forms)doc.createForms("office:forms");
            blockElement.add(form);
        }catch(Exception ex){
            System.out.print("insert forms failed!");            
        }
        return form;
    }
    public Style testInsertstyle(BlockElement autostyle){
        Style stylenode = null;
        try{
            stylenode = doc.createStyle("style:style");
            stylenode.setAttribute("style:name","dp1");
            stylenode.setAttribute("style:family","drawing-page");
            autostyle.add(stylenode);
        }catch(Exception ex){
            System.out.print("insert style failed!");
        }
        return stylenode;
    }
    public Rectangle testInsertRect(BlockElement blockElement){
        Rectangle recnode = null;
        try{
            recnode = (Rectangle)doc.createGraphics("draw:rect");
            blockElement.add(recnode);
        }catch(Exception ex){
            System.out.print("insert rect failed!");
        }
        return recnode;
    }
    public Text testInsertText(BlockElement blockElement){
        Text text = null;
        try{
        text = (Text)doc.createText("text");
        blockElement.add(text);
        }catch(Exception ex){
            System.out.print("insert text failed!");
        }
        return text;
    }
    public Circle testInsertcircle(BlockElement blockElement){
        Circle circle = null;
        try{
        circle = (Circle)doc.createGraphics("draw:circle");
        blockElement.add(circle);
        }catch(Exception ex){
            System.out.print("insert Circle failed!");
        }
        return circle;        
    }
    public Line testInsertline(BlockElement blockElement){
        Line line = null;
        try{
        line = (Line)doc.createGraphics("draw:line");
        blockElement.add(line);
        }catch(Exception ex){
           System.out.print("insert Line failed!");
        }
        return line;          
    }
    public Polygon testInsertpolygon(BlockElement blockElement){
        Polygon polygon = null;
        try{
        polygon = (Polygon)doc.createGraphics("draw:polygon");
        blockElement.add(polygon);
        }catch(Exception ex){
            System.out.print("insert Polygon failed!");
        }
        return polygon;             
    }

    public void testHandleStyle(){
        try{
            Style autostyle = doc.getStyle();
            Iterator iterator=autostyle.iterator();
            if (iterator.hasNext()){
                do{
                    Element element=(Element)iterator.next();
                    if (element instanceof Style){
                        Style style = (Style)element;
                        System.out.println(style.getName());
                    }
                }while ( iterator.hasNext());
            }else{
                   testInsertstyle(autostyle);
            }
            doc.save(path);
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
     
    public void testHandleGraphicBlockElement() {
    try{
        Body body = doc.getBody();
        if (body instanceof Body){
            Page p1 = testInsertPage(body);
            System.out.println(p1.getPageName());
            if (p1.getPageName() == "page4"){
                testInsertforms(p1);
                Rectangle rc = testInsertRect(p1);
                testInsertText(rc);   
            }
        }
        Iterator iterator=body.iterator();
        if ( iterator.hasNext()){
            do{
                Element element=(Element)iterator.next();
                 if( element instanceof GraphicElement) {
                        if ( element instanceof Page ) {
                            Page p = (Page)element;
                            System.out.println(p.getPageName());
                            if (p.getPageName().equals("page3")){
                                Rectangle rc = testInsertRect(p);
                                testInsertText(rc);   
                            }else if(p.getPageName().equals("page1")){
                                Line line = testInsertline(p);
                                testInsertText(line);
                            }else if(p.getPageName().equals("page2")){
                                Circle circle = testInsertcircle(p);
                                testInsertText(circle);
                            }
                        }else if ( element instanceof Rectangle ) {
                            System.out.println("rect ");
                        }
                    } else if (element instanceof Forms){
                            System.out.println("forms");
                    }else {
                        System.out.println("not grphic shape.");
                    }
                }  while ( iterator.hasNext() ) ;
            }
        doc.save(path);
    }catch(IOException ex){
        ex.printStackTrace();
    }
 }
}
