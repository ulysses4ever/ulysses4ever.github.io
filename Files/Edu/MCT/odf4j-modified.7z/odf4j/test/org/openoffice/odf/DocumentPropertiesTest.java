/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: DocumentPropertiesTest.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: lo $ $Date: 2007/07/12 11:36:25 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf;

import junit.framework.*;
import java.io.IOException;
import java.io.InputStream;
import java.lang.Exception;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.TimeZone;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.openoffice.odf.OdfPackage;
import org.openoffice.odf.common.meta.DocumentProperties;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author zhaoshen
 */
public class DocumentPropertiesTest extends TestCase {
    
    public DocumentPropertiesTest(String testName) {
         super(testName);
    }
     public void testDocumentProperties()  {
        OdfPackage pkg = null;
        try {
            pkg = OpenDocumentFactory.load("test/testdocument1.odt");
        } catch (IOException ex) {
            ex.printStackTrace();
        }    
        DocumentProperties dp = pkg.getDocumentProperties();
        
            dp.setTitle("test document");
            dp.setInitialCreator("zhaosheng");
            dp.setSubject("for the testing");
            dp.setLanguage("chinese");
            dp.setKeyword("test");
            dp.setEditingCycles(100L);
            dp.setDescription("this is the test of the class");
            dp.setEditingDuration(4895);
            dp.setPrintedBy("zhaosheng");       
            dp.setCreationDate(new Date());
            dp.setPrintedDate(new Date());
            ArrayList list = dp.getCreator();
            list.add(list.size(),"Peter");
            list.add(list.size(),"Jack");
             System.out.println("there are "+list.size()+" creators:\n");
             for(int i =0;i<list.size();i++)
             System.out.println(list.get(i)); 
             list.remove("Jack");
             System.out.println("there are "+list.size()+" creators:\n");
             for(int i =0;i<list.size();i++)
             System.out.println(list.get(i)); 
        System.out.println("generator is: "+dp.getGenerator());
        System.out.println(dp.getLanguage());
        try {
            System.out.println(dp.getDate());
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        System.out.println("Editing Duration is : "+dp.getEditingDuration());
        System.out.println("keyword is: "+dp.getKeyword());
        System.out.println("title is: "+dp.getTitle());
        System.out.println("subject is: "+ dp.getSubject());
        System.out.println(dp.getInitialCreator());
        try {
            System.out.println("created at: " + dp.getCreationDate());
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        try {
            System.out.println("printed at: " +dp.getPrintedDate());
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
         System.out.println("origin from: " +dp.getInitialCreator());
        try {
            pkg.save("testdocument1.odt");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
     }
}
