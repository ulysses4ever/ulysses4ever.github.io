/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OdfPackageTest.java,v $
 *
 *  $Revision: 1.5 $
 *
 *  last change: $Author: lo $ $Date: 2007/07/12 11:36:25 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf;

import java.io.OutputStream;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import junit.framework.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.openoffice.odf.xml.OdfPackageStream;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 *
 * @author Lars Oppermann <lars.oppermann@sun.com>
 */
public class OdfPackageTest extends TestCase {
    
    public OdfPackageTest(String testName) {
        super(testName);
    }

    
    private OdfPackage odfPackage;
    
    protected void setUp() throws Exception {
        System.out.println("setup");
        odfPackage = OpenDocumentFactory.load("test/testdocument1.odt");
    }

    protected void tearDown() throws Exception {
        odfPackage.close();
    }

    /**
     * Test of getContentStream method, of class org.openoffice.odf.OdfPackage.
     */
    public void testGetContentStream() {
        System.out.println("getContentStream");
        try{
            OdfPackageStream stream = odfPackage.getContentStream();
            Document doc = parseStream(stream.getInputStream());
            Element root = doc.getDocumentElement();
            if (! root.getLocalName().equals("document-content"))
                fail("getContent stream did not return ODF content stream. root element is: "+
                        root.getLocalName());
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
        
    public void testSave() {
        try {
            File f = File.createTempFile(
                    "odfout_1_", ".odt", new File("build/test/results"));
            FileOutputStream out = new FileOutputStream(f);
            /*
            OdfPackageStream content = odfPackage.getContentStream();           
            Document doc = parseStream(content.getInputStream());           
             */
            Document doc = odfPackage.getDocument(OdfPackage.STREAMNAME_CONTENT);
            Node node = doc.getDocumentElement();
            capitalizeText(node);
            
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty("indent", "yes");
            t.transform(
                    new DOMSource(doc), new StreamResult(System.out));
            OdfPackageStream content = odfPackage.getContentStream();
            OutputStream cout = content.getOutputStream();
            t.transform(
                    new DOMSource(doc), new StreamResult(cout));
            cout.close();
            
            odfPackage.save(out, f.toURI().toString());
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
        
    }

    /**
     * Test of getStyleStream method, of class org.openoffice.odf.OdfPackage.
     */
    public void testGetStyleStream() {
        try {                
            OdfPackageStream content = odfPackage.getStyleStream();           
            Document doc = parseStream(content.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }

    /**
     * Test of getMetadataStream method, of class org.openoffice.odf.OdfPackage.
     */
    public void testGetMetadataStream() {
        try {
            OdfPackageStream content = odfPackage.getMetadataStream();           
            Document doc = parseStream(content.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }    

    // parse xml
    private Document parseStream(InputStream in) {
        Document doc = null;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.parse(in);        
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
        return doc;
    }
    
    // recursive function to capatalize all text in a dom sub-tree
    private void capitalizeText(Node node) {
        for (; node != null; node = node.getNextSibling()) {
            if (node.getNodeType() == Node.TEXT_NODE) {
                node.setNodeValue(node.getNodeValue().toUpperCase());
            } else {
                capitalizeText(node.getFirstChild());
            }            
        }
    }
    
}
