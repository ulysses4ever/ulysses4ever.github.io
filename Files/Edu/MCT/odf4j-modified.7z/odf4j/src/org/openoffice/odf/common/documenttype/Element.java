/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Element.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.common.documenttype;

import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;

import java.util.List;
import java.io.Reader;
import java.io.StringReader;

import org.openoffice.odf.OpenDocument;
/**
 *
 * @author duyunfen
 */
 
public abstract class Element implements DocNode{
    private Node node = null;
    private String descrption = "ODF Element";
    
    /** Creates a new instance of Element */
    public Element(){}
    
    protected Element(Node node){
        attach(node);
    }
    protected void attach(Node node){
        this.node = node;
    }
    
    public Node getNode(){
        return node;
    }   
    
    /** get Node Name */
    public String getNodeName() {
      String shapeName =""; 
      if(node!=null)
         shapeName= node.getNodeName(); 
      return shapeName;
    }       

    /**
     *get the factory associated with the current element
     */
    public abstract ElementFactory getFactory(Document doc);
    
    /**
     *set and get Description.
     */
    public void setDescription(String desc){
        descrption = desc;
    }
    public String getDescription(){
        return descrption;
    }
    
    /** get node's attibute */
    public String getAttribute(Node node,String attributeType){
        return getAttibute(node,attributeType);
    }
    
     public String getAttibute(Node node,String attributeType){
        NamedNodeMap map = node.getAttributes();
        Node attr = map.getNamedItem(attributeType);
        if (attr != null) {
            return attr.getNodeValue();
        } else {
            return null;
        }    
    }
    
     /**set attribute ,prvoid the attr node was exist */
    public void setAttribute(String attType,String value,String nameSpaceURIForCreate){
      NamedNodeMap map = node.getAttributes();
      Node attr = map.getNamedItem(attType);
      try{
          if(attr != null){
              attr.setNodeValue(value);
          }else{
              Attr a = getNode().getOwnerDocument().createAttributeNS(nameSpaceURIForCreate,attType);
              a.setValue(value);
              map.setNamedItemNS(a);
          }
      } catch (Exception ex) {
          throw new IllegalArgumentException("fail to set " + nameSpaceURIForCreate 
                  + " " + attType +"attibute value " + value);
      }
  }    
    
   public abstract String getStyle();
    
    /** get (copy of) all text childs */
    public String getTextContent() {
        StringBuffer sb = new StringBuffer();
        getText(sb, getNode());
        return sb.toString();        
    }
    
    public Reader getTextContentReader() {
        return new StringReader(getTextContent());
    }
    
    private void getText(StringBuffer sb, Node node) {
        if (node == null) return;
        if (node.getNodeType() == Node.TEXT_NODE) {
            sb.append(node.getNodeValue());    
            sb.append(' ');
        } else {
            Node child = node.getFirstChild();
            while (child != null) {
                getText(sb, child);
                child = child.getNextSibling();
            }
        }
    }       
}
