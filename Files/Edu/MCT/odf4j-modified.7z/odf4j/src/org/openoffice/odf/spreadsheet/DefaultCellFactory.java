/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: DefaultCellFactory.java,v $
 *
 *  $Revision: 1.4 $
 *
 *  last change: $Author: bei $ $Date: 2007/03/05 17:57:05 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.spreadsheet;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.openoffice.odf.util.Link;
import org.openoffice.odf.schema.Namespaces;


/**
 * CellFactory to set content for cells
 * <p>
 * This CellFactory currently supports 
 * java.lang.String, java.lang.Integer, 
 * java.lang.Long, java.lang.Boolean,
 * java.util.Date and java.sql.Time objects
 * but Date and time are not handled correct yet,
 * eg. DocumentSettings and Spreadsheets BaseDate are not considered.
 * </p>
 *
 */
public class DefaultCellFactory implements CellFactory {

    protected static DateFormat _dateFormatValue;
    protected static DateFormat _timeFormatValue;
    protected static DateFormat _dateFormatDisplay;
    protected static DateFormat _timeFormatDisplay;


    private static class SimpleISO8601TimeFormat extends DateFormat {
        public SimpleISO8601TimeFormat() {
            super();
        }
        
        public StringBuffer format(Date date, StringBuffer toAppendTo,
                                   FieldPosition fieldPosition) {

            Calendar calendar=Calendar.getInstance(Locale.US);
            calendar.setTime(date);
            toAppendTo.append("PT");
            int i=calendar.get(Calendar.HOUR_OF_DAY);
            toAppendTo.append(i);
            toAppendTo.append("H");
            i=calendar.get(Calendar.MINUTE);
            toAppendTo.append(i);
            toAppendTo.append("M");
            i=calendar.get(Calendar.SECOND);
            toAppendTo.append(i);
            toAppendTo.append("S");
            return toAppendTo;
        }

        public Date parse(String source, ParsePosition pos) {
            throw new RuntimeException("parse not implemented");
        }

    }

    private static class ODFDateAndTimeFormat extends DateFormat {

        private static DateFormat _df=new SimpleDateFormat("yyyy-MM-dd");
        private static DateFormat _tf=new SimpleDateFormat("HH:mm:ss");

        public ODFDateAndTimeFormat() {
            super();
        }
        
        public StringBuffer format(Date date, StringBuffer toAppendTo,
                                   FieldPosition fieldPosition) {

            synchronized(_df) {
                toAppendTo.append(_df.format(date));
            }
            synchronized(_tf) {
                toAppendTo.append("T");
                toAppendTo.append(_tf.format(date));
            }
            return toAppendTo;
        }

        public Date parse(String source, ParsePosition pos) {
            throw new RuntimeException("parse not implemented");
        }

    }

    public DefaultCellFactory() {
    }

    protected DateFormat getDateFormatValue() {
        if ( _dateFormatValue == null ) {
            _dateFormatValue = new ODFDateAndTimeFormat();
        }
        return _dateFormatValue;
    }
    
    protected DateFormat getTimeFormatValue() {
        if ( _timeFormatValue == null ) {
            _timeFormatValue = new SimpleISO8601TimeFormat();
        }
        return _timeFormatValue;
    }

    protected DateFormat getDateFormatDisplay() {
        if ( _dateFormatDisplay == null ) {
            _dateFormatDisplay = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        }
        return _dateFormatDisplay;
    }
    
    protected DateFormat getTimeFormatDisplay() {
        if ( _timeFormatDisplay == null ) {
            _timeFormatDisplay = new SimpleDateFormat("h:mm a");
        }
        return _timeFormatDisplay;
    }

    public void setCellContent(SpreadsheetDocument spreadsheetDocument,
                               Document doc,
                               Element cell,
                               Object content) {

        boolean useTextP=false;

        if ( content == null ) {

        } else if ( content instanceof Link ) {
            Link link=(Link)content;
            cell.setAttributeNS(Namespaces.office,"office:value-type","string");
            cell.setAttributeNS(Namespaces.table,"table:style-name","Text");
            Element pL=doc.createElementNS(Namespaces.text,"text:p");
            Element a=doc.createElementNS(Namespaces.text,"text:a");
            a.setAttributeNS(Namespaces.xlink,"xlink:href",link.getHref());
            a.setTextContent(link.getTitle());
            pL.appendChild(a);
            cell.appendChild(pL);
        } else if ( content instanceof Integer ) {
            useTextP=true;
            cell.setAttributeNS(Namespaces.office,"office:value-type","float");
            cell.setAttributeNS(Namespaces.office,"office:value",((Integer)content).toString());
            cell.setAttributeNS(Namespaces.table,"table:style-name","Number");
        } else if ( content instanceof Long ) {
            useTextP=true;
            cell.setAttributeNS(Namespaces.office,"office:value-type","float");
            cell.setAttributeNS(Namespaces.office,"office:value",((Long)content).toString());
            cell.setAttributeNS(Namespaces.table,"table:style-name","Number");
        } else if ( content instanceof BigDecimal ) {
            useTextP=true;
            cell.setAttributeNS(Namespaces.office,"office:value-type","float");
            cell.setAttributeNS(Namespaces.office,"office:value",((BigDecimal)content).toString());
            cell.setAttributeNS(Namespaces.table,"table:style-name","Number");
        } else if ( content instanceof Float ) {
            useTextP=true;
            cell.setAttributeNS(Namespaces.office,"office:value-type","float");
            cell.setAttributeNS(Namespaces.office,"office:value",((Float)content).toString());
            cell.setAttributeNS(Namespaces.table,"table:style-name","Number");
        } else if ( content instanceof Boolean ) {
            cell.setAttributeNS(Namespaces.office,"office:value-type","boolean");
            cell.setAttributeNS(Namespaces.office,"office:boolean-value",((Boolean)content).toString());
            cell.setAttributeNS(Namespaces.table,"table:style-name","Boolean");
            Element pB=doc.createElementNS(Namespaces.text,"text:p");
            pB.setTextContent(content.toString().toUpperCase());
            cell.appendChild(pB);
        } else if ( content instanceof Time ) {
            cell.setAttributeNS(Namespaces.office,"office:value-type","time");
            String s;
            DateFormat df=getTimeFormatValue();
            synchronized ( df ) {
                s=df.format((Time)content);
            }
            cell.setAttributeNS(Namespaces.office,"office:time-value",s);
            df=getTimeFormatDisplay();
            synchronized ( df ) {
                s=df.format((Time)content);
            }
            Element pT=doc.createElementNS(Namespaces.text,"text:p");
            pT.setTextContent(s);
            cell.setAttributeNS(Namespaces.table,"table:style-name","Time");
            cell.appendChild(pT);
        } else if ( content instanceof Date ) {
            cell.setAttributeNS(Namespaces.office,"office:value-type","date");
            String s;
            DateFormat df=getDateFormatValue();
            synchronized ( df ) {
                s=df.format((Date)content);
            }
            cell.setAttributeNS(Namespaces.office,"office:date-value",s);
            df=getDateFormatDisplay();
            synchronized ( df ) {
                s=df.format((Date)content);
            }
            Element pD=doc.createElementNS(Namespaces.text,"text:p");
            pD.setTextContent(s);
            cell.setAttributeNS(Namespaces.table,"table:style-name","DateAndTime");
            cell.appendChild(pD);
        } else {
            String s=content.toString();
            boolean wasHref=false;
            if ( s.startsWith("<a href=") || s.startsWith("<A href=") ) {
                int i=s.indexOf('"',9);
                if (i==-1) i=s.indexOf("'",9);
                if ( i > 0 ) {
                    String href=s.substring(9,i);
                    int j=s.indexOf('>',i);
                    if ( j > 0 ) {
                        int k=s.indexOf("</a>");
                        if ( k==-1) {
                            k=s.indexOf("</A>");
                        }
                        if ( k > 0 ) {
                            String text=s.substring(j+1,k);

                            cell.setAttributeNS(Namespaces.office,"office:value-type","string");
                            cell.setAttributeNS(Namespaces.table,"table:style-name","Text");
                            Element pA=doc.createElementNS(Namespaces.text,"text:p");
                            Element a=doc.createElementNS(Namespaces.text,"text:a");
                            a.setAttributeNS(Namespaces.xlink,"xlink:href",href);
                            a.setTextContent(text);
                            pA.appendChild(a);
                            cell.appendChild(pA);

                            wasHref=true;
                        }
                    }
                }
            } 
            if ( ! wasHref ) {
                useTextP=true;
                cell.setAttributeNS(Namespaces.office,"office:value-type","string");
                cell.setAttributeNS(Namespaces.table,"table:style-name","Text");
            }
        }

        if ( useTextP ) {
            Element p=doc.createElementNS(Namespaces.text,"text:p");
            p.setTextContent(content.toString());
            cell.appendChild(p);
        }
    }

}


