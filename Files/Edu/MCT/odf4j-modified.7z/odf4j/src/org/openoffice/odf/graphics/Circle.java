/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Circle.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.graphics;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Node;
import java.awt.Point;
/**
 *
 * @author duyunfen
 */
public class Circle extends GraphicElement{
    
    /** Creates a new instance of Circle */
    public Circle() {
    }
    public Circle(Node node){
      super(node);
      if(node.getNodeName()!="draw:circle"){
            throw new IllegalArgumentException("not a circle node initialized");   
      }else{
            /** initial the default attribute */
            initial();
      }
        setDescription("ODF circle");
    }
    
    public Circle(OpenDocument od){
        super(od,"draw:circle");
    }
    
    /** initial the default attributes */
    public void initial(){
        super.initial();
        this.setAttribute("svg:cx","4.999cm",Namespaces.draw);
        this.setAttribute("svg:cy","6.222cm",Namespaces.draw);
        this.setAttribute("svg:r","5.111cm",Namespaces.draw);  
        this.setAttribute("draw:kind","full",Namespaces.draw);         
    }
    
    /** get center point attribute svg:cx, svg:cy */
   public Point getCenterPoint(){
        return getAttriPointValue("svg:cx","svg:cy");
   }
   
   /**get svg:r attribute */
   public float getRedius(){
        return getAttriFloatValue("svg:r");
   }
   
   /** get draw:kind attribute */
   public String getKind(){
        return getAttriStringValue("draw:kind");
   }
}
    

