/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: BlockElementImpl.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.common.documenttype;

import java.util.AbstractList;
import java.util.NoSuchElementException;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.DOMException;

import org.w3c.dom.Node;
/**
 *
 * @author duyunfen
 *Element package's base Implement class
 */
public abstract class BlockElementImpl extends AbstractList<Element>{
    
    protected Node node = null;
    /** Creates a new instance of BlockElementImpl */
    
    public BlockElementImpl(){}
    
    public BlockElementImpl(Node node) {
        this.node = node;
    }
    
    protected Node nextElement(Node node) {        
        do {
            node = node.getNextSibling();
        } while (node != null && node.getNodeType() != Node.ELEMENT_NODE);
        return node;
    }

    public int size() {
        // count elements
        int count = 0;
        Node e = node.getFirstChild();
        if ( e != null && e.getNodeType() != Node.ELEMENT_NODE ) {
            e=nextElement(e);
        }
        while (e != null) {
            count++;
            e = nextElement(e);
        }
        return count;
    }

    protected abstract Element getElement(Node node);
    
    public Element get(int index) {
        int i = 0;
        //Node e = nextElement(node.getFirstChild());
        Node e = node.getFirstChild();
        if ( e.getNodeType() != Node.ELEMENT_NODE ) {
            e=nextElement(e);
        }
        while (i < index && e != null ) {
            e = nextElement(e);
            i++;
        }
        if (e == null ) {
            throw new NoSuchElementException("index not found "+index);
        } else {    
            Element result = getElement(e);
            return result;
        }
    }
    
    public Element set(int index, Element element) {
        Element old = get(index);
        try {
            node.replaceChild(element.getNode(), old.getNode());
        } catch (DOMException ex) {
            // old element stays in place 
            throw new IllegalArgumentException(ex.getMessage());
        }        
        return old;
    }

    /** 
     * adds the element to the end of the content collection
     */
    public boolean add(Element e) {
        add(size(), e);
        return true;
    }

    /**
     * In case of nested spans, the new portion will have the same parent
     * as the span at the reference position
     */
    public void add(int index, Element newElement) {
        // PRE index => 0 && index <= size()
        if (index <0 || index > size()) {
            throw new IndexOutOfBoundsException("index must be >= 0 and <= size()");
        }        
        if (index == size()) {
            node.appendChild(newElement.getNode());
        } else {
            // get the insertion point
            Element refElement = (Element) get(index);
            Node refNode = refElement.getNode();
            node.insertBefore(newElement.getNode(), refNode); 
        }
    }
        
    public Element remove(int index) {
        Element element = (Element) get(index);
        node.removeChild(element.getNode());
        return element;
    }    
    
   public boolean remove(Element e){
        node.removeChild(e.getNode());
        return true;
    }
}
