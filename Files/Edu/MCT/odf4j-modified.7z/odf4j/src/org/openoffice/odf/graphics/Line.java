/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Line.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/


package org.openoffice.odf.graphics;
import org.openoffice.odf.schema.Namespaces;
import org.openoffice.odf.OpenDocument;
import java.awt.Point;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 *
 * @author duyunfen
 */
public class Line extends GraphicElement{
  private String lineType = ""; 
  private String dashType = "";    
    /** Creates a new instance of Line */
    public Line() {
    }
    public Line(Node node){
        super(node);
      if(node.getNodeName()!="draw:line"){
            throw new IllegalArgumentException("not a line node initialized");   
      }else{
            initial();
      }
    }
    
    public Line(OpenDocument od){
        super(od,"draw:line");
    }
    
    /** initial default attr node */
    public void initial(){
        super.initial();
        this.setAttribute("svg:x1","0",Namespaces.draw);
        this.setAttribute("svg:y1","0",Namespaces.draw); 
        this.setAttribute("svg:x2","10.999cm",Namespaces.draw);
        this.setAttribute("svg:y2","10.999cm",Namespaces.draw);          
    }
    
    public String getLineType(){
       return lineType;
   }
 
   public String getDashType(){
        return dashType;
   }
 
   /** start point */
   public Point getStartPoint(){
        return getAttriPointValue("svg:x1","svg:y1");
   }
   
   /** end point  */
    public Point getEndPoint(){
        return getAttriPointValue("svg:x2","svg:y2");
   }
}
