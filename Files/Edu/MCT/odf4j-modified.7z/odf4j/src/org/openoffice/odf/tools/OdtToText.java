/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OdtToText.java,v $
 *
 *  $Revision: 1.4 $
 *
 *  last change: $Author: mib $ $Date: 2007/10/25 13:22:43 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.tools;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Stack;
import org.openoffice.odf.OpenDocumentFactory;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import org.openoffice.odf.OdfPackage;
import org.openoffice.odf.xml.OdfXMLHelper;
import org.openoffice.odf.schema.Namespaces;

/**
 * Simple demo program extracting text content from OpenDocument text files...
 * <p>Outputs anything in <text:p> or <text:h> tags except when contained
 * in <text:tracked-changes>.</p>
 */
public class OdtToText extends DefaultHandler {
    
    public static void main(String[] argv) {
        try {
            OdfPackage pkg = OpenDocumentFactory.load(argv[0]);
            OdtToText txt = new OdtToText(System.out);
            txt.convert(pkg);
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }    
    
    private PrintStream out;
    private Stack<ElementInfo> elementStack;    
    private Locator documentLocator;
    private boolean tracked=false;
    private boolean ph=false;

    private final class ElementInfo {
        public String name;
        public String ns;
        public Attributes atts;
        public ElementInfo(String name, String ns, Attributes atts) {
            this.name = name;
            this.ns = ns;
            this.atts = atts;
        }
    }

    public OdtToText(OutputStream out) {
        this.out = new PrintStream(out);
    }
    
    public void convert(OdfPackage pkg) {
        try {
            OdfXMLHelper odfXMLHelper=new OdfXMLHelper();
            odfXMLHelper.parse(pkg,OdfPackage.STREAMNAME_CONTENT,this,this);
        } catch (Exception ex) {
            ex.printStackTrace();
        }     
    }
    
    public void setDocumentLocator(Locator locator) {
        super.setDocumentLocator(locator);
        documentLocator = locator;
    }

    public void startDocument() throws SAXException {
        elementStack = new Stack<ElementInfo>();
    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        ElementInfo ei = new ElementInfo(localName, uri, atts);
        if ( uri.equals(Namespaces.text) && localName.equals("tracked-changes") ) {
            tracked=true;
        } else if ( uri.equals(Namespaces.text) && (localName.equals("p") || localName.equals("h")) ) {
            ph=true;
        } else if ( uri.equals(Namespaces.text) && localName.equals("list-item")) {
            if ( ! tracked ) {
                this.out.print("  * ");
            }
        }
        elementStack.push(ei);
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        ElementInfo ei = (ElementInfo) elementStack.pop();
        if ( uri.equals(Namespaces.text) && localName.equals("tracked-changes") ) {
            tracked=false;
        } else if (uri.equals(Namespaces.text) && (localName.equals("p") || localName.equals("h")) ) {
            if ( ! tracked ) {
                this.out.println();
            }
            ph=false;
        } else if (uri.equals(Namespaces.text) && localName.equals("line-break")) {
            if ( ! tracked ) {
                this.out.println();
            }
        } else if (uri.equals(Namespaces.text) && localName.equals("s")) {
            try {
                int n = Integer.parseInt(ei.atts.getValue(ei.ns, "c"));
                for (int i=0; i<n; i++) {
                    this.out.print(" ");
                }
            } catch (NumberFormatException ex) {/*ignored*/}
        }
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        if ( !tracked && ph ) {
            this.out.print(new String(ch, start, length));
        }
    }    
}
