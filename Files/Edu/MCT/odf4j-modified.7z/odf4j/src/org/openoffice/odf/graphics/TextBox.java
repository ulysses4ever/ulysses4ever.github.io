/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: TextBox.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.graphics;
import org.openoffice.odf.schema.Namespaces;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.InlineElement;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.openoffice.odf.OpenDocument;
import org.w3c.dom.Document;
import org.openoffice.odf.schema.Namespaces;
/**
 *
 * @author duyunfen
 */
public class TextBox extends GraphicElement{
    private Frame frame = null;
    /** Creates a new instance of TextBox */
    public TextBox() {
    }
    public TextBox(Node node){
        super(node);
    } 
    public TextBox(OpenDocument od){
        super(od,"draw:text-box");       
    }
    
    public float getMinHeight(){
        return getAttriFloatValue("fo:min-height");
    }
    public void setMinHeight(float value){
       setAttribute(Namespaces.draw,"fo:min-height",Float.toString(value));
    }
    
    public float getMinWidth(){
        return getAttriFloatValue("fo:min-width");
    }
    public void setMinWidth(float value){
        setAttribute(Namespaces.draw,"fo:min-width",Float.toString(value));
    }
    
    public float getMaxHeight(){
        return getAttriFloatValue("fo:max-height");
    }
    public void setMaxHeight(float value){
       setAttribute(Namespaces.draw,"fo:max-height",Float.toString(value));
    }    
    
    public float getMaxWidth(){
        return getAttriFloatValue("fo:max-width");
    }
    public void setMaxWidth(float value){
        setAttribute(Namespaces.draw,"fo:max-width",Float.toString(value));
    }
   
}
