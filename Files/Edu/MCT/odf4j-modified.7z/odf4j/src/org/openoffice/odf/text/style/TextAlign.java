package org.openoffice.odf.text.style;

/**
 *
 * @author Eliseev
 */
public enum TextAlign {
    LEFT { String getFoTextAlignAttr() { return "start"; }},
    CENTER { String getFoTextAlignAttr() { return "center"; }},
    RIGHT { String getFoTextAlignAttr() { return "end"; }},
    JUSTIFY { String getFoTextAlignAttr() { return "justify"; }};
    
    abstract String getFoTextAlignAttr();
}
