/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: DocumentProperties.java,v $
 *
 *  $Revision: 1.3 $
 *
 *  last change: $Author: mib $ $Date: 2007/10/25 13:22:44 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.common.meta;

import java.io.IOException;
import java.io.InputStream;
import java.lang.Exception;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.TimeZone;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.openoffice.odf.OdfPackage;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author zhaoshen
 */
public class DocumentProperties {
    
    private static Document metaDoc;
    
    private class CreatorList extends ArrayList<Object>{
        public CreatorList(int capacity){
            super(capacity);
        }
        /**
         * Override the add method of List
         */
        public void add(int index,Object element){
            if(element!=null){
                if(element instanceof String){
                    super.add(index,element);
                    Element elem;
                    try {
                        elem = metaDoc.createElementNS("http://purl.org/dc/elements/1.1/","dc:creator");
                        Element refNode = (Element) metaDoc.getElementsByTagName("office:meta").item(0);
                        refNode.insertBefore(elem, null);
                        elem.setTextContent((String) element);
                    } catch (DOMException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
        public boolean addAll(int index,Collection<? extends Object> c){
            return  super.addAll(index,c);
        }
        public boolean remove(Object o){
            
            if(o!=null && o instanceof String){
                NodeList nodeList =  metaDoc.getElementsByTagName("dc:creator");
                if(super.remove(o)){
                    int i =0;
                    while(i<nodeList.getLength()){
                        if(o.toString().equals(nodeList.item(i).getTextContent())) {
                            metaDoc.getElementsByTagName("office:meta").item(0).removeChild(nodeList.item(i));
                            return true;
                        }
                        i++;
                    }
                }
                return false;
            } else{
                throw new IllegalArgumentException("please pass a string");
            }
        }
        
    }
    /** Creates a new instance of DocumentProperties */
    public DocumentProperties() {
    }
    /**
     * Creates a new instance from OdfPackage
     */
    public DocumentProperties(OdfPackage pkg) {
        create(pkg);
        
    }
    /**
     * Creates a new instance from inputstream
     */
    public DocumentProperties(InputStream is)
    throws IOException {
    }
    /**
     * create properties from OdfPackage
     */
    public static void create(OdfPackage pkg) {
        if(pkg==null){
            throw new NullPointerException("not a valid object");
        } else  if(pkg!=null){
            try {
                metaDoc = pkg.getDocument(pkg.STREAMNAME_META);
                
            } catch (IllegalArgumentException ex) {
                ex.printStackTrace();
            } catch (TransformerConfigurationException ex) {
                ex.printStackTrace();
            } catch (ParserConfigurationException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (SAXException ex) {
                ex.printStackTrace();
            } catch (TransformerException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    
    /**
     * get the first initial creator of the document
     */
    public String getInitialCreator() {
        String initial_Creator=null;
        if(this.getProperty("meta:initial_creator")!=null){
            String temp[] =this.getProperty("meta:initial_creator");
            initial_Creator = temp[0];
        }
        
        return initial_Creator;
    }
    /**
     * get the all the initial creators of the document, and return them as a array of String
     */
    public String[] getInitialCreators() {
        String initial_Creators[]=null;
        if(this.getProperty("meta:initial_creator")!=null){
            initial_Creators =this.getProperty("meta:initial_creator");
        }
        return initial_Creators;
    }
    public void setInitialCreator(String initial_Creator) {
        if(metaDoc.getElementsByTagName("meta:initial_creator").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:initial_creator");
        }
        if(metaDoc.getElementsByTagName("meta:initial_creator").getLength()>0){
            int length= metaDoc.getElementsByTagName("meta:initial_creator").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:initial_creator").item(i);
                element.setTextContent(initial_Creator);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the title of the document
     */
    public String getTitle() {
        String title = null;
        if(this.getProperty("dc:title")!=null){
            String temp[] =this.getProperty("dc:title");
            title =  temp[0];
        }
        return title;
    }
    
    public void setTitle(String title) {
        if(metaDoc.getElementsByTagName("dc:title").getLength()==0){
            this.addElement("http://purl.org/dc/elements/1.1/","dc:title");
        }
        if(metaDoc.getElementsByTagName("dc:title").getLength()>0){
            int length= metaDoc.getElementsByTagName("dc:title").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("dc:title").item(i);
                element.setTextContent(title);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the subjectr of the document
     */
    public String getSubject() {
        String subject = null;
        if(this.getProperty("dc:subject")!=null){
            String temp[] =this.getProperty("dc:subject");
            subject =  temp[0];
        }
        return subject;
    }
    
    public void setSubject(String subject) {
        if(metaDoc.getElementsByTagName("dc:subject").getLength()==0){
            this.addElement("http://purl.org/dc/elements/1.1/","dc:subject");
        }
        if(metaDoc.getElementsByTagName("dc:subject").getLength()>0){
            int length= metaDoc.getElementsByTagName("dc:subject").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("dc:subject").item(i);
                element.setTextContent(subject);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the description of the document
     */
    public String getDescription() {
        String description =null;
        if(this.getProperty("dc:description")!=null){
            String temp[] =this.getProperty("dc:description");
            description = temp[0];
        }
        return description;
    }
    
    public void setDescription(String description) {
        if(metaDoc.getElementsByTagName("dc:description").getLength()==0){
            this.addElement("http://purl.org/dc/elements/1.1/","dc:description");
        }
        if(metaDoc.getElementsByTagName("dc:description").getLength()>0){
            int length= metaDoc.getElementsByTagName("dc:description").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("dc:description").item(i);
                element.setTextContent(description);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the lastest date that the document was opened
     */
    public Date getDate() throws ParseException {
        Date date = null;
        if(this.getProperty("dc:date")!=null){
            String strDate[] =this.getProperty("dc:date");
            if(strDate.length>0)
                date = parseToDate(strDate[0]);
        }
        return date;
    }
    /**
     * get all the dates that the document was opened,and return a array of dates
     */
    public Date[] getDates() throws ParseException {
        Date date[] =null;
        if(this.getProperty("dc:date")!=null){
            String strDate[] =this.getProperty("dc:date");
            date =new Date[strDate.length];
            for(int i=0; i<strDate.length;i++)
                date[i] = parseToDate(strDate[i]);
        }
        return date;
    }
    /**
     * change the latest date that the document was opened
     */
    public void setDate(Date date) {
        if(metaDoc.getElementsByTagName("dc:date").getLength()==0){
            this.addElement("http://purl.org/dc/elements/1.1/","dc:date");
        }
        if(metaDoc.getElementsByTagName("dc:date").getLength()>0){
            int length = metaDoc.getElementsByTagName("dc:date").getLength();
            String eText = DateFormat.getDateTimeInstance().format(date);
            String[]  strArray = eText.split(" ");
            String dateStr =strArray[0]+"T"+strArray[1];
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("dc:date").item(i);
                element.setTextContent(dateStr);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the language appeared first in the languages used in the document
     */
    public String getLanguage() {
        String language =null;
        if(this.getProperty("dc:language")!=null){
            String temp[] =this.getProperty("dc:language");
            language= temp[0];
        }
        return language;
    }
    /**
     * get all the languages used in the document, and return a array of Strings
     */
    public String[] getLanguages() {
        String language[] =null;
        if(this.getProperty("dc:language")!=null)
            language =this.getProperty("dc:language");
        return language;
    }
    /**
     * change the language of the document
     */
    public void setLanguage(String language) {
        if(metaDoc.getElementsByTagName("dc:language").getLength()==0){
            this.addElement("http://purl.org/dc/elements/1.1/","dc:language");
        }
        if(metaDoc.getElementsByTagName("dc:language").getLength()>0){
            int length= metaDoc.getElementsByTagName("dc:language").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("dc:language").item(i);
                element.setTextContent(language);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the software used of the document
     */
    public String getGenerator() {
        String generator =null;
        if(this.getProperty("meta:generator")!=null){
            String temp[] =this.getProperty("meta:generator");
            generator = temp[0];
        }
        return generator;
        
    }
    /**
     * change the generator of the document
     */
    public void setGenerator(String generator) {
        if(metaDoc.getElementsByTagName("meta:generator").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:generator");
        }
        if(metaDoc.getElementsByTagName("meta:generator").getLength()>0){
            int length= metaDoc.getElementsByTagName("meta:generator").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:generator").item(i);
                element.setTextContent(generator);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the list of creators of the document
     */
    public CreatorList getCreator(){
        CreatorList creatorList = new CreatorList(0);
        if(metaDoc!=null){
            NodeList creList = metaDoc.getElementsByTagName("dc:creator");
            if(creList!=null){
                creatorList.ensureCapacity(creList.getLength());
                int i =0;
                while(i<creList.getLength()){
                    creatorList.add(creList.item(i++).getTextContent());
                }
            }
        }
        return creatorList;
    }
    /**
     * get the creating date of the document
     */
    public  Date getCreationDate() throws ParseException{
        Date creation_Date =null;
        if(metaDoc!=null){
            String crDate = metaDoc.getElementsByTagName("meta:creation-date").item(0).getTextContent();
            creation_Date = parseToDate(crDate);
        }
        return creation_Date;
    }
    public  Date[] getCreationDates() throws ParseException{
        Date creation_Date[] =null;
        if(this.getProperty("meta:creation-date")!=null){
            String crDate[] =this.getProperty("meta:creation-date");
            creation_Date =new Date[crDate.length];
            for(int i=0; i<crDate.length;i++)
                creation_Date[i] = parseToDate(crDate[i]);
        }
        return creation_Date;
    }
    
    /**
     * change the creating date of the document
     */
    public void setCreationDate(Date creation_Date) {
        if(metaDoc.getElementsByTagName("meta:creation-date").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:creation-date");
        }
        if(metaDoc.getElementsByTagName("meta:creation-date").getLength()>0){
            int length = metaDoc.getElementsByTagName("meta:creation-date").getLength();
            String eText = DateFormat.getDateTimeInstance().format(creation_Date);
            String[]  strArray = eText.split(" ");
            String crDateStr =strArray[0]+"T"+strArray[1];
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:creation-date").item(i);
                element.setTextContent(crDateStr);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the editing times of the document
     */
    public int getEditingCycles() {
        int editing_Cycles = 0 ;
        if(this.getProperty("meta:editing-cycles")!=null){
            String temp[] =this.getProperty("meta:editing-cycles");
            editing_Cycles=Integer.parseInt(temp[0]);
        }
        return editing_Cycles;
    }
    /**
     * change the editing times of the document
     */
    public void setEditingCycles(long editing_Cycles) {
        if(metaDoc.getElementsByTagName("meta:editing-cycles").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:editing-cycles");
        }
        if(metaDoc.getElementsByTagName("meta:editing-cycles").getLength()>0){
            int length= metaDoc.getElementsByTagName("meta:editing-cycles").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:editing-cycles").item(i);
                element.setTextContent(String.valueOf(editing_Cycles));
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the editing duration of the document
     */
    public long getEditingDuration() {
        long editing_Duration = 0;
        if(this.getProperty("meta:editing-duration")!=null){
            String tempStr =this.getProperty("meta:editing-duration")[0];
            StringBuffer strBuf = new StringBuffer(tempStr);
            /** handle the string to format the string to fulfil the process of
             * of reading the numbers out
             */
            if(!tempStr.contains("H")){
                strBuf.insert(strBuf.lastIndexOf("T")+1,"0H");
            }
            if(!tempStr.contains("M")){
                strBuf.insert(strBuf.lastIndexOf("H")+1,"0M");
            }
            if(!tempStr.contains("S")){
                strBuf.insert(strBuf.lastIndexOf("M")+1,"0S");
            }
            
            int second =0;
            int minute =0;
            int hour  =0;
            int index=0;
            // parse the intergers out of the string for hour, minute and second
            while(index<strBuf.length()){
                switch(strBuf.charAt(index)){
                    case 'H':
                        hour = Integer.parseInt(strBuf.substring(strBuf.indexOf("T")+1
                                ,strBuf.indexOf("H")));
                    case 'M':
                        minute =  Integer.parseInt(strBuf.substring(strBuf.indexOf("H")+1
                                ,strBuf.indexOf("M")));
                    case 'S':
                        second = Integer.parseInt(strBuf.substring(strBuf.indexOf("M")+1
                                ,strBuf.indexOf("S"))) ;
                    default:
                        index++;
                }
            }
            editing_Duration =hour*60*60+minute*60+second;
        }
        return editing_Duration;
    }
    /**
     * change the editing duration of the document
     */
    public void setEditingDuration(int editing_Duration) {
        if(metaDoc.getElementsByTagName("meta:editing-duration").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","editing-duration");
        }
        if(metaDoc.getElementsByTagName("meta:editing-duration").getLength()>0){
            
            int hour = editing_Duration/3600 ;
            int minute = editing_Duration%3600/60;
            int second = editing_Duration%3600%60;
            StringBuffer sb = new StringBuffer("T");
            String edstr = "T"+hour+"H"+minute+"M"+second+"S";
            int length= metaDoc.getElementsByTagName("meta:editing-duration").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:editing-duration").item(i);
                element.setTextContent(edstr);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the keyword of the document
     */
    public String getKeyword() {
        String keyword =null;
        if(this.getProperty("meta:keyword")!=null){
            String temp[] =this.getProperty("meta:keyword");
            keyword= temp[0];
        }
        return keyword;
    }
    /**
     * change the keyword of the document
     */
    public void setKeyword(String keyword) {
        if(metaDoc.getElementsByTagName("meta:keyword").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:keyword");
        }
        if(metaDoc.getElementsByTagName("meta:keyword").getLength()>0){
            int length= metaDoc.getElementsByTagName("meta:keyword").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:keyword").item(i);
                element.setTextContent(keyword);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the keyword of the document
     */
    public String[] getUserDefinedField() {
        
        String  urDf[] = this.getProperty("meta:user-defined");
        return urDf;
        
    }
    /**
     * get the person appeared first in the list of persons who printed the document
     */
    public String getPrintedBy() {
        String printedBy =null;
        if(this.getProperty("meta:printed-by")!=null){
            String temp[] =this.getProperty("meta:printed-by");
            printedBy = temp[0];
        }
        return  printedBy;
    }
    /**
     * get all the persons who printed the document
     */
    public String[] getPrintedBys() {
        String printedBy[] =null;
        if(this.getProperty("meta:printed-by")!=null)
            printedBy =this.getProperty("meta:printed-by");
        return printedBy;
    }
    /**
     * change the person who printed the document
     */
    public void setPrintedBy(String printedBy) {
        if(metaDoc.getElementsByTagName("meta:printed-by").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:printed-by");
        }
        if(metaDoc.getElementsByTagName("meta:printed-by").getLength()>0){
            int length= metaDoc.getElementsByTagName("meta:printed-by").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:printed-by").item(i);
                element.setTextContent(printedBy);
            }
            metaDoc.normalizeDocument();
        }
    }
    /**
     * get the date when the document was printed
     */
    public Date getPrintedDate() throws ParseException {
        Date ptDate = null;
        if(this.getProperty("meta:print-date")!=null){
            String temp[] =this.getProperty("meta:print-date");
            ptDate = parseToDate(temp[0]);
        }
        return ptDate;
    }
    /**
     * get all the dates that the document was opened,and return a array of dates
     */
    public Date[] getPrintedDates() throws ParseException {
        Date ptDate[] =null;
        if(this.getProperty("meta:print-date")!=null){
            String strDate[] =this.getProperty("meta:print-date");
            ptDate =new Date[strDate.length];
            for(int i=0; i<strDate.length;i++)
                ptDate[i] = parseToDate(strDate[i]);
        }
        return ptDate;
    }
    /**
     * change the lastest date that the document was printed
     */
    public void setPrintedDate(Date date) {
        if(metaDoc.getElementsByTagName("meta:print-date").getLength()==0){
            this.addElement("urn:oasis:names:tc:opendocument:xmlns:meta:1.0","meta:print-date");
        }
        if(metaDoc.getElementsByTagName("meta:print-date").getLength()>0){
            
            String eText = DateFormat.getDateTimeInstance().format(date);
            String[]  strArray = eText.split(" ");
            String dateStr =strArray[0]+"T"+strArray[1];
            int length= metaDoc.getElementsByTagName("meta:print-date").getLength();
            for(int i=0;i<length;i++){
                Element element = (Element) metaDoc.getElementsByTagName("meta:print-date").item(i);
                element.setTextContent(dateStr);
            }
            metaDoc.normalizeDocument();
        }
    }
    private Date parseToDate(String str) throws ParseException{
        Date date =null;
        str = str.replace("T"," ");
        date = DateFormat.getDateTimeInstance().parse(str);
        return date;
    }
    private String[] getProperty(String name){
        String  urDf[]=null;
        if(metaDoc!=null){
            NodeList urNodes = null;
            try {
                urNodes = metaDoc.getElementsByTagName(name);
            }catch(NullPointerException npe){
                System.out.println("null pooint");
                npe.printStackTrace();
            }
            if(urNodes.getLength()>0){
                urDf = new String[urNodes.getLength()];
                int i =0;
                while(i<urNodes.getLength()){
                    urDf[i] =urNodes.item(i++).getTextContent();
                }
                return urDf;
            }
        }
        return null;
    }
    private void addElement(String namespace,String name){
        Element element;
        try {
            element = metaDoc.createElementNS(namespace,name);
            Node parentNode =  metaDoc.getElementsByTagName("office:meta").item(0);
            parentNode.insertBefore(element, null);
        } catch (DOMException ex) {
            ex.printStackTrace();
        }
    }
}
