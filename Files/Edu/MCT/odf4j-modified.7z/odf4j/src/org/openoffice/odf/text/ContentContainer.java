package org.openoffice.odf.text;

public interface ContentContainer {
    
    
    
}
