/**************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OdtToText2.java,v $
 *
 *  $Revision: 1.5 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************
 * OdtToText2.java
 *
 * Created on 9 May, 2007, 11:52 PM
 *
 *ODT to Text Converter
 *
 */

package org.openoffice.odf.tools;

import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.*;
import org.openoffice.odf.text.*;

import java.util.Iterator;
import java.util.Collection;
import java.io.File;
import org.w3c.dom.Node;

import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;


/**
 *
 * @author Amit K Saha <amitsaha.in@gmail.com>
 *
 */

public class OdtToText2 {
    
    /** Creates a new instance of OdtToText2 */
    
    public OdtToText2() {
    }
    
    private void handleBlockElement(BlockElement blockElement ) {
        
        //System.err.println("size="+blockElements.size());
        Iterator iterator=blockElement.iterator();
        
        while ( iterator.hasNext() ) {
            Element element=(Element)iterator.next();
            
            
            try{
                
                System.out.println("Style of "+ element.getNode() +"=>" + element.getStyle());
                
            }catch(NullPointerException e){
                System.out.println("Exception Message" + e.getMessage());
            }
            
            
            if( element instanceof BlockElement) {
                
                if ( element instanceof ListItem ) {
                    System.out.print("  *  ");
                } else if ( element instanceof Heading ) {
                    System.out.print("==== ");
                }else if ( element instanceof Section ) {
                    System.out.print("### ");
                }else if (element instanceof UnknownElement){
                    System.out.print("@@@ ");
                }
                
                // this is where we recurse to handle child elements
                this.handleBlockElement((BlockElement)element);
                
                if ( element instanceof Heading ) {
                    System.out.println(" ====");
                } else if ( element instanceof Paragraph ) {
                    System.out.println("");
                }
                
            } else if ( element instanceof Portion ) {
                
                // something like this should output actual text in the document
                System.out.print(element.toString());
                
            } else {
                
                // debug not yet handled elements
                System.err.println("DEBUG unhandled elem is "+element.getClass().getName()+" node="+element.getNode().getNodeName());
            }
        }
    }
    
    
    public static void main(String argv[]){
        
        OdtToText2 obj = new OdtToText2();
        try{
            
            //OpenDocument openDocument = OpenDocumentFactory.load(new File("D:\\Current projects & Research\\ODF Toolkit-odf4j\\working-copy\\odftoolkit\\odf4j\\test\\testdocument1.odt"));
            OpenDocument openDocument = OpenDocumentFactory.load(new File("c:\\t2.odg"));//test/testdocument1.odt
            TextDocument textDoc = (TextDocument) openDocument;
            Body textBody = textDoc.getBody();
            obj.handleBlockElement(textBody);
            
        } catch(ClassCastException e) {
            System.out.println("Attempt to open a non-ODT file");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
}

