/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: ParagraphContentImpl.java,v $
 *
 *  $Revision: 1.5 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Stack;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;

import org.openoffice.odf.common.documenttype.ElementFactory;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.BlockElementImpl;

/**
 * Provides a view of the text portions in a paragraph
 */
class ParagraphContentImpl extends TextContentImpl implements EventListener {
    
    /*
     * portions are either text-children of the paragraph element or text
     * children of span elements in this paragraph.
     *
     */
    
    private TextContentFactory factory =null;
    private ArrayList<Element> list;
    
    ParagraphContentImpl(Node node) {
        super(node);
        factory = (TextContentFactory)super.getFactory();
        //factory.addElement(element.getNode(),element);
        rebuild();
        if (node instanceof EventTarget) {
            EventTarget t = (EventTarget) node;
            t.addEventListener("DOMSubtreeModified", this, false);
        }        
    }
        
    private void rebuild() {
        list = new ArrayList<Element>();
        // iterate the child nodes. a span starts a new text portion any other 
        // elemnt is a normal inline element
                
        final int STATE_START = 0;
        final int STATE_TEXT = 1;
        final int STATE_SPAN = 2;
        final int STATE_ELEM = 3;
        int state = 0;
        Stack<Node> stack = new Stack<Node>();
        BlockElement block = (BlockElement) factory.getElement(node);
        Node current = node.getFirstChild();        
        
        while (current != null) {
            if (current.getNodeType() == Node.TEXT_NODE) {
                if (state != STATE_TEXT) {                    
                    // this is the first text node in a new block or span 
                    state = STATE_TEXT;
                    Element e = factory.getInlineElement(current, block);
                    // don't add empty portions
                    if (e.toString().length()>0)
                        list.add(e);
                }                
                current = current.getNextSibling();
            } else if (current.getNodeType() == Node.ELEMENT_NODE) {
                if (current.getNamespaceURI().equals(Namespaces.text) && 
                    current.getLocalName().equals("span"))
                {
                    // entering a span
                    state = STATE_SPAN;
                    stack.push(current);
                    current = current.getFirstChild();
                } else {
                    // found another inline element
                    state = STATE_ELEM;
                    list.add(factory.getInlineElement(current, block));
                    current = current.getNextSibling();
                }
            }            
            if (current == null && !stack.empty()) {                
                current = ((Node) stack.pop()).getNextSibling();
            }
        }
    }
        
    public Element get(int index) {
        return list.get(index);
    }

    public int size() {
        return list.size();
    } 

    public void handleEvent(Event evt) {
        rebuild();
    }    
}
