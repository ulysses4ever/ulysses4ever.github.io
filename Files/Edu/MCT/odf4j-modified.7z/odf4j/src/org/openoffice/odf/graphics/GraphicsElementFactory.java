/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: GraphicsElementFactory.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.graphics;

import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.ElementFactory;

import org.openoffice.odf.text.TextContentFactory;

/**
 *
 * @author duyunfen
 */
public class GraphicsElementFactory extends ElementFactory{
    
    private TextContentFactory textfac = null;
    /** Creates a new instance of GraphicsElementFactory */
    public GraphicsElementFactory() {
          super();
          elementMap = new HashMap<Node,Element>();
    }
    public GraphicsElementFactory(Map<Node,Element> elemap){
        elementMap = elemap;
    }
    /**
     *get the textcontentfactory that inserted into graphics element.
     */
    public ElementFactory getTextInstance(){
        if (textfac == null)
            textfac = new TextContentFactory(elementMap);
        return textfac;
    }
    
    public ElementFactory getGraphicsInstance(){
        return this;
    }
    
    public Element getElement(Node node) {
        String name = node.getLocalName();
        String ns = node.getNamespaceURI();
        if (ns.equals(Namespaces.draw)) {
            if (name.equals("page")) {
                return getElement(node, Page.class);
            } else if (name.equals("rect")) {
                return getElement(node, Rectangle.class);
            } else if (name.equals("circle")) {
                return getElement(node, Circle.class);
            } else if (name.equals("line")) {
                return getElement(node,Line.class);
            }  else if (name.equals("customshape")) {
                return getElement(node,CustomShape.class );
            }  else if (name.equals("polygon")) {
                return getElement(node,Polygon.class);
            }  else if(name.equals("polyline")) {
                return getElement(node,Polyline.class);
            }  else if(name.equals("ellipse")){
                return getElement(node,Ellipse.class);
            } else if(name.equals("frame")){
                return getElement(node,Frame.class);
            } else if(name.equals("image")){
                return getElement(node,Image.class);
            }
        } else if(ns.equals(Namespaces.office)) {
            if (name.equals("drawing")){
                return getElement(node, Body.class);
            }else if(name.equals("forms")){
                return getElement(node,Forms.class);
            }else if(name.equals("automatic-styles")){
                return getElement(node,Style.class);
            }
        } else if (ns.equals(Namespaces.text)) {
            return getTextInstance().getElement(node);           
        } else if(ns.equals(Namespaces.style)) {//for testing
            return getElement(node,Style.class);
        }
        return getElement(node, UnknownElement.class);            
    }
    
    public Element getInlineElement(Node n, BlockElement block) {
        return null;
    }    
    
    /*create graphics element*/
    public Element createGraphics(Document doc, String name){
        Node node  = null;
        try {        
            node = doc.createElementNS(Namespaces.draw,name);
            return getElement(node);
        } catch (Exception ex) {
            return null;
        }
    } 
    
    /*create text*/ 
    public Text createText(Document doc,String content){
        Node node = null;
        try{
           node = doc.createElementNS(Namespaces.text,"text:p");
           Text text = new Text(node);
           //text.addText("text");
           return text;
        }catch (Exception ex){
            return null;
        }        
    }
    
    /*create forms*/ 
    public Forms createForms(Document doc,String formsname){
        Node node = null;
        try{
            node = doc.createElementNS(Namespaces.office,formsname);
            Forms form = new Forms(node);
            return form;
        }catch (Exception ex){
            return null;
        }        
    }
    
    /*create style for testing*/
   public Style createStyle(Document doc,String stylename){
       Node node = null;
        try{
            node = doc.createElementNS(Namespaces.style,stylename);
            Style style = new Style(node);
            return style;
        }catch (Exception ex){
            return null;
        }
    }    
    
   /*create individial graphic element*/     
    public static Page CreatePage(Document doc){
        Page p = null;
        try{
            Node node = doc.createElement("draw:page");
            p = new Page(node);
            }catch(Exception ex){
                return null;
        }
        return p;
    }
    
    public static GluePoint CreateGluePoint(Document doc){
        GluePoint gpt = null;
        //try{
         //   Node node = doc.Create
        //}
        return gpt;
    }
    
    public static Circle CreateCircle(Document doc){
        Circle circle = null;
        try{
            Node node = doc.createElement("draw:circle");
            circle = new Circle(node);
            }catch(Exception ex){
                return null;
        }
        return circle;
    }
    
    public static Rectangle CreateRectangle(Document doc){
        Rectangle rec = null;
        try{
            Node node = doc.createElement("draw:rect");
            rec = new Rectangle(node);
            }catch(Exception ex){
                return null;
        }   
        return rec;
    }
    
    public static Line CreateLine(Document doc){
        Line line = null;
        try{
            Node node = doc.createElement("draw:line");
            line = new Line(node);
            }catch(Exception ex){
                return null;
        }
        return line;
    }
    
    public static Polygon CreatePolygon(Document doc){
        Polygon pol = null;
        try{
            Node node = doc.createElement("draw:polygon");
            pol = new Polygon(node);
            }catch(Exception ex){
                return null;
        }        
        return pol;
    }
}
