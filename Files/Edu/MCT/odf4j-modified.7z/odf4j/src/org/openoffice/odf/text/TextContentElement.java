/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: TextContentElement.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.ElementFactory;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;

import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Attr;
import org.w3c.dom.NodeList;

import java.util.List;
import java.io.Reader;
import java.io.StringReader;

/**
 *
 * @author duyunfen
 */
public class TextContentElement extends BlockElement{
    
    /** Creates a new instance of TextContentElement */
    public TextContentElement() {
        super();
    }
    
    public TextContentElement(Node node) {
       attach(node);
  }        
    
    protected void attach(Node node){
        attach(node,new TextContentImpl(node));       
    }
    
    protected void attach(Node node,List<Element> contentList){
        super.attach(node,contentList);
        ElementFactory fac = getFactory(node.getOwnerDocument());
        fac.addElement(node, this);        
    }
    
    /**
     *get textcontentElement's factory associated with current document.
     */
    public ElementFactory getFactory(Document doc){
        ElementFactory fac = null;
        fac = ElementFactory.getInstance(doc,TextContentFactory.class);
        if ((fac != null) && !(fac instanceof TextContentFactory)){
               fac =  fac.getTextInstance();
            }
        return fac;
    }
    
    /**
     *create textcontentelement  
     */
    protected TextContentElement(OpenDocument od, String name){
        Node node  = null;
        try {        
            Document doc = od.getDocument(OpenDocument.STREAMNAME_CONTENT);
            node = doc.createElementNS(Namespaces.text,name);
            attach(node);
        } catch (Exception ex) {     
            throw new RuntimeException("FIXME!!!");
        }        
    }
  
    public Element getParent() {
       ElementFactory fac = null; 
       Node node = getNode();
       fac = getFactory(node.getOwnerDocument());
       return fac.getElement(node.getParentNode());
    }  
    
    public String getStyle() {
        NamedNodeMap map = getNode().getAttributes();
        Node attr = map.getNamedItem("text:style-name");
        // if there is a text:style-name attribute return its value, null otherwise
        if (attr != null) {
            return attr.getNodeValue();
        } else {
            return null;
        }
    }

    /** ������������� ������ �� ��� ����� (�� �� ������ ��� �����) <br>
     * �������� Eliseev */
    public void setStyle(Style style) {
        Attr a = getNode().getOwnerDocument().createAttributeNS(Namespaces.text, "text:style-name");
	a.setNodeValue(style.getName());
	getNode().getAttributes().setNamedItem(a);
    }
    
      
}
