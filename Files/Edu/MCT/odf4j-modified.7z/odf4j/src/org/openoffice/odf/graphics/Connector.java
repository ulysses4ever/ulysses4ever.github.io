/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Connector.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.graphics;
import org.w3c.dom.Node;
import java.awt.Point;
import org.openoffice.odf.OpenDocument;
/**
 *
 * @author duyunfen
 */
public class Connector extends GraphicElement{
    
    /** Creates a new instance of Connector */
    public Connector() {
    }
    
    public Connector(Node node){
        super(node);
    }
    public Connector(OpenDocument od){
        super(od,"draw:connector");
    }
    
    public String getDrawType(){
        return getAttriStringValue("draw:type");
   }        
    
    public Point getStartPosition(){
        return getAttriPointValue("svg:x1","svg:y1");
    }
    
    public Point getEndPosition(){
        return getAttriPointValue("svg:x2","svg:y2");
    }
    
    public String getStartShape(){
        return getAttriStringValue("draw:start-shape");
    }
    
    public String getEndShape(){
        return getAttriStringValue("draw:end-shape");
    }
    
    public int getStartGluePointId(){
        return getAttriIntValue("draw:start-glue-point");
    }
    
    public int getEndGluePointId(){
        return getAttriIntValue("draw:end-glue-point");
    }
}
