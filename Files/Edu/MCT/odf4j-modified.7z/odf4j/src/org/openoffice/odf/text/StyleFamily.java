/*
 * StyleFamily.java
 *
 * Created on 16 June, 2007, 10:32 AM
 *
 * 
 */

package org.openoffice.odf.text;

/**
 *
 * @author amitksaha <amitsaha.in@gmail.com>
 */
public class StyleFamily {
    
    /** Creates a new instance of StyleFamily */
    public StyleFamily() {
    }
    
}
