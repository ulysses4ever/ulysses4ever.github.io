/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OdfPackage.java,v $
 *
 *  $Revision: 1.20 $
 *
 *  last change: $Author: mib $ $Date: 2007/10/25 13:22:45 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.PipedOutputStream;
import java.io.PipedInputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.CRC32;
import java.util.StringTokenizer;
import java.util.List;
import java.util.LinkedList;
import java.util.Hashtable;
import java.util.Iterator;
import javax.imageio.ImageIO;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import org.openoffice.odf.common.meta.DocumentProperties;
import org.xml.sax.XMLReader;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.URIResolver;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.JarURLConnection;
import org.w3c.dom.Document;

import org.openoffice.odf.manifest.FileEntry;
import org.openoffice.odf.manifest.EncryptionData;
import org.openoffice.odf.manifest.KeyDerivation;
import org.openoffice.odf.manifest.Algorithm;

import org.openoffice.odf.xml.OdfXMLHelper;
import org.openoffice.odf.xml.OdfPackageStream;

import org.openoffice.odf.util.TempDir;
import org.openoffice.odf.util.TempDirDeleter;

/**
 * Handling OpenDocument Packages
 * instances of this class are not created directly
 * but via OpenDocumentFactory class
 */
public class OdfPackage {

    // global parent Directory for tempDirs
    private static File _tempDirParent = null;

    // temp Dir for this ODFpackage
    private File _tempDir=null;

    // some well known streams inside ODF packages
    public static final String STREAMNAME_CONTENT = "content.xml";
    public static final String STREAMNAME_STYLE = "styles.xml";
    public static final String STREAMNAME_META = "meta.xml";
    public static final String STREAMNAME_SETTINGS = "settings.xml";
    public static final String STREAMNAME_MANIFEST = "META-INF/manifest.xml";    
    public static final String STREAMNAME_DOCUMENT_SIGNATURES = "META-INF/documentsignatures.xml";    
    public static final String STREAMNAME_MACRO_SIGNATURES = "META-INF/macrosignatures.xml";    

    private String _mimetype;
    private byte[] _digest;
    private List<String> _entries;
    private Hashtable<String,ZipEntry> _zipEntries;
    private Hashtable<String,byte[]> _contents;
    private Hashtable<String,File> _tempFiles;
    private Hashtable<String,Document> _doms;
    private List<String> _manifestList;
    private Hashtable<String,FileEntry> _manifestEntries;
    private String _baseURI;
    private Resolver _resolver;
    private ErrorHandler _errorHandler;

    private boolean _isMimetypeValid=true;
    private boolean _hasEncryptedContent=false;

    private class StoreContentOutputStream extends ByteArrayOutputStream {
        private ZipEntry zipEntry;

        public StoreContentOutputStream(ZipEntry zipEntry) {
            super();
            this.zipEntry=zipEntry;
        }

        public void close()
            throws IOException {

            byte[] content=toByteArray();
            if ( zipEntry != null ) {
                store(zipEntry,content);  
            }
        }

    }

    private class StoreTempOutputStream extends OutputStream {
        private ZipEntry zipEntry;
        private File tempFile;
        OutputStream os;
        private String mediaType;

        public StoreTempOutputStream(ZipEntry zipEntry) 
            throws IOException {

            super();
            this.zipEntry=zipEntry;
            String fname=zipEntry.getName();
            if ( File.separatorChar == '\\' ) {
                fname=fname.replaceAll("\\\\","/");
            }
            tempFile=new File(getTempDir(),fname);
            File parent=tempFile.getParentFile();
            parent.mkdirs();
            os=new BufferedOutputStream(new FileOutputStream(tempFile));
        }

        public void write(byte[] b)
            throws IOException {

            os.write(b);
        }

        public void write(byte[] b,int off, int len)
            throws IOException {

            os.write(b,off,len);
        }
        
        public void write(int b)
            throws IOException {

            os.write(b);
        }

        public void close()
            throws IOException {
            
            os.close();
            if ( zipEntry != null ) {
                store(zipEntry,tempFile);
            }
        }
    }


    private class ManifestContentHandler implements ContentHandler {

        private FileEntry _currentFileEntry;
        private EncryptionData _currentEncryptionData;

        /**
         * Receive an object for locating the origin of SAX document events.
         */
        public void setDocumentLocator(Locator locator) {
        }

        /**
         * Receive notification of the beginning of a document. 
         */   
        public void startDocument() throws SAXException {
            _manifestList=new LinkedList<String>();
            _manifestEntries = new Hashtable<String,FileEntry>();
            _hasEncryptedContent=false;
        }

        /**
         * Receive notification of the end of a document.
         */
        public void endDocument() throws SAXException {
        }

        /**
         * Begin the scope of a prefix-URI Namespace mapping.
         */   
        public void startPrefixMapping(String prefix, String uri) 
            throws SAXException {
        }

        /**
         * End the scope of a prefix-URI mapping. 
         */   
        public void endPrefixMapping(String prefix)
            throws SAXException {
        }

        /**
         * Receive notification of the beginning of an element.
         */  
        public void startElement(String namespaceURI, String localName, String qName, Attributes atts) 
            throws SAXException {
            
            if ( localName.equals("file-entry") ) {
                _currentFileEntry=new FileEntry();
                _currentFileEntry.setPath(atts.getValue("manifest:full-path"));
                _currentFileEntry.setMediaType(atts.getValue("manifest:media-type"));
                if ( atts.getValue("manifest:size") != null ) {
                    try {
                        _currentFileEntry.setSize(Integer.parseInt(atts.getValue("manifest:size")));
                    } catch (NumberFormatException nfe) {
                        throw new SAXException("not a number: "+atts.getValue("manifest:size"));
                    }
                }
            } else if (localName.equals("encryption-data") ) {
                _hasEncryptedContent=true;
                _currentEncryptionData=new EncryptionData();
                if ( _currentFileEntry != null ) {
                    _currentEncryptionData.setChecksumType(atts.getValue("manifest:checksum-type"));
                    _currentEncryptionData.setChecksum(atts.getValue("manifest:checksum"));
                    _currentFileEntry.setEncryptionData(_currentEncryptionData);
                }
            } else if (localName.equals("algorithm") ) {
                Algorithm algorithm=new Algorithm();
                algorithm.setName(atts.getValue("manifest:algorithm-name"));
                algorithm.setInitializationVector(atts.getValue("manifest:initialization-vector"));
                if ( _currentEncryptionData != null ) {
                    _currentEncryptionData.setAlgorithm(algorithm);
                }
            } else if (localName.equals("key-derivation") ) {
                KeyDerivation keyDerivation=new KeyDerivation();
                keyDerivation.setName(atts.getValue("manifest:key-derivation-name"));
                keyDerivation.setSalt(atts.getValue("manifest:salt"));
                if ( atts.getValue("manifest:iteration-count") != null ) {
                    try {
                        keyDerivation.setIterationCount(Integer.parseInt(atts.getValue("manifest:iteration-count")));
                    } catch (NumberFormatException nfe) {
                        throw new SAXException("not a number: "+atts.getValue("manifest:iteration-count"));
                    }
                }
                if ( _currentEncryptionData != null ) {
                    _currentEncryptionData.setKeyDerivation(keyDerivation);
                }
            }

        }

        /**
         * Receive notification of the end of an element.
         */
        public void endElement(String namespaceURI, String localName, String qName)
            throws SAXException {
            if ( localName.equals("file-entry") ) {
                if ( _currentFileEntry.getPath() != null ) {
                    _manifestEntries.put(_currentFileEntry.getPath(),_currentFileEntry);
                }
                _manifestList.add(_currentFileEntry.getPath());
                _currentFileEntry=null;
            } else if (localName.equals("encryption-data") ) {
                _currentEncryptionData=null;
            }
        }

        /**
         * Receive notification of character data. 
         */
        public void characters(char[] ch, int start, int length)
            throws SAXException {
        }
	          
        /**
         * Receive notification of ignorable whitespace in element content.
         */
        public void ignorableWhitespace(char[] ch, int start, int length)
            throws SAXException {
        }
           
        /**
         * Receive notification of a processing instruction.
         */
        public void processingInstruction(String target, String data) 
            throws SAXException {
        }
                  
        /**
         * Receive notification of a skipped entity.
         */   
        public void skippedEntity(String name) throws SAXException {
        }
    }

    /**
     * resolve external entities
     */
    private class Resolver implements EntityResolver, URIResolver {

        /**
         * Resolver constructor.
         */
        public Resolver() {
        }

        /**
         * Allow the application to resolve external entities.
         *
         * The Parser will call this method before opening any external entity except
         * the top-level document entity (including the external DTD subset,
         * external entities referenced within the DTD, and external entities referenced
         * within the document element): the application may request that the parser
         * resolve the entity itself, that it use an alternative URI,
         * or that it use an entirely different input source.
         */
        public InputSource resolveEntity(String publicId, String systemId)
            throws SAXException, IOException {

            if ( systemId != null) {
                if ( (_baseURI != null) && systemId.startsWith(_baseURI) ) {
                    if ( systemId.equals(_baseURI) ) {
                        InputStream in=null;
                        try {
                            in=getInputStream();
                        } catch (Exception e) {
                            throw new SAXException(e);
                        }
                        InputSource ins;
                        ins=new InputSource(in);
                        
                        if ( ins == null ) {
                            return null;
                        }
                        ins.setSystemId(systemId);
                        return ins;
                    } else {
                        if ( systemId.length() > _baseURI.length()+1 ) {
                            String path=systemId.substring(_baseURI.length()+1);
                            InputStream in=getInputStream(path);
                            InputSource ins=new InputSource(in);
                            ins.setSystemId(systemId);
                            return ins;
                        }
                        return null;
                    }
                } else if ( systemId.startsWith("resource:/") ) {
                    int i=systemId.indexOf('/');
                    if ( (i > 0) && systemId.length() > i+1 ) { 
                        String res=systemId.substring(i+1);
                        ClassLoader cl=OdfPackage.class.getClassLoader();
                        InputStream in=cl.getResourceAsStream(res);
                        if ( in != null ) {
                            InputSource ins=new InputSource(in);
                            ins.setSystemId(systemId);
                            return ins;
                        }
                    }
                    return null;
                } else if ( systemId.startsWith("jar:") ) {
                    try {
                        URL url=new URL(systemId);
                        JarURLConnection jarConn = (JarURLConnection)url.openConnection();
                        InputSource ins=new InputSource(jarConn.getInputStream());
                        ins.setSystemId(systemId);
                        return ins;
                    } catch(MalformedURLException me){
                        throw new SAXException(me); // Incorrect URL format used
                    }
                }
            }
            return null;
        }

        public Source resolve(String href, String base) 
        throws TransformerException {
            try {
                URI uri=null;
                if ( base != null ) {
                    URI baseuri=new URI(base);
                    uri=baseuri.resolve(href);
                } else {
                    uri=new URI(href);
                }

                InputSource ins=null;
                try {
                    ins=resolveEntity(null,uri.toString());
                } catch (Exception e) {
                    throw new TransformerException(e);
                }
                if ( ins == null ) {
                    return null;
                }
                InputStream in=ins.getByteStream();
                StreamSource src=new StreamSource(in);
                return src;
            } catch ( URISyntaxException use ) {
                return null;
            }
        }
    }

    /**
     * creates an empty package
     */
    public OdfPackage() {
        clear();
    }

    /**
     * create package from file stored at give path
     *
     * @param path - the path to the file
     */
    public OdfPackage(String path) 
        throws IOException {

        load(path);
    }


    /**
     * create package from file stored at give path
     *
     * @param path - the path to the file
     * @param keepUnparsedManifest - do not parse the Manifest just keep it's content unparsed internally
     * @param ignoreBinaryContent - binary content is not stored internally. Note that this content
     *                             than is also not available when you call save afterwards.
     */
    public OdfPackage(String path, boolean keepUnparsedManifest, boolean ignoreBinaryContent)
        throws IOException {

        load(path, keepUnparsedManifest, ignoreBinaryContent);
    }

    /**
     * create package from file stored at give File
     *
     * @param file - a File to load content from
     */
    public OdfPackage(File file)
        throws IOException {

        load(file);
    }

    /**
     * create package from file stored at give File
     *
     * @param file - a File to load content from
     * @param keepUnparsedManifest - do not parse the Manifest just keep it's content unparsed internally
     * @param ignoreBinaryContent - binary content is not stored internally. Note that this content
     *                             than is also not available when you call save afterwards.
     */
    public OdfPackage(File file, boolean keepUnparsedManifest, boolean ignoreBinaryContent)
        throws IOException {

        load(file, keepUnparsedManifest, ignoreBinaryContent);
    }

    /**
     * create package from InputStream
     *
     * @param is - the InputStream to load from
     * @param baseURI - a URI for the document loaded
     */
    public OdfPackage(InputStream is, String baseURI)
        throws IOException {

        load(is, baseURI);
    }

    /**
     * create package from InputStream
     *
     * @param is - the InputStream to load from
     * @param baseURI - a URI for the document loaded
     * @param keepUnparsedManifest - do not parse the Manifest just keep it's content unparsed internally
     * @param ignoreBinaryContent - binary content is not stored internally. Note that this content
     */
    public OdfPackage(InputStream is, String baseURI, boolean keepUnparsedManifest, boolean ignoreBinaryContent)
        throws IOException {

        load(is, baseURI, keepUnparsedManifest, ignoreBinaryContent);
    }


    /**
     * Copy constructor
     */
    public OdfPackage(OdfPackage pkg) {
        _mimetype=pkg._mimetype;
        _isMimetypeValid=pkg._isMimetypeValid;
        if ( pkg._digest == null ) {
            _digest=null;
        } else {
            _digest=new byte[pkg._digest.length];
            for (int i=0; i<pkg._digest.length; i++) {
                _digest[i]=pkg._digest[i];
            }
        }
        _entries=new LinkedList<String>(pkg._entries);
        _zipEntries=new Hashtable<String,ZipEntry>(pkg._zipEntries);
        _contents=new Hashtable<String,byte[]>(pkg._contents);
        _tempFiles=new Hashtable<String,File>(pkg._tempFiles);
        _doms=new Hashtable<String,Document>(pkg._doms);
        _manifestList=new LinkedList<String>(pkg._manifestList);
        if ( pkg._manifestEntries != null ) {
            _manifestEntries=new Hashtable<String,FileEntry>(pkg._manifestEntries);
        }
        _baseURI=new String(pkg._baseURI);
        _tempDir=pkg._tempDir;
        TempDir.ref(_tempDir);

        _isMimetypeValid=pkg._isMimetypeValid;
        _hasEncryptedContent=pkg._hasEncryptedContent;
    }


    /**
     * set the baseURI for this package
     */
    public void setBaseURI(String baseURI) {
        _baseURI=baseURI;
    }


    /**
     * get the baseURI
     */
    public String getBaseURI() {
        return _baseURI;
    }

    /**
     * Removes all content, resets to not password protected
     * <p>This basically transforms the ODFPackage to an empty Package</p>
     */
    public void clear() {
        _mimetype=null;
        _digest=null;
        _entries=new LinkedList<String>();
        _zipEntries=new Hashtable<String,ZipEntry>();
        _contents=new Hashtable<String,byte[]>();
        _tempFiles=new Hashtable<String,File>();
        _doms=new Hashtable<String,Document>();
        _manifestList=new LinkedList<String>();
        _manifestEntries=null;
        
        if ( _tempDir != null ) {
            TempDir.release(_tempDir);
            _tempDir=null;
        }
    }

    /**
     * close this OdfPackage
     */
    public void close() {
        clear();
    }

    /**
     * get the mimetype
     */
    public String getMimetype() {
        return _mimetype;
    }

    /**
     * set the mimetype
     */
    public void setMimetype(String mimetype) {
        _mimetype=mimetype;
        if ( _mimetype == null ) {
            _entries.remove("mimetype");
        } else {
            if ( ! _entries.contains("mimetype") ) {
                _entries.add(0,"mimetype");
            }
        }
    }
    
    /**
     * set a password, NOT YET IMPLEMENTED
     * <p>use null to reset to not password protected</p>
     */
    public void setPassword(String password) {
        if ( password == null ) {
            _digest=null;
            return;
        }
        throw new RuntimeException("not yet implemented");
    }

    /**
     * check password, NOT YET IMPLEMENTED
     */
    public boolean checkPassword(String password) {
        throw new RuntimeException("not yet implemented");
    }

    /**
     * check wether the package is password protected
     */
    public boolean isPasswordProtected() {
        return _digest != null;
    }

    /**
     * get FileEntry for path
     */
    public FileEntry getFileEntry(String path) {
        if ( _manifestEntries == null ) {
            try {
                parseManifest();
            } catch ( Exception e ) {
                throw new RuntimeException(e);
            }
        }
        if ( _manifestEntries == null ) {
            return null;
        }
        return (FileEntry)_manifestEntries.get(path);
    }

    /**
     * check wether the file contains some encrypted content
     */
    public boolean hasEncryptedContent() {

        if ( _manifestEntries == null ) {
            try {
                parseManifest();
            } catch ( Exception e ) {
                throw new RuntimeException(e);
            }
        }

        return _hasEncryptedContent;
    }


    /**
     * Save to given path
     *
     * @param path - the path to the file
     */
    public void save(String path) 
        throws IOException {

        File f=new File(path);
        save(f);
    }

    /**
     * Save to File
     *
     * @param file - a File to store content to
     *
     */
    public void save(File file) 
        throws IOException { 

        FileOutputStream fos=new FileOutputStream(file);
        String baseURI=file.getCanonicalFile().toURI().toString();
        if ( File.separatorChar == '\\' ) {
            baseURI=baseURI.replaceAll("\\\\","/");
        }
        save(fos,baseURI);
    }

    /**
     * Save to OutputStream
     *
     * @param os - the OutputStream to store content to
     * @param baseURI - a URI for the document to be stored
     */
    public void save(OutputStream os, String baseURI) 
        throws IOException {

        _isMimetypeValid=true;
        _baseURI=baseURI;

        if ( _manifestEntries == null ) {
            try {
                parseManifest();
            } catch ( Exception e ) {
                throw new RuntimeException(e);
            }
        }

        FileEntry slashEntry=(FileEntry)_manifestEntries.get("/");
        if ( slashEntry==null ) {
            slashEntry=new FileEntry("/",_mimetype);
            _manifestList.add(0,slashEntry.getPath());
        } else {
            slashEntry.setMediaType(_mimetype);
        }

        ZipOutputStream zos=new ZipOutputStream(os);
        long modTime=(new java.util.Date()).getTime();
        
        Iterator it=_entries.iterator();
        while ( it.hasNext() ) {
            String key=(String)it.next();
            byte[] data=getData(key);
            
            ZipEntry ze=(ZipEntry)_zipEntries.get(key);
            if ( ze == null ) {
                ze=new ZipEntry(key);
            }
            ze.setTime(modTime);

            if ( key.equals("mimetype") || key.equals("meta.xml") ) {
                ze.setMethod(ZipEntry.STORED);
            } else {
                ze.setMethod(ZipEntry.DEFLATED);
            }

            CRC32 crc = new CRC32();
            if ( data != null ) {
                crc.update(data);
                ze.setSize(data.length);
            } else {
                ze.setMethod(ZipEntry.STORED);
                ze.setSize(0);
            }
            ze.setCrc(crc.getValue());
            ze.setCompressedSize(-1);
            zos.putNextEntry(ze);
            if ( data != null ) {
                zos.write(data,0,data.length);
            }
            zos.closeEntry();
            
            _zipEntries.put(key,ze);

        }

        zos.close();

        os.flush();
    }

    /**
     * Load from given path
     *
     * @param path - the path to the file
     */
    void load(String path) 
        throws IOException {

        File f=new File(path);
        load(f);
    }

    /**
     * Load from given path
     *
     * @param path - the path to the file
     * @param keepUnparsedManifest - do not parse the Manifest just keep it's content unparsed internally
     * @param ignoreBinaryContent - binary content is not stored internally. Note that this content
     *                             than is also not available when you call save afterwards.
     */
    void load(String path, boolean keepUnparsedManifest, boolean ignoreBinaryContent) 
        throws IOException {

        File f=new File(path);
        load(f, keepUnparsedManifest, ignoreBinaryContent);
    }

    /**
     * load from given File
     *
     * @param file - a File to load content from
     */
    void load(File file) 
        throws IOException {
        load(file, false, false);
    }
        
    /**
     * load from given File
     * 
     * <p>Note that for the keepManifest parameter being set to true
     *    keeping the Manifest unparsed is only a temporary situation
     *    to be used to get the content of the Manifest file without parsing it directly
     *    after calling this method, eg. for validating.</p>
     *
     * <p>As soon as information from the Manifest would be modified or even accessed only
     *    by other methods of this class the Manifest will be parsed.</p>
     *
     * <p>In case of that there is an Error in the Manifest file this would lead
     *    to RuntimeExceptions being thrown by such methods during late parsing of the 
     *    Manifest file.</p>
     *
     * @param file - a File to load content from
     * @param keepUnparsedManifest - do not parse the Manifest just keep it's content unparsed internally
     * @param ignoreBinaryContent - binary content is not stored internally. Note that this content
     *                             than is also not available when you call save afterwards.
     */
    void load(File file, boolean keepUnparsedManifest, boolean ignoreBinaryContent) 
        throws IOException {

        FileInputStream fos=new FileInputStream(file);
        String baseURI=file.getCanonicalFile().toURI().toString();
        if ( File.separatorChar == '\\' ) {
            baseURI=baseURI.replaceAll("\\\\","/");
        }
        load(fos, baseURI, keepUnparsedManifest, ignoreBinaryContent);
    }
    
    /**
     * Load from given InputStream
     *
     * @param is - the InputStream to load from
     * @param baseURI - a URI for the document loaded
     */
    void load(InputStream is, String baseURI)
        throws IOException {

        load(is, baseURI, false, false);
    }

    /**
     * Load from given InputStream
     * 
     * @param is - the InputStream to load from
     * @param baseURI - a URI for the document loaded
     * @param keepUnparsedManifest - do not parse the Manifest just keep it's content unparsed internally
     * @param ignoreBinaryContent - binary content is not stored internally. Note that this content
     *                             than is also not available when you call save afterwards.
     */
    void load(InputStream is, String baseURI, boolean keepUnparsedManifest, boolean ignoreBinaryContent )
        throws IOException {
       
        int zipcnt=0;

        clear();
        _baseURI=baseURI;
        ZipInputStream zin=new ZipInputStream(is);
        _isMimetypeValid=false;

        try {
            ZipEntry zipe;
            boolean bFirst=true;
            while ( (zipe=zin.getNextEntry()) != null ) {
                zipcnt++;
                if ( zipe.isDirectory() ) {
                    store(zipe,(byte[])null);
                } else {
                    OutputStream os=null;
                    if ( zipe.getName().endsWith(".xml") || zipe.getName().equals("mimetype") ) {
                        if ( zipe.getName().equals("mimetype") ) {
                            _isMimetypeValid=bFirst && (zipe.getMethod() == ZipEntry.STORED);
                        }
                        os=new StoreContentOutputStream(zipe);
                    } else if ( ! ignoreBinaryContent ) {
                        os=new StoreTempOutputStream(zipe);
                    }
                    if ( os != null ) {
                        byte[] buf=new byte[4096];
                        int r=0;
                        while ( (r=zin.read(buf,0,4096)) > -1 ) {
                            os.write(buf,0,r);
                        }
                        os.close();
                    }
                }
                bFirst=false;
            }
            if ( ! keepUnparsedManifest ) {
                parseManifest();
            }
            decryptAll();
            zin.close();

            if ( zipcnt==0 ) {
                throw new IOException("File is not a ZIP file or empty!");
            }

        } catch ( SAXException se ) {
            throw new IOException("SAXException:"+se.getMessage());
        } catch (ParserConfigurationException pce ) {
            throw new IOException("ParserConfigurationException:"+pce.getMessage());
        } catch (TransformerConfigurationException tce ) {
            throw new IOException("TransformerConfigurationException:"+tce.getMessage());
        } catch (TransformerException te ) {
            throw new IOException("TransformerException:"+te.getMessage());
        }
    }

    /**
     * get EntityResolver to be used in XML Parsers
     * which can resolve content inside the OdfPackage
     */
    public EntityResolver getEntityResolver() {
        if ( _resolver == null ) {
            _resolver=new Resolver();
        }
        return _resolver;
    }


    /**
     * get URIResolver to be used in XSL Transformations
     * which can resolve content inside the OdfPackage
     */
    public URIResolver getURIResolver() {
        if ( _resolver == null ) {
            _resolver=new Resolver();
        }
        return _resolver;
    }

    public DocumentProperties getDocumentProperties() {
        return new DocumentProperties(this);
    }
    
    /**
     * get org.w3c.dom.Document for XML file contained in package
     */
    public Document getDocument(String path) 
        throws SAXException, ParserConfigurationException,
               IOException, IllegalArgumentException,
               TransformerConfigurationException, TransformerException {

        Document doc=(Document)_doms.get(path);
        if (  doc != null ) {
            return doc;
        }

        InputStream is=getXMLInputStream(path);
        
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware( true );
        factory.setValidating( false );
        
        DocumentBuilder builder=factory.newDocumentBuilder();
        builder.setEntityResolver(getEntityResolver());

        String uri=_baseURI+path;

        if ( _errorHandler != null ) {
            builder.setErrorHandler(_errorHandler);
        }
        
        InputSource ins=new InputSource(is);
        ins.setSystemId(uri);
        
        doc=builder.parse(ins);

        if ( doc != null ) {
            _doms.put(path,doc);
            _contents.remove(path);
        }

        return doc;
    }

    /**
     * returns true if a DOM tree has been requested 
     * for given sub-content of OdfPackage
     */
    public boolean hasDOM(String path) {
        return (_doms.get(path) != null );
    }

    /**
     * get Stream for XML Subcontent
     *
     * @throws IllegalArgumentException 
     * if filetype of subcontent is not text/xmlo
     */
    public InputStream getXMLInputStream(String path) 
        throws IOException {

        if ( path.equals("META-INF/manifest.xml") ) {
            if ( _contents.get(path) == null ) {
                throw new IOException(_baseURI+": "+path+" not found in package");
            }
        } else {
            if ( _manifestEntries == null ) {
                try {
                    parseManifest();
                } catch ( Exception e ) {
                    throw new RuntimeException(e);
                }
            }

            FileEntry fileEntry=(FileEntry)_manifestEntries.get(path);
            if ( fileEntry == null ) {
                throw new IOException(_baseURI+": "+path+" not found in package");
            }
            if ( ! "text/xml".equals(fileEntry.getMediaType()) ) {
                throw new IllegalArgumentException(_baseURI+": "+path+" is not of type text/xml");
            }
        }
        InputStream is=getInputStream(path);
        if ( is == null ) {
            throw new IOException(_baseURI+": "+path+" not found in package");
        }
        return is;
    }
    

    /**
     * data was updated, update zipEntry and FileEntry as well
     */
    private void entryUpdate(String path) 
        throws IOException, SAXException,
               TransformerConfigurationException,TransformerException,
               ParserConfigurationException {

        byte[] data=getData(path);
        int size=0;
        if ( data == null ) {
            size=0;
        } else {
            size=data.length;
        }
        if ( _manifestEntries == null ) {
            try {
                parseManifest();
            } catch ( Exception e ) {
                throw new RuntimeException(e);
            }
        }
        FileEntry fileEntry=(FileEntry)_manifestEntries.get(path);
        ZipEntry zipEntry=(ZipEntry)_zipEntries.get(path);
        if ( zipEntry==null ) {
            return;
        }
        if ( fileEntry != null ) {
            if ( "text/xml".equals(fileEntry.getMediaType()) ) {
                fileEntry.setSize(-1);
            } else {
                fileEntry.setSize(size);
            }
        }
        zipEntry.setSize(size);
        CRC32 crc = new CRC32();
        if ( (data != null) && size > 0 ) {
            crc.update(data);
        }
        zipEntry.setCrc(crc.getValue());
        zipEntry.setCompressedSize(-1);
        long modTime=(new java.util.Date()).getTime();
        zipEntry.setTime(modTime);

    }

    /**
     * parse the Manifest file
     */
    protected void parseManifest() 
        throws SAXException, ParserConfigurationException,
               IOException,
               TransformerConfigurationException,TransformerException {

        InputStream is=getInputStream("META-INF/manifest.xml");
        if ( is == null ) {
            _manifestList=null;
            _manifestEntries=null;
            return;
        }

        _manifestList=new LinkedList<String>();

        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware( true );
        factory.setValidating( false );
        factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

        SAXParser parser=factory.newSAXParser(); 
        XMLReader reader=parser.getXMLReader();
        
        String uri=_baseURI+"/META-INF/manifest.xml";
        reader.setEntityResolver(getEntityResolver());
        reader.setContentHandler(new ManifestContentHandler());
        
        InputSource ins=new InputSource(is);
        ins.setSystemId(uri);
        
        reader.parse(ins);

        _contents.remove("META-INF/manifest.xml");
        entryUpdate("META-INF/manifest.xml");
    }
    
    /**
     * decrypt subcontent, NOT YET IMPLEMENTED
     */
    private void decryptAll() {
    }

    /**
     * add a directory to the OdfPackage
     */
    public void addDirectory(String path) 
        throws IOException {

        if ( (path.length() < 1) || (path.charAt(path.length()-1) != '/') ) {
            path=path+"/";
        }
        store(path,(byte[])null,null);
        
    }

    /**
     * store DOM tree into OdfPackage
     */
    public void store(String path, Document doc)
        throws IOException {

        if ( _manifestEntries == null ) {
            try {
                parseManifest();
            } catch ( Exception e ) {
                throw new RuntimeException(e);
            }
        }

        String mediaType="text/xml";

        String d="";
        StringTokenizer tok=new StringTokenizer(path,"/"); {
            while ( tok.hasMoreTokens() ) {
                String s=tok.nextToken();
                if ( "".equals(d) ) {
                    d=s+"/";
                } else {
                    d=d+s+"/";
                }
                if ( tok.hasMoreTokens() ) {
                    if ( ! _entries.contains(d) ) {
                        addDirectory(d);
                    }
                }
            }

        }

        _contents.remove(path);
        if ( doc == null ) {
            _doms.remove(path);
        } else {
            _doms.put(path,doc);
        }

        if ( ! _entries.contains(path) ) {
            _entries.add(path);
        }

        try {
            if ( ! "META-INF/manifest.xml".equals(path) ) {
                if ( _manifestEntries.get(path) == null ) {
                    FileEntry fileEntry=new FileEntry(path, mediaType);
                    _manifestEntries.put(path,fileEntry);
                    _manifestList.add(path);
                }
            } else {
                parseManifest();
            }

            ZipEntry ze=(ZipEntry)_zipEntries.get(path);
            if ( ze != null ) {
                ze=new ZipEntry(path);
                ze.setMethod(ZipEntry.DEFLATED);
                _zipEntries.put(path,ze);
            }
            if ( path.equals("mimetype") || path.equals("meta.xml") ) {
                ze.setMethod(ZipEntry.STORED);
            }
            
            entryUpdate(path);
        } catch ( SAXException se ) {
            throw new IOException("SAXException:"+se.getMessage());
        } catch (ParserConfigurationException pce ) {
            throw new IOException("ParserConfigurationException:"+pce.getMessage());
        } catch (TransformerConfigurationException tce ) {
            throw new IOException("TransformerConfigurationException:"+tce.getMessage());
        } catch (TransformerException te ) {
            throw new IOException("TransformerException:"+te.getMessage());
        }
    }

    
    /**
     * store InputStream into OdfPackage
     */
    public void store(String path, InputStream is, String mediaType) 
        throws IOException {

        if ( is == null ) {
            store(path,(byte[])null,mediaType);
        } else {
            ByteArrayOutputStream baos=new ByteArrayOutputStream();
            BufferedInputStream bis=new BufferedInputStream(is);
            byte[] buf=new byte[4096];
            int r=0;
            while ( (r=bis.read(buf,0,4096)) > -1 ) {
                baos.write(buf,0,r);
            }
            byte[] data=baos.toByteArray();
            store(path,data,mediaType);

            if ( (! path.endsWith(".xml")) && (!path.equals("mimetype")) ) {
                // store to filesystem
                File tempFile=new File(getTempDir(),path);
                File parent=tempFile.getParentFile();
                parent.mkdirs();
                OutputStream fos=new BufferedOutputStream(new FileOutputStream(tempFile));
                fos.write(data);
                fos.close();
                _tempFiles.put(path, tempFile);
                _contents.remove(path);

            }
            
        }
    }

    /**
     * store data into OdfPackage
     */
    public void store(String path, byte[] data, String mediaType) 
        throws IOException {

        String d="";
        StringTokenizer tok=new StringTokenizer(path,"/"); {
            while ( tok.hasMoreTokens() ) {
                String s=tok.nextToken();
                if ( "".equals(d) ) {
                    d=s+"/";
                } else {
                    d=d+s+"/";
                }
                if ( tok.hasMoreTokens() ) {
                    if ( ! _entries.contains(d) ) {
                        addDirectory(d);
                    }
                }
            }
        }

        try {
            if ( "mimetype".equals(path) ) {
                try {
                    setMimetype(new String(data,"UTF-8"));
                } catch (UnsupportedEncodingException use) {
                }
                return;
            }
            if ( data == null ) {
                _contents.remove(path);
            } else {
                _contents.put(path, data);
            }
            if ( ! _entries.contains(path) ) {
                _entries.add(path);
            }
            if ( ! "META-INF/manifest.xml".equals(path) ) {
                if ( mediaType != null ) {
                    if ( _manifestEntries.get(path) == null ) {
                        FileEntry fileEntry=new FileEntry(path, mediaType);
                        _manifestEntries.put(path,fileEntry);
                        if ( _manifestList.contains(path) ) {
                            _manifestList.add(path);
                        }
                    }
                }
            } else {
                parseManifest();
            }
            ZipEntry ze=(ZipEntry)_zipEntries.get(path);
            if ( ze != null ) {
                ze=new ZipEntry(path);
                ze.setMethod(ZipEntry.DEFLATED);
                _zipEntries.put(path,ze);
            }
            if ( path.equals("mimetype") || path.equals("meta.xml") ) {
                ze.setMethod(ZipEntry.STORED);
            }
            
            entryUpdate(path);

        } catch ( SAXException se ) {
            throw new IOException("SAXException:"+se.getMessage());
        } catch (ParserConfigurationException pce ) {
            throw new IOException("ParserConfigurationException:"+pce.getMessage());
        } catch (TransformerConfigurationException tce ) {
            throw new IOException("TransformerConfigurationException:"+tce.getMessage());
        } catch (TransformerException te ) {
            throw new IOException("TransformerException:"+te.getMessage());
        }

    }

    private void store(ZipEntry zipe, byte[] content) {
        if ( content != null ) {
            if (zipe.getName().equals("mimetype") ) {
                try {
                    _mimetype=new String(content,0,content.length,"UTF-8");
                } catch (UnsupportedEncodingException e) {
                    // should not happen
                }
            } else {
                _contents.put(zipe.getName(), content);
            }
        }
        if ( ! _entries.contains(zipe.getName()) ) {
            _entries.add(zipe.getName());
        }
        _zipEntries.put(zipe.getName(),zipe);
    }

    private void store(ZipEntry zipe, File file) {
        if ( file != null ) {
            _tempFiles.put(zipe.getName(), file);
        }
        if ( ! _entries.contains(zipe.getName()) ) {
            _entries.add(zipe.getName());
        }
        _zipEntries.put(zipe.getName(),zipe);
    }


    /**
     * get Manifest as String
     */ 
    public String getManifestAsString() {
        if ( _manifestEntries == null ) {
            try {
                parseManifest();
                if ( _manifestEntries == null ) {
                    return null;
                }
            } catch ( Exception e ) {
                throw new RuntimeException(e);
            }
        }
        StringBuffer buf=new StringBuffer();

        buf.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        buf.append("<manifest:manifest xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\">\n");

        Iterator it=_manifestList.iterator();
        while ( it.hasNext() ) {
            String key=(String)it.next();
            String s=null;
            FileEntry fileEntry=(FileEntry)_manifestEntries.get(key);
            if ( fileEntry != null ) {
                buf.append(" <manifest:file-entry");
                s=fileEntry.getMediaType();
                if ( s == null ) { 
                    s="";
                }
                buf.append(" manifest:media-type=\"");
                buf.append(encodeXMLAttributes(s));
                buf.append("\"");
                s=fileEntry.getPath();

                if ( s == null ) { 
                    s="";
                }
                buf.append(" manifest:full-path=\"");
                buf.append(encodeXMLAttributes(s));
                buf.append("\"");
                int i=fileEntry.getSize();
                if ( i > 0 ) {
                    buf.append(" manifest:size=\"");
                    buf.append(i);
                    buf.append("\"");
                }
                EncryptionData enc=fileEntry.getEncryptionData();

                if ( enc != null ) {
                    buf.append(">\n");
                    buf.append("  <manifest:encryption-data>\n");
                    Algorithm alg=enc.getAlgorithm();
                    if ( alg != null ) {
                        buf.append("   <manifest:algorithm");
                        s=alg.getName();
                        if ( s == null ) { 
                            s="";
                        }
                        buf.append(" manifest:algorithm-name=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"");
                        s=alg.getInitializationVector();
                        if ( s == null ) { 
                            s="";
                        }
                        buf.append(" manifest:initialization-vector=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"/>\n");
                    }
                    KeyDerivation keyDerivation=enc.getKeyDerivation();
                    if ( keyDerivation != null ) {
                        buf.append("   <manifest:key-derivation");
                        s=keyDerivation.getName();
                        if ( s == null ) { 
                            s="";
                        }
                        buf.append(" manifest:key-derivation-name=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"");
                        s=keyDerivation.getSalt();
                        if ( s == null ) { 
                            s="";
                        }
                        buf.append(" manifest:salt=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"");

                        buf.append(" manifest:iteration-count=\"");
                        buf.append(keyDerivation.getIterationCount());
                        buf.append("\"/>\n");
                    }
                    buf.append("  </manifest:encryption-data>\n");
                    buf.append(" </<manifest:file-entry>\n");
                } else {
                    buf.append("/>\n");
                }
            }
        }
        buf.append("</manifest:manifest>");

        return buf.toString();
    }
    
    /**
     * get sub-content as byte array
     */
    public byte[] getData(String path) 
        throws IOException {

        byte[] data=null;

        try {

            if ( path==null || path.equals("") ) {
                ByteArrayOutputStream baos=new ByteArrayOutputStream();
                save(baos,_baseURI);
                return baos.toByteArray();
            }
            if ( path.equals("mimetype") ) {
                if ( _mimetype == null ) {
                    return null;
                }
                try {
                    data=_mimetype.getBytes("UTF-8");
                } catch ( UnsupportedEncodingException use ) {
                    return null;
                }
            } else if ( _entries.contains(path) && _doms.get(path)!=null ) {
                ByteArrayOutputStream baos=new ByteArrayOutputStream();
                OdfXMLHelper helper=new OdfXMLHelper();
                Result result=new StreamResult(baos);
                EntityResolver resolver=getEntityResolver();
                InputSource ins=resolver.resolveEntity(null,"resource:/org/openoffice/odf/xml/transform/identity.xsl");
                if ( ins == null ) {
                    throw new IOException("Resource not found: resource:/org/openoffice/odf/xml/transform/identity.xsl");
                }
                Source source=new StreamSource(ins.getByteStream());
                source.setSystemId(ins.getSystemId());
                helper.transform(this,path,source,result);
                data=baos.toByteArray();
            } else if ( _entries.contains(path) && _tempFiles.get(path)!=null ) {
                ByteArrayOutputStream os=new ByteArrayOutputStream();
                InputStream is=new BufferedInputStream(new FileInputStream((File)_tempFiles.get(path)));
                byte[] buf=new byte[4096];
                int r=0;
                while ( (r=is.read(buf,0,4096)) > 0 ) {
                    os.write(buf,0,r);
                }
                is.close();
                os.close();
                data=os.toByteArray();
            } else if ( _entries.contains(path) && _contents.get(path)!=null ) {
                data=(byte[]) _contents.get(path);
            } else if ( path.equals("META-INF/manifest.xml") ) {
                if ( _manifestEntries == null ) {
                    // manifest was not present
                    return null;
                }
                String s=getManifestAsString();
                if ( s == null ) {
                    return null;
                } else {
                    data=s.getBytes("UTF-8");
                }
            }
        } catch ( SAXException se ) {
            throw new IOException("SAXException:"+se.getMessage());
        } catch (ParserConfigurationException pce ) {
            throw new IOException("ParserConfigurationException:"+pce.getMessage());
        } catch (TransformerConfigurationException tce ) {
            throw new IOException("TransformerConfigurationException:"+tce.getMessage());
        } catch (TransformerException te ) {
            throw new IOException("TransformerException:"+te.getMessage());
        }
        return data;
    }

    /**
     * get subcontent as InputStream
     */
    public InputStream getInputStream(String path) 
        throws IOException {

        if ( path==null || "".equals(path) ) {
            return getInputStream();
        }

        if ( _entries.contains(path) && _tempFiles.get(path)!=null ) {
            return new BufferedInputStream(new FileInputStream((File)_tempFiles.get(path)));
        }

        byte []data=getData(path);
        if ( data != null && data.length != 0 ) {
            ByteArrayInputStream bais=new ByteArrayInputStream(data);
            return bais;
        }
        return null;
    }

    /**
     * get InputStream containing whole OdfPackage
     */
    public InputStream getInputStream() throws IOException
    {
        final PipedOutputStream os=new PipedOutputStream();
        final PipedInputStream is=new PipedInputStream();

        is.connect(os);

        Thread thread1=new Thread() {
                public void run() {
                    try {
                        save(os,_baseURI);
                    } catch ( Exception e ) {
                    }
                }
            };

        Thread thread2=new Thread() {
                public void run() {
                    try {
                        BufferedInputStream bis=new BufferedInputStream(is,4096);
                        BufferedOutputStream bos=new BufferedOutputStream(os,4096);
                        byte[] buf=new byte[4096];
                        int r=0;
                        while ( (r=bis.read(buf,0,4096)) > 0 ) {
                            bos.write(buf,0,r);
                        }
                        is.close();
                        os.close();
                    } catch ( IOException ie ) {
                    }
                }
            };

        thread1.start();
        thread2.start();

        return is;
    }


    /**
     * get OutputStream for writing new sub-content into OdfPackage
     */
    public OutputStream getOutputStream(String path)
        throws IOException {
        
        if ( path==null || "".equals(path) ) {
            throw new IllegalArgumentException("empty path not allowed");
        }
        
        final String fPath=path;
        final FileEntry fFileEntry=getFileEntry(path);

        ByteArrayOutputStream baos=new ByteArrayOutputStream() {
                
                public void close() throws IOException {
                    super.close();
                    byte[] data=this.toByteArray();
                    store(fPath,data,(fFileEntry==null?null:fFileEntry.getMediaType()));
                }
            };
        return baos;
    }


    /**
     * get an OdfPackagStream containing the document content from the package
     * 
     */
    public OdfPackageStream getContentStream() throws IOException {
        return getNamedStream(STREAMNAME_CONTENT);
    }
    
    /**
     * get and OdfPackageStream containing the document styles from the package
     * 
     */
    public OdfPackageStream getStyleStream() throws IOException {
        return getNamedStream(STREAMNAME_STYLE);
    }

    /**
     * get and OdfPackageStream containing
     * the document metadata from the package
     * 
     */
    public OdfPackageStream getMetadataStream() throws IOException {
        return getNamedStream(STREAMNAME_META);
    }

    /**
     * get an OdfPackageStream with a specific name from the package.
     *
     * @throws IllegalArgumentException if sub-content is not XML
     */    
    public OdfPackageStream getNamedStream(String name) throws IOException {
        OdfPackageStream stream = new OdfPackageStream(this,name);
        return stream;
    }

    /**
     * get Temp Directory
     */
    private File getTempDir() 
        throws IOException {
        
        if ( _tempDir == null ) {
            _tempDir=TempDir.createGeneratedName("ODF",_tempDirParent);
        }
        return _tempDir;
    }

    /**
     * set Parent Directory for TempDirs created by ODFPackage instances
     */
    public static void setTempDirParent(File dir) {
        _tempDirParent=dir;
    }
    
    /**
     * gets an embedded image
     * @param path the package path to the image, e.g. "Images/picture001.png"
     * @return the image
     * @throws IOException if the specified image cannot be opened
     */
    public java.awt.Image getImage(String path) throws IOException {
        Image emImage = null;
        String mediaType = getFileEntry(path).getMediaType();
        if(mediaType.contains("image")){
            InputStream is = getInputStream(path);
            BufferedImage bi = ImageIO.read(is);
            return bi;
        } else{
            throw new IllegalArgumentException("wrong path not allowed");
        }
    }


    /**
     * returns true if mimetype file has been first file in package
     * and stored uncompressed
     */
    public boolean isMimetypeValid() {
        return _isMimetypeValid;
    }

    /**
     * encoded XML Attributes
     */
    private String encodeXMLAttributes(String s) {
        String r=s.replaceAll("\"","&quot;");
        r=r.replaceAll("'","&apos;");
        return r;
    }

}

