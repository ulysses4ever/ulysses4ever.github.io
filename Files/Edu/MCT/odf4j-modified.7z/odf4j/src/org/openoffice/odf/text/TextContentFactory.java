/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: TextContentFactory.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;

import org.openoffice.odf.common.documenttype.Element;
//import org.openoffice.odf.common.documenttype.BlockElementImpl;
import org.openoffice.odf.common.documenttype.ElementFactory;
import org.openoffice.odf.common.documenttype.BlockElement;

//import org.openoffice.odf.graphics.Frame;
//import org.openoffice.odf.graphics.Image;

import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import org.openoffice.odf.graphics.GraphicsElementFactory;
/**
 *
 * @author duyunfen
 */
public class TextContentFactory extends ElementFactory{
    
    private GraphicsElementFactory graphicsElementFactory = null; 
    /** Creates a new instance of TextContentFactory */
    public TextContentFactory() {
        super();
        elementMap = new HashMap<Node,Element>();        
    }    
    public TextContentFactory(Map<Node,Element> elemap){
        elementMap = elemap;
    }            
    
    public ElementFactory getTextInstance(){
        return this;
    }
    
    public ElementFactory getGraphicsInstance(){
        if (graphicsElementFactory == null){
            GraphicsElementFactory graphicsFactory = new GraphicsElementFactory(elementMap);
        }
        return graphicsElementFactory;
    }
    
    public Element getElement(Node node) {
        String name = node.getLocalName();
        String ns = node.getNamespaceURI();
        if (ns.equals(Namespaces.text)) {
            if (name.equals("p")) {
                return getElement(node, Paragraph.class);
            } else if (name.equals("h")) {
                return getElement(node, Heading.class);
            } else if (name.equals("list-item")) {
                return getElement(node, ListItem.class);
            }else if (name.equals("section")) {
                return getElement(node, Section.class);
            } else if (name.equals("list")) {
                return getElement(node, List.class);
            }
        } else if(ns.equals(Namespaces.draw)) {
            if(graphicsElementFactory != null){
                return getGraphicsInstance().getElement(node);
            }
        } else if(ns.equals(Namespaces.office)) {
            if (name.equals("text")){
                return getElement(node, Body.class);
            }else if(ns.equals("forms")){
                //return getElement(node,Forms.class);
            }
        }
        return getElement(node, UnknownElement.class);            
    }
    
    public Element getInlineElement(Node n, BlockElement block) {
        if (n.getNodeType() == Node.TEXT_NODE)
            return getPortion(n, block);
        else {
            return getElement(n);
        }
    }   
    
    protected Portion getPortion(Node node, BlockElement block) {       
        Portion p = (Portion) elementMap.get(node);
        if (p == null) {
            p = new Portion(node, block);
        }
        return p;
    }    
}
