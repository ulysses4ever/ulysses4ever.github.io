/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OdfXMLHelper.java,v $
 *
 *  $Revision: 1.3 $
 *
 *  last change: $Author: bei $ $Date: 2007/03/30 10:27:36 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.xml;

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.Templates;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.URIResolver;
import org.xml.sax.XMLReader;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;


import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;

import org.openoffice.odf.OdfPackage;

public class OdfXMLHelper {

    /**
     * create an XMLReader
     * with a Resolver set to parse content in a package
     */
    protected XMLReader createXMLReader(OdfPackage pkg) 
        throws SAXException, ParserConfigurationException {

        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware( true );
        factory.setValidating( false );

        SAXParser parser=factory.newSAXParser();
        XMLReader reader=parser.getXMLReader();

        reader.setEntityResolver(pkg.getEntityResolver());
     
        return reader;
    }

    /**
     * use SAX parser to parse content of package 
     */
    public void parse(OdfPackage pkg, String path, ContentHandler contentHandler, ErrorHandler errorHandler) 
        throws SAXException, ParserConfigurationException, IOException, IllegalArgumentException, TransformerConfigurationException, TransformerException {

        InputStream is=pkg.getXMLInputStream(path);
        XMLReader reader=createXMLReader(pkg);

        String uri=pkg.getBaseURI()+path;

        if ( contentHandler != null ) {
            reader.setContentHandler(contentHandler);
        }
        if ( errorHandler != null ) {
            reader.setErrorHandler(errorHandler);
        }
        
        InputSource ins=new InputSource(is);
        ins.setSystemId(uri);
        
        reader.parse(ins);
    }

    /**
     * Do XSL-Transformation on content contained in package
     */
    public void transform(OdfPackage pkg, String path, String templatePath, String outPath)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {
        
        transform(pkg, path, new File(templatePath), new File(outPath));
    }

    /**
     * Do XSL-Transformation on content contained in package
     */
    public void transform(OdfPackage pkg, String path, Source templateSource, String outPath)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {
        
        transform(pkg, path, templateSource, new File(outPath));
    }

    /**
     * Do XSL-Transformation on content contained in package
     */
    public void transform(OdfPackage pkg, String path, Source templateSource, File out)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {
        
        transform(pkg, path, templateSource, new StreamResult(out));
    }

    /**
     * Do XSL-Transformation on content contained in package
     * store result back to package
     */
    public void transform(OdfPackage pkg, String path, String templatePath)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {
        transform(pkg, path, new File(templatePath));        
    }

    /**
     * Do XSL-Transformation on content contained in package
     */
    public void transform(OdfPackage pkg, String path, File template, File out)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {

        TransformerFactory transformerfactory = TransformerFactory.newInstance();
        
        Templates templates=transformerfactory.newTemplates(new StreamSource(template));
        transform(pkg, path,templates,new StreamResult(out));
    }

    /**
     * Do XSL-Transformation on content contained in package
     * store result back to package
     */
    public void transform(OdfPackage pkg, String path, File template)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {

        TransformerFactory transformerfactory = TransformerFactory.newInstance();

        Templates templates=transformerfactory.newTemplates(new StreamSource(template));
        transform(pkg, path,templates);
    }

    /**
     * Do XSL-Transformation on content contained in package
     */
    public void transform(OdfPackage pkg, String path, Source templateSource, Result result)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException,
               ParserConfigurationException {
        TransformerFactory transformerfactory = TransformerFactory.newInstance();
        transformerfactory.setURIResolver(pkg.getURIResolver());
        
        Templates templates=transformerfactory.newTemplates(templateSource);
        transform(pkg,path,templates,result);
    }

    /**
     * Do XSL-Transformation on content contained in package
     */
    public void transform(OdfPackage pkg, String path, Templates templates, Result result)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException,
               ParserConfigurationException {

        Source source=null;
        String uri=pkg.getBaseURI()+path;
        Document doc=pkg.getDocument(path);
        source = new DOMSource(doc);
        Transformer transformer=templates.newTransformer();
        transformer.setURIResolver(pkg.getURIResolver());

        transformer.setParameter("sourceURL",uri);
        transformer.setParameter("sourceBaseURL",pkg.getBaseURI()+"/");

        uri=result.getSystemId();
        if ( uri != null ) {
            transformer.setParameter("targetURL",uri);
            int i=uri.lastIndexOf('/');
            if ( i > 0 ) {
                uri=uri.substring(0,i+1);
                transformer.setParameter("targetBaseURL",uri);
            }
        }
        DocumentType doctype=doc.getDoctype();
        if ( doctype != null ) {
            if ( doctype.getPublicId() != null ) {
                transformer.setParameter("publicType",doctype.getPublicId());
            }
            if ( doctype.getSystemId() != null ) {
                transformer.setParameter("systemType",doctype.getSystemId());
            }
        }

        transformer.transform(source,result);
    }

    /**
     * Do XSL-Transformation on content contained in package
     * and store result back to package
     */
    public void transform(OdfPackage pkg, String path, Templates templates)
        throws TransformerConfigurationException, TransformerException,
               IOException, IllegalArgumentException, SAXException, ParserConfigurationException {

        Result result=null;
        ByteArrayOutputStream baos=null;

        if ( pkg.hasDOM(path) ) {
            result=new DOMResult();
        } else {
            baos=new ByteArrayOutputStream();
            result=new StreamResult(baos);
        }

        transform(pkg, path, templates, result);

        if ( pkg.hasDOM(path) ) {
            pkg.store(path,(Document)((DOMResult) result).getNode());
        } else {
            byte[] data=baos.toByteArray();
            pkg.store(path,data,"text/xml");
        }

    }

}

