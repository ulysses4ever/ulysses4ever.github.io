/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OpenDocumentFactory.java,v $
 *
 *  $Revision: 1.4 $
 *
 *  last change: $Author: bei $ $Date: 2007/06/07 15:59:12 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;

import org.openoffice.odf.spreadsheet.SpreadsheetDocument;
import org.openoffice.odf.text.TextDocument;
import org.openoffice.odf.graphics.GraphicsDocument;
import org.openoffice.odf.presentation.PresentationDocument;
import org.openoffice.odf.OdfPackage;

public class OpenDocumentFactory {

    private static OpenDocument toOpenDocument(OdfPackage pkg) {

        String mimetype=pkg.getMimetype();
        if ( mimetype == null ) {
            return null;
        }

        OpenDocument odf=null;

        if ( mimetype.equals(OpenDocument.TEXT_MEDIA_TYPE)
             || mimetype.equals(OpenDocument.TEXT_TEMPLATE_MEDIA_TYPE) ) {

            odf = new TextDocument(pkg);

        } else if ( mimetype.equals(OpenDocument.GRAPHICS_MEDIA_TYPE)
                    || mimetype.equals(OpenDocument.GRAPHICS_TEMPLATE_MEDIA_TYPE) ) {

            odf = new GraphicsDocument(pkg);

        } else if ( mimetype.equals(OpenDocument.PRESENTATION_MEDIA_TYPE)
                    || mimetype.equals(OpenDocument.PRESENTATION_TEMPLATE_MEDIA_TYPE) ) {
            
            odf = new PresentationDocument(pkg);

        } else if ( mimetype.equals(OpenDocument.SPREADSHEET_MEDIA_TYPE)
                    || mimetype.equals(OpenDocument.SPREADSHEET_TEMPLATE_MEDIA_TYPE) ) {

            odf = new SpreadsheetDocument(pkg);

        }
        
        pkg.close();
        return odf;
    }
    
    public static OpenDocument load(String filename)
        throws IOException {
        OdfPackage pkg = new OdfPackage(filename);
        return toOpenDocument(pkg);
    }

    public static OpenDocument load(File file)
        throws IOException {
        OdfPackage pkg = new OdfPackage(file);
        return toOpenDocument(pkg);
    }

    public static OpenDocument load(InputStream is, String baseURI)
        throws IOException {
        OdfPackage pkg = new OdfPackage(is,baseURI);
        return toOpenDocument(pkg);
    }
}

