/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: SpreadsheetDocument.java,v $
 *
 *  $Revision: 1.7 $
 *
 *  last change: $Author: mib $ $Date: 2007/10/25 13:22:44 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.spreadsheet;

import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Iterator;

import java.util.LinkedList;

import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;

import org.openoffice.odf.OdfPackage;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;

/**
 * Class for working with OpenDocument Spreadsheets
 */
public class SpreadsheetDocument extends OpenDocument {

    private CellFactory _cellFactory;

    public SpreadsheetDocument()
        throws IOException {
        super();
    }

    public SpreadsheetDocument(OdfPackage pkg) {
        super(pkg);
    }

    /**
     * For now just returns the DefaultCellFactory
     * later it is planned that this can be overriden by a system property
     */
    public CellFactory getCellFactory() {
        if ( _cellFactory == null ) {
            _cellFactory=new DefaultCellFactory();
        }
        return _cellFactory;
    }

    /**
     * Get iterator for names of all spreadsheets in the SpreadsheetDocument
     */
    public Iterator<String> getSpreadsheetNames()
        throws SAXException, ParserConfigurationException, IOException,
               IllegalArgumentException,
               TransformerConfigurationException, TransformerException {
        
        Document doc=getDocument("content.xml");

        LinkedList<String> list=new LinkedList<String>();
        NodeList nl=doc.getElementsByTagNameNS(Namespaces.table,"table");
        if ( nl != null ) {
            for (int i=0; i<nl.getLength(); i++ ) {
                Element elem=(Element)nl.item(i);
                String name=elem.getAttributeNS(Namespaces.table,"name");
                list.add(name);
            }
        }
        return list.iterator();
    }

    /**
     * delete a spreadsheet in the SpreadsheetDocument
     * @throws IllegaArgumentException if a spreadsheet with
     *         this name is not in the document.
     */
    public void deleteSpreadsheet(String name)
        throws SAXException, ParserConfigurationException, IOException,
               IllegalArgumentException,
               TransformerConfigurationException, TransformerException {

        Document doc=getDocument("content.xml");
        NodeList nl=doc.getElementsByTagNameNS(Namespaces.table,"table");
        boolean bFound=false;
        if ( nl != null ) {
            for (int i=0; i<nl.getLength(); i++ ) {
                Element elem=(Element)nl.item(i);
                String tname=elem.getAttributeNS(Namespaces.table,"name");
                if ( tname.equalsIgnoreCase(name) ) {
                    elem.getParentNode().removeChild(elem);
                    bFound=true;
                }
            }
        }
        if ( ! bFound ) {
            throw new IllegalArgumentException(name+": no such spreadsheet");
        }
    }

    /**
     * add a Spreadsheet use TableModel as data source
     */
    public void addSpreadsheet(String name, TableModel model, boolean withHeader)
        throws SAXException, ParserConfigurationException, IOException,
               IllegalArgumentException,
               TransformerConfigurationException, TransformerException {

        if ( name==null ) {
            throw new IllegalArgumentException("name is null");
        }
        if ( "".equals(name) ) {
            throw new IllegalArgumentException("empty name");
        }

        for ( Iterator<String> it=getSpreadsheetNames(); it.hasNext(); ) {
            String sheet=it.next();
            if ( sheet.equals(name) ) {
                throw new IllegalArgumentException(name+": is already defined as spreadsheetname in the document");
            }
        }


        CellFactory cf=getCellFactory();

        Document doc=getDocument("content.xml");
        NodeList nl=doc.getElementsByTagNameNS(Namespaces.office,"spreadsheet");
        Element spreadsheet=(Element)nl.item(0);
        if ( spreadsheet == null ) {
            throw new IllegalArgumentException("shreadsheet tag not found");
        }
        Element table=doc.createElementNS(Namespaces.table,"table:table");
        table.setAttributeNS(Namespaces.table,"table:name",name);
        table.setAttributeNS(Namespaces.table,"table:style-name","ta1");
        table.setAttributeNS(Namespaces.table,"table:print","true");
        
        if ( model == null ) {
            Element rowE=doc.createElementNS(Namespaces.table,"table:table-row");
            rowE.setAttributeNS(Namespaces.table,"table:style-name","ro1");
            Element cellE=doc.createElementNS(Namespaces.table,"table:table-cell");
            Element colE=doc.createElementNS(Namespaces.table,"table:table-column");
            colE.setAttributeNS(Namespaces.table,"table:style-name","co1");
            colE.setAttributeNS(Namespaces.table,"table:default-style-name","Default");
            rowE.appendChild(cellE);
            table.appendChild(colE);
            table.appendChild(rowE);
        } else {
            Element tableRows=doc.createElementNS(Namespaces.table,"table:table-rows");
            Element tableColumns=doc.createElementNS(Namespaces.table,"table:table-columns");
            if ( model.getColumnCount()> 0) {
                for ( int coli=0; coli<model.getRowCount(); coli++ ) {
                    Element col=doc.createElementNS(Namespaces.table,"table:table-column");
                    col.setAttributeNS(Namespaces.table,"table:style-name","co1");
                    col.setAttributeNS(Namespaces.table,"table:default-style-name","Default");
                    tableColumns.appendChild(col);

                }
            }
            if ( (withHeader == true) && (model.getColumnCount()> 0) ) {
                Element tableHeaderRows=doc.createElementNS(Namespaces.table,"table:table-header-rows");
                Element rowH=doc.createElementNS(Namespaces.table,"table:table-row");
                rowH.setAttributeNS(Namespaces.table,"table:style-name","ro1");
                for (int coli=0; coli<model.getColumnCount(); coli++ ) {
                    Element cellH=doc.createElementNS(Namespaces.table,"table:table-cell");
                    String columnName=model.getColumnName(coli);

                    cf.setCellContent(this,doc,cellH,columnName);

                    rowH.appendChild(cellH);
                }
                tableHeaderRows.appendChild(rowH);
                tableRows.appendChild(tableHeaderRows);
            }
            if ( model.getRowCount()> 0) {
                for ( int rowi=0; rowi<model.getRowCount(); rowi++ ) {
                    Element row=doc.createElementNS(Namespaces.table,"table:table-row");
                    row.setAttributeNS(Namespaces.table,"table:style-name","ro1");
                    for (int coli=0; coli<model.getColumnCount(); coli++ ) {

                        Element cell=doc.createElementNS(Namespaces.table,"table:table-cell");
                        cf.setCellContent(this,doc,cell,model.getValueAt(rowi,coli));
                        
                        row.appendChild(cell);
                    }
                    tableRows.appendChild(row);
                }
            }
            table.appendChild(tableColumns);
            table.appendChild(tableRows);
        }
        spreadsheet.appendChild(table);
    }

    /**
     * Implementation of the abstract method from
     * the OpenDocument base class returns a Stream
     * for an empty SpreadSheetDocument
     */
    protected InputSource emptyDocumentTemplate() {
        EntityResolver resolver=getEntityResolver();
        InputSource is=null;
        try {
            is=resolver.resolveEntity(null,"resource:/org/openoffice/odf/template/SpreadsheetDocument.ods");
        } catch ( Exception e ) {
        }
        return is;
    }

}
