/*
 * StyleFactory.java
 *
 * Created on 3 July, 2007, 10:31 AM
 *
 *
 */

package org.openoffice.odf.text;

import org.w3c.dom.Document;
/**
 *
 * @author Amit K Saha <amitsaha.in@gmail.com>
 */
public class StyleFactory {
    
    /** Creates a new instance of StyleFactory */
    public StyleFactory() {
    }
    
    static synchronized StyleFactory getInstance(Document doc)
    {
      //  NamedNodeMap map = element.getNode().getAttributes();
     return new StyleFactory();   
    }
}
