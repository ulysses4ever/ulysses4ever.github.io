/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Page.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.graphics;
import org.openoffice.odf.OpenDocument;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.schema.Namespaces;

/**
 *
 * @author duyunfen
 */
public class Page extends GraphicElement{
    
    private String drawname = null;
    private String fillType = "pagefilltype";
    /** Creates a new instance of Page */
    public Page() {
    }
    
    public Page(Node node){
        super(node);
      if(node.getNodeName()!="draw:page"){
            throw new IllegalArgumentException("not a page node initialized");   
      }else{
            initial();
      }
    }
    
    public Page(OpenDocument od){
        super(od,"draw:page");
    }
    
    /** initial default attr node */
    public void initial(){
        setAttribute("draw:style-name","dp1",Namespaces.draw);
        setAttribute("draw:master-page-name","Default",Namespaces.draw);   
    }
    
    /** get draw:name  attribute*/
    public String getPageName(){
           return getAttriStringValue("draw:name");
    }
    public void setPageName(String sname){
        setAttribute("draw:name",sname,Namespaces.draw);
    }
    
    /** fill type */
    public String getFillStyle(){
       fillType = "";
       Node drawNode = getNode();
       if(drawNode!=null){
       }
        return fillType;
    }
    
    public void setFillType(String filltype){
       fillType = filltype;
    }
   
   public String getMasterPageName(){
        return getAttriStringValue("draw:master-page-name");
   }
 
}
