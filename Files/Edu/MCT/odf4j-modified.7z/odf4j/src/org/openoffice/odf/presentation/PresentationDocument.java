/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: PresentationDocument.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2007/03/29 18:49:30 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.presentation;

import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;

import org.openoffice.odf.OdfPackage;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;

/**
 * Class for working with OpenDocument text documents
 */
public class PresentationDocument extends OpenDocument {

    public PresentationDocument()
        throws IOException {
        super();
    }

    public PresentationDocument(OdfPackage pkg) {
        super(pkg);
    }
    
    /**
     * Implementation of the abstract method from
     * the OpenDocument base class returns a Stream
     * for an empty PresentationDocument
     */
    protected InputSource emptyDocumentTemplate() {
        EntityResolver resolver=getEntityResolver();
        InputSource is=null;
        try {
            is=resolver.resolveEntity(null,"resource:/org/openoffice/odf/template/PresentationDocument.odp");
        } catch ( Exception e ) {
        }
        return is;
    }

}
