/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: BlockElement.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.common.documenttype;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.graphics.Text;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
/**
 *
 * @author duyunfen
 */
public abstract class BlockElement extends Element implements List<Element> {
    
    private List<Element> m_contentList;
    /** Creates a new instance of BlockElement */
    public BlockElement() {
    }
    
    protected BlockElement(Node node){
        super(node);
    }
    
    public BlockElement(Node node, List<Element> contentList) {
        attach(node,contentList);
    }      
    
    protected void attach(Node node, List<Element> contentList){
        super.attach(node);
        m_contentList = contentList;        
    }
    
    public int size() {
        return m_contentList.size();
    }

    public boolean isEmpty() {
        return m_contentList.isEmpty();
    }

    public boolean contains(Object o) {
        return m_contentList.contains(o);
    }

    public Iterator<Element> iterator() {
        return m_contentList.iterator();
    }

    public Object[] toArray() {
        return m_contentList.toArray();
    }

    public <T> T[] toArray(T[] a) {
        return m_contentList.toArray(a);
    }

    public boolean add(Element e) {
        return m_contentList.add(e);
    }

    public boolean remove(Object o) {
        return m_contentList.remove(o);
    }

    public boolean containsAll(Collection<?> c) {
        return m_contentList.containsAll(c);
    }

    public boolean addAll(Collection<? extends Element> c) {
        return m_contentList.addAll(c);
    }

    public boolean addAll(int index, Collection<? extends Element> c) {
        return m_contentList.addAll(index, c);
    }

    public boolean removeAll(Collection<?> c) {
        return m_contentList.removeAll(c);
    }

    public boolean retainAll(Collection<?> c) {
        return m_contentList.retainAll(c);
    }

    public void clear() {
        m_contentList.clear();
    }

    public Element get(int index) {
        return m_contentList.get(index);
    }

    public Element set(int index, Element element) {
        return m_contentList.set(index, element);
    }

    public void add(int index, Element element) {
        m_contentList.add(index, element);
    }

    public Element remove(int index) {
        return m_contentList.remove(index);
    }

    public int indexOf(Object o) {
        return m_contentList.indexOf(o);
    }

    public int lastIndexOf(Object o) {
        return m_contentList.lastIndexOf(o);
    }

    public ListIterator<Element> listIterator() {
        return m_contentList.listIterator();
    }

    public ListIterator<Element> listIterator(int index) {
        return m_contentList.listIterator(index);
    }

    public List<Element> subList(int fromIndex, int toIndex) {
        return m_contentList.subList(fromIndex, toIndex);
    }

}
