/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: TempDir.java,v $
 *
 *  $Revision: 1.3 $
 *
 *  last change: $Author: mib $ $Date: 2007/10/25 13:22:44 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.util;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Hashtable;
    
public class TempDir {

    public static Hashtable<File,Integer> _refCounts=new Hashtable<File,Integer>();

    /**
     * Creates a temp directory with a generated name (given a certain prefix) 
     * in a given directory.
     * The directory (and all its content) will be destroyed on exit.
     */    
    public static File createGeneratedName(String prefix, File directory)
        throws IOException {

        File tempFile = File.createTempFile(prefix, "", directory);
        if (!tempFile.delete())
            throw new IOException();
        if (!tempFile.mkdir())
            throw new IOException();
        TempDirDeleter.getInstance().add(tempFile);
        _refCounts.put(tempFile,new Integer(1));
        return tempFile;        
    }
    

    /**
     * Creates a temp directory with a generated name (given a certain prefix)
     * in default temporary-file directory.
     * Invoking this method is equivalent to invoking createGeneratedName(prefix, null).
     * The directory (and all its content) will be destroyed on exit.
     */    
    public static File createGeneratedName(String prefix)
        throws IOException {
        return createGeneratedName(prefix,null);
    }

    /**
     * Creates a temp directory with a given name in a given directory.
     * The directory (and all its content) will be destroyed on exit.
     */    
    public static File createNamed(String name, File directory)
        throws IOException {

        File tempFile = new File(directory, name);
        if (!tempFile.mkdir())
            throw new IOException();
        TempDirDeleter.getInstance().add(tempFile);
        _refCounts.put(tempFile,new Integer(1));
        return tempFile;        
    }    

    /**
     * increase refCount
     */
    public static int ref(File dir) {
        int refCount=((Integer)_refCounts.get(dir)).intValue();
        ++refCount;
        _refCounts.put(dir,new Integer(refCount));
        return refCount;
    }
    
    /**
     * release reference, when refcount gets 0 Directory is deleted
     */
    public static void release(File dir) {
        int refCount=((Integer)_refCounts.get(dir)).intValue();
        if ( --refCount==0 ) {
            TempDirDeleter.getInstance().deleteDirectory(dir);
            _refCounts.remove(dir);
        } else {
            _refCounts.put(dir,new Integer(refCount));
        }
    }
    
}
