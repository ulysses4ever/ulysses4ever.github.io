package org.openoffice.odf.text.style;

import org.w3c.dom.*;
import org.openoffice.odf.schema.Namespaces;

/**
 *
 * @author Eliseev
 */
public class ParagraphStyle extends StyleInfo {
    
    private TextAlign textAlign;
    
    public ParagraphStyle(Font font) {
	this(font, TextAlign.LEFT);
    }
    
    public ParagraphStyle(Font font, TextAlign textAlign) {
	super(font);
	this.textAlign = textAlign;
    }
    
    protected String getStyleFamilyAttr() { return "paragraph"; }
    
    protected void addStyleChildren(Node styleTag) {
	Node paraProps = styleTag.getOwnerDocument().createElementNS(Namespaces.style, "style:paragraph-properties");
	styleTag.appendChild(paraProps);
	addAttr("fo","text-align",textAlign.getFoTextAlignAttr(),paraProps,Namespaces.fo);
	addAttr("style","justify-single-word","false",paraProps,Namespaces.style);
    }
    
    public TextAlign getTextAlign() { return textAlign; }
    public void setTextAlign(TextAlign textAlign) { this.textAlign = textAlign; }

}
