/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: ContentTreeNode.java,v $
 *
 *  $Revision: 1.5 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.explorer;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import javax.swing.tree.TreeNode;
import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.InlineElement;
//import org.openoffice.odf.text.BlockElement;
//import org.openoffice.odf.text.Element;
//import org.openoffice.odf.text.InlineElement;
import org.w3c.dom.Node;

public class ContentTreeNode implements TreeNode {
    
    private Element m_element;
    private List<ContentTreeNode> m_children;
    private ContentTreeNode m_parent;
    
    public ContentTreeNode(Element object) {
        this(null, object);
    }
    
    public ContentTreeNode(ContentTreeNode parent, Element object) {
        m_parent = parent;
        m_element = object;
        rebuild();
    }
    
    private void rebuild() {
        if (m_element instanceof BlockElement) {
            m_children = new ArrayList<ContentTreeNode>();
            BlockElement block = (BlockElement) m_element;
            for (Element e : block) {
                m_children.add(new ContentTreeNode(e));
            }
        }        
    }
       
    public Element getElement() {
        return m_element;
    }
    
    public String toString() {
        // Node node = m_element.getNode();        
        // return node.getNodeName();
        return m_element.getDescription();
    }

    
    public TreeNode getChildAt(int childIndex) {
        
        if (m_children != null) {
            return (TreeNode) m_children.get(childIndex);
        } else {
            return null;
        }
    }

    public int getChildCount() {
        if (m_children != null) {
            return m_children.size();
        } else {
            return 0;
        }
    }

    public TreeNode getParent() {
        return m_parent;
    }

    public int getIndex(TreeNode node) {
        if (m_children != null) {
            return m_children.indexOf(node);
        } else {
            return -1;
        }
    }

    public boolean getAllowsChildren() {
        return ! (m_element instanceof InlineElement);
    }

    public boolean isLeaf() {
        return m_element instanceof InlineElement;
    }

    public Enumeration children() {
        if (m_children != null) {
            // on the fly iterator->enumeration wrapper...
            return new Enumeration() {
                private Iterator iter = m_children.iterator();
                public boolean hasMoreElements() {
                    return iter.hasNext();
                }
                public Object nextElement() {
                    return iter.next();
                }};                
        } else {
            return null;
        }
    }    

    public boolean equals(Object obj) {
        if (obj instanceof ContentTreeNode) {
            return ((ContentTreeNode)obj).getElement().equals(m_element);
        } else {
            return false;
        }
    }
}
