package org.openoffice.odf.text.style;

import org.w3c.dom.*;
import org.openoffice.odf.schema.Namespaces;

/**
 *  �������� ���������� � �����.<br>
 * Eliseev
 */
public class StyleInfo {
    private static Integer curNumber = 1;
    
    private String name;
    private Font font;
    
    public StyleInfo(Font font) {
	synchronized(curNumber) {
	    name = "S" + curNumber.toString();
	    ++curNumber;
	}
	this.font = font;
    }
    
    protected String getStyleFamilyAttr() { return "text"; }
    
    protected void addStyleChildren(Node styleTag) {}
    
    public void appendStyleTag(Node toElement) {
	Node result = toElement.getOwnerDocument().createElementNS(Namespaces.style, "style:style");
	toElement.appendChild(result);
	addAttr("style", "name", name, result, Namespaces.style);
	addAttr("style", "family", getStyleFamilyAttr(), result, Namespaces.style);
	addAttr("style", "parent-style-name", "Standard", result, Namespaces.style);
	
	addStyleChildren(result);
	
	if (font != null) {
	    font.appendFontTag(result);
	}
    }
    
    static void addAttr(String ns, String name, String value, Node n, String namespace) {
	Attr attr = n.getOwnerDocument().createAttributeNS(namespace, ns + ":" + name);
	attr.setNodeValue(value);
	n.getAttributes().setNamedItem(attr);
    }
    

    public String getName() { return name; }

    public Font getFont() { return font; }
    public void setFont(Font font) { this.font = font; }
    
}
