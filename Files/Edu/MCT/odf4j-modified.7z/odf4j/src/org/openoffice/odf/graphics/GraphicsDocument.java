/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: GraphicsDocument.java,v $
 *
 *  $Revision: 1.3 $
 *
 *  last change: $Author: bei $ $Date: 2007/12/18 10:53:40 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.graphics;

import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;

import org.openoffice.odf.OdfPackage;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Node;

import org.openoffice.odf.common.documenttype.ElementFactory;
//import org.openoffice.odf.common.documenttype.Element;

/**
 * Class for working with OpenDocument graphics documents
 */
public class GraphicsDocument extends OpenDocument {

    private Document doc = null;
    private GraphicsElementFactory fac = null;
    public GraphicsDocument()
        throws IOException {
        super();
    }

    public GraphicsDocument(OdfPackage pkg) {
        super(pkg);
        initial();
    }
    
    /** initial private member */
   private void initial(){
       try{
            doc = getDocument(STREAMNAME_CONTENT);
            fac = (GraphicsElementFactory)ElementFactory.getInstance(doc,GraphicsElementFactory.class );        
       } catch (Exception ex){
       }
   }
    
   /** create graphics' shape element */
    public GraphicElement createGraphics(String name){
      return (GraphicElement)fac.createGraphics(doc,name);
    }
 
    /** create forms element */
    public Forms createForms(String name){
       return fac.createForms(doc,name);  
    }
    
   /*create style for testing*/
   public Style createStyle(String name){
        return fac.createStyle(doc,name);
    }
   
   /**create text content
    *text should derived from paragraph of text package
    *here just for testing,need ajusting
    */
   public Text createText(String content){
       return fac.createText(doc,content);
   }
     
   
    public Body getBody(){
        
             try {
            // find the body element
            NodeList nl = doc.getElementsByTagNameNS(Namespaces.office, "drawing");
            
            // XXX we might want to cache this to avoid searching for the element
            // again.
            Body body = (Body)fac.getElement(nl.item(0));
            
            return body;
            
        } catch (Exception ex) {
            return null;
        }
    }
    
    public Style getStyle(){
        try{
        doc = getDocument(STREAMNAME_CONTENT);

        GraphicsElementFactory fac = (GraphicsElementFactory)ElementFactory.getInstance(doc,GraphicsElementFactory.class );

        // find the body element
        NodeList nl = doc.getElementsByTagNameNS(Namespaces.office, "automatic-styles");

        // XXX we might want to cache this to avoid searching for the element
        // again.
        Style style = (Style) fac.getElement(nl.item(0));
        
        return style;
            
        }catch(Exception ex){
            return null;
        }
    }
    /**
     * Implementation of the abstract method from
     * the OpenDocument base class returns a Stream
     * for an empty Calc document
     */
    protected InputSource emptyDocumentTemplate() {
        EntityResolver resolver=getEntityResolver();
        InputSource is=null;
        try {
            is=resolver.resolveEntity(null,"resource:/org/openoffice/odf/template/GraphicsDocument.odg");
        } catch ( Exception e ) {
        }
        return is;
    }
}
