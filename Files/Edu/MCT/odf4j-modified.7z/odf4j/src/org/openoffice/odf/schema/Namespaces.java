/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Namespaces.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: mib $ $Date: 2007/10/24 15:31:21 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.schema;

/**
 * class keeping some constants for OpenDocument namespaces
 */
public class Namespaces {
    public static final String office="urn:oasis:names:tc:opendocument:xmlns:office:1.0";
    public static final String style="urn:oasis:names:tc:opendocument:xmlns:style:1.0";
    public static final String text="urn:oasis:names:tc:opendocument:xmlns:text:1.0";
    public static final String table="urn:oasis:names:tc:opendocument:xmlns:table:1.0";
    public static final String draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0";
    public static final String fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0";
    public static final String xlink="http://www.w3.org/1999/xlink";
    public static final String dc="http://purl.org/dc/elements/1.1/";
    public static final String meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0";
    public static final String number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0";
    public static final String svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0";
    public static final String chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0";
    public static final String dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0";
    public static final String math="http://www.w3.org/1998/Math/MathML";
    public static final String form="urn:oasis:names:tc:opendocument:xmlns:form:1.0";
    public static final String script="urn:oasis:names:tc:opendocument:xmlns:script:1.0";
    public static final String config="urn:oasis:names:tc:opendocument:xmlns:config:1.0";
    public static final String ooo="http://openoffice.org/2004/office";
    public static final String ooow="http://openoffice.org/2004/writer";
    public static final String oooc="http://openoffice.org/2004/calc";
    public static final String dom="http://www.w3.org/2001/xml-events";
    public static final String xforms="http://www.w3.org/2002/xforms";
    public static final String xsd="http://www.w3.org/2001/XMLSchema";
    public static final String xsi="http://www.w3.org/2001/XMLSchema-instance";
}
