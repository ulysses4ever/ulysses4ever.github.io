/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Paragraph.java,v $
 *
 *  $Revision: 1.7 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;

import org.openoffice.odf.common.documenttype.ElementFactory;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.BlockElement;

import org.openoffice.odf.text.style.*;

import java.io.IOException;
import java.util.Iterator;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class Paragraph extends TextContentElement {
    
    /** ���������������� � ������������. Eliseev */
    private TextDocument parentTextDoc;
    private ParagraphStyle style = null;
        
    public Paragraph(Node node) {
        super.attach(node, new ParagraphContentImpl(node));
        setDescription("ODF Paragraph");
    }
    
    /** 
     * append text to the end of the paragraph with the style set for the paragraph
     *
     */
    public Portion addText(String text) {
        // add a text node with the new text at the end of the paragraph
        org.w3c.dom.Document doc = getNode().getOwnerDocument();
        Node textNode = doc.createTextNode(text);
        getNode().appendChild(textNode);
        TextContentFactory textfactory = (TextContentFactory)getFactory(doc);
        Element e = textfactory.getInlineElement(textNode, this);
        return (Portion) e;
    }
    
    /**
     * append text to the end of the paragraph with a specific style<br>
     * ��������� �� �������� ����� <code>Font</code>.<br>
     * Eliseev
     */
    @Deprecated
    public Portion addText(String text, Style style) {
	Portion p = addText(text);            
	p.setStyle(style);
	return p;
    }
    
    public Portion addText(String text, Font font) {
	StyleInfo stl = new StyleInfo(font);
	parentTextDoc.addStyleInfo(stl);
	return addText(text, new Style(stl.getName()));
    }
    
    /** 
     * insert text at the specified position with the style applied at that position
     */
    public void insertText(int pos, String text) {
        // find the portion that includes the position
        int cur = 0;
        for (Element inline : this) {
            if (inline instanceof Portion) {
                Portion portion = (Portion) inline;
                String content = portion.getText();                
                if ((cur + content.length()) >= pos) {
                    // we found the portion in which to insert
                    // get the relative insertion point
                    int ip = pos - cur;
                    content = content.substring(0, ip)
                            + text
                            + content.substring(ip);
                    portion.setText(content);
                    break;
                } else {
                    cur += content.length();
                }
            }
        }        
    }
    
    /** 
     * insert text at the specified position with a specific style
     * the style will be added to the style already applied at the 
     * specified position
     */
    public void insertText(int pos, String text, Style style) {
        insertText(pos, text);
    }         
    
    public Paragraph(OpenDocument od) {
        parentTextDoc = (TextDocument) od;
        try {            
            // create a new element in the DOM document
            Document doc = od.getDocument(OpenDocument.STREAMNAME_CONTENT);            
            Node node = doc.createElementNS(Namespaces.text, "text:p");
            
            // make the new node known to the base classes
            super.attach(node, new ParagraphContentImpl(node));
        } catch (Exception ex) {
            throw new RuntimeException("FIXME!!!");
            //ex.printStackTrace();
        }        
    }
    
    public Paragraph(OpenDocument od, String text) {
        this(od);
        addText(text);
    } 
     
    /*
     *  ��������� �� ������� ����� <code>ParagraphStyle</code>.<br>
     * Eliseev
     */
    @Deprecated
    public Paragraph(OpenDocument od, String text, Style style) {
        this(od, text);
        setStyle(style);
    }    
    
    /*
     *  �������� ��������� � ��������� ������.<br>
     * Eliseev
     */
    public Paragraph(TextDocument td, String text, ParagraphStyle stl) {
	this(td, text, new Style(stl.getName()));
	style = stl;
	td.addStyleInfo(stl);
    }
    
    /*
     *  ���������� ����� ���������, ���� �� ��� ������ ��� ���������������, ����� null.<br>
     * Eliseev
     */
    public ParagraphStyle getStyleInfo() { return style; }
}
