/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Portion.java,v $
 *
 *  $Revision: 1.6 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import org.openoffice.odf.common.documenttype.BlockElement;
import org.openoffice.odf.common.documenttype.InlineElement;

public class Portion extends InlineElement {    
    /** Creates a new instance of Portion */
    public Portion(Node node, BlockElement block) {
        super(node, block);
        setDescription("ODF Text portion");
        if (node.getNodeType()!=Node.TEXT_NODE)
            throw new IllegalArgumentException("text portion must start with text node");
    }
    
    public String getTextContent() {
        return toString();
    }
    
    public String getText() {
        return toString();
    }
    
    public String toString() {
        // the portion starts with a text node and includes all following
        // text siblings
        StringBuffer value = new StringBuffer();
        Node current = getNode();
        while (current != null && current.getNodeType() == Node.TEXT_NODE) {
            value.append(current.getNodeValue());
            current = current.getNextSibling();
        }        
        return value.toString().replaceAll("\\s+", " ").trim();
    }
        
    public String _dbgStyles() {
        // DEBUG: get appllied styles up to containing block
        Node current = getNode();
        String styleString = "{styles: ";
        do {
            current = current.getParentNode();
            NamedNodeMap attr = current.getAttributes();
            Node a = attr.getNamedItemNS(Namespaces.text, "style-name");
            if (a != null) {
                String s = a.getNodeValue();
                styleString += s + " ";                
            }

        } while (current != block.getNode() && current != null);
        styleString += "}";        
        return styleString;
    }
    
    /**
     *	����� �������� �� ������� � ������� StyleInfo.<br>
     * Eliseev
     */
    @Deprecated
    public void setStyle(Style style) {
       
        // create a new span element and move this node and all adjacent text nodes
        // underneath it        
        // the identity of the text node that represents the beginning of this portion
        // is retained...
        
        // XXX
        // if a span gets set to the same style as it's surroundings
        // it should be removed/merged
        
        Node node = getNode();        
        Node span = node.getOwnerDocument().createElementNS(Namespaces.text, "text:span");
        
        // set the style-name attribute of the new span element
        Attr a = node.getOwnerDocument().createAttributeNS(Namespaces.text, "text:style-name");
        a.setNodeValue(style.getName());
        span.getAttributes().setNamedItem(a);
        
        // replace the text node with the span element and add the text node to the new span
        Node parent = node.getParentNode();
        node = parent.replaceChild(span, node);
        span.appendChild(node);
        
        // move the remaining adjacent nodes to the new span
        node = span.getNextSibling();
        while (node != null && node.getNodeType() == Node.TEXT_NODE) {
            Node next = node.getNextSibling();
            node = node.getParentNode().removeChild(node);
            span.appendChild(node);
            node = next;
        }
    }

    public void setText(String content) {
        // put the new conent in the first text child and remove all 
        // adjacent text nodes
        
        Node current = getNode();

        // remove adjacent text nodes...
        current.setNodeValue(content);
        current = current.getNextSibling();
        while (current != null && current.getNodeType() == Node.TEXT_NODE) {
            Node next = current.getNextSibling();
            current.getParentNode().removeChild(current);
            current = next;
        }        
    }    
}
