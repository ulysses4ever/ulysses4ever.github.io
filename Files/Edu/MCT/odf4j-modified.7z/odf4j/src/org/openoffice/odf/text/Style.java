package org.openoffice.odf.text;

import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;

public class Style{

    private Node m_node;
    private String name; // for testing
    
    public Style(Node node) {
        m_node = node;
    }
    public Style(String name) {
        this.name = name;
    }

    
    public Style getParentStyle(){        
        return null;
    }
    
    String getName() {
        if (name != null) {
            return name;
        }
        
        Node a = m_node.getAttributes().getNamedItemNS(Namespaces.style, "name");
        if (a != null) {
            return a.getNodeValue();
        } else {
            return null;
        }
    }
}

