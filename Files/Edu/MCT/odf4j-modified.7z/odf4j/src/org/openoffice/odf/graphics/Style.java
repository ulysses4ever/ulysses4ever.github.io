/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Style.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.graphics;
/**
 *
 * @author duyunfen for testing
 */
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.openoffice.odf.schema.Namespaces;
import org.openoffice.odf.common.documenttype.ElementFactory;

public class Style extends GraphicElement{

    //private Node m_node = null;
    private String name = "style"; // for testing
    
    public Style(Node node) {
       super(node,new GraphicDrawImpl(node));
    }
    public Style(String name) {
        this.name = name;
    }
    
    public String getName() {
        Node currnode = getNode();
        if (name != null) {
            return name;
        }
        Node a = currnode.getAttributes().getNamedItemNS(Namespaces.style, "name");
        if (a != null) {
            return a.getNodeValue();
        } else {
            return null;
        }
    }
    
    public String getFamily(){
        Node currnode = getNode();     
        String strfam = null;
        if(currnode != null){
            strfam =  getAttibute(currnode,"style:family");
        }
        return strfam;
    }
    public String getParentStyleName(){
        Node currnode = getNode();
        String strpa = null;
        if(currnode != null ){
            strpa = getAttibute(currnode,"style:parent-style-name");
        }
        return strpa;
    }
  
      public void setAttribute(String attType,String value){
      Node currnode = getNode();
      NamedNodeMap map = currnode.getAttributes();
      Node attr = map.getNamedItem(attType);
      try{
          if(attr != null){
              attr.setNodeValue(value);
          }else{
              Attr a = currnode.getOwnerDocument().createAttributeNS(Namespaces.style,attType);
              a.setValue(value);
              map.setNamedItemNS(a);
          }
      } catch (Exception ex) {
          throw new IllegalArgumentException("fail to create attibute node");
      }
    }
  }


