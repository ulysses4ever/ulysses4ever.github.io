/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: ElementFactory.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.common.documenttype;
import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.graphics.*;
//import org.openoffice.odf.graphics.Image;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.lang.reflect.Method;

public abstract class ElementFactory{
    
    protected static  Map<Document,Reference<ElementFactory>> instanceMap;
    protected Map<Node,Element> elementMap;    
    
    public  ElementFactory() {}
    /**
     * get instance of child factory according node's owner document, if
     *it was not exist,then create it and save to instanceMap;
     */
    public static synchronized <T extends ElementFactory> ElementFactory getInstance(Document doc,Class<T> type) {        
        if (instanceMap == null) {
            instanceMap = new WeakHashMap<Document,Reference<ElementFactory>>();
        }
        // store element factories as soft references so they do not prevent
        // garbage collection of DOM trees when there are no other references
        // to a document.
        Reference<ElementFactory> ref = instanceMap.get(doc);        
        ElementFactory instance = null;
        if (ref == null || ref.get() == null) {
            //ref = new SoftReference<ElementFactory>(new ElementFactory());
            ref = new SoftReference<ElementFactory>(getFactory(type));
            instanceMap.put(doc, ref );
        }
        
        instance = (ElementFactory) ref.get();
        return instance;
    }    
    /**
     *attach factory in static instanceMap,
     */    
    public static synchronized void addInstance(ElementFactory factory,Document doc){
        Reference<ElementFactory> ref = new SoftReference<ElementFactory>(factory);
        instanceMap.put(doc, ref );
    }
    /**
     *attach current element in elementMap
     */
    public void addElement(Node node, Element e) {
        elementMap.put(node, e);
    }    
    
    /**
     *get textcontentelement's factory,because the textcontentelement 
     * was thought that offen been inserted into other blockElement.
     */
    public abstract ElementFactory getTextInstance();
    /**
     *it was detailed by specific element 
     */
    public abstract Element getElement(Node node);    
    /**
     *get graphicselement's factory,because the graphicselement could be 
     * included in other element,for example,textcontent
     */
    public abstract Element getInlineElement(Node n, BlockElement block);
    public abstract ElementFactory getGraphicsInstance();
    
     // scrap your boilerplate!!!
    protected <T extends Element> T getElement(Node node, Class<T> type) {
        try {
            T e = (T)elementMap.get(node);
            if (e == null) {
                Constructor<T> ctor = type.getConstructor(Node.class);
                e = ctor.newInstance(node);
            } 
            return e;
        } catch (Exception ex) {
            return null;
        }                
    }      

    private static <T extends ElementFactory> ElementFactory getFactory(Class<T> type){
        try{
            T e = null;
            Constructor<T> ctor = type.getConstructor();
            e = ctor.newInstance();
            return e;
        }catch(Exception ex){
            return null;
        }
    }    

}

