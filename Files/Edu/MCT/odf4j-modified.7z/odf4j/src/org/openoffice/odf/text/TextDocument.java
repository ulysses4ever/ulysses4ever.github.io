/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: TextDocument.java,v $
 *
 *  $Revision: 1.9 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;

import java.io.IOException;
import java.io.OutputStream;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import org.openoffice.odf.OdfPackage;
import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;

import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.ElementFactory;

import org.openoffice.odf.text.style.*;

/**
 * Class for working with OpenDocument text documents
 */
public class TextDocument extends OpenDocument {

    private Document doc = null;
    
    /** Eliseev */
    private java.util.List<StyleInfo> styles = new java.util.LinkedList<StyleInfo>();
    
    public TextDocument()
        throws IOException {
        super();
    }

    public TextDocument(OdfPackage pkg) {
        super(pkg);
    }
    
    public Body getBody() {
        try {
            
            // get DOM
            doc = getDocument(STREAMNAME_CONTENT);
            
            ElementFactory fac = ElementFactory.getInstance(doc,TextContentFactory.class);

            // find the body element
            NodeList nl = doc.getElementsByTagNameNS(Namespaces.office, "text");
            
            // XXX we might want to cache this to avoid searching for the element
            // again.
            Body body = (Body) fac.getElement(nl.item(0));
            return body;
        } catch (Exception ex) {
            return null;
        }
    }
    
    /** ����� �������� �� ������� ����� StyleInfo.<br>
     * Eliseev
     */
    @Deprecated
    public Node getStyle(String name){        
        StyleFactory s_fac = StyleFactory.getInstance(doc);
        
        //find the office:automatic-styles
        NodeList nl = doc.getElementsByTagNameNS(Namespaces.office, "automatic-styles");
        
        // no automatic styles?
        if (nl.getLength() == 0) return null;
        
        Node autostyles = nl.item(0);        
        //search for the requested style node...
        Node style = autostyles.getFirstChild();
        while (style != null) {
            if (style.getNodeType() == Node.ELEMENT_NODE) {
                NamedNodeMap map = style.getAttributes();
                Node attr = map.getNamedItemNS(Namespaces.style, "style-name");
                if (attr != null && attr.getNodeValue().equals(name)) {
                    // found the style node...
                    return style;
                }
            }
        }
        // not found...
        return null;
    }
        
    void addStyleInfo(StyleInfo stl) {
	if (!styles.contains(stl)) {
	    styles.add(stl);
	}
    }
    
     @Override
     public void save(OutputStream os, String baseURI) throws IOException {
	//��������� � �������� ��� ����������� �����
	NodeList nl = doc.getElementsByTagNameNS(Namespaces.office, "automatic-styles");
	if (nl.getLength() == 0)
	    throw new IOException("<office:automatic-styles> element not found");
	Node autostyles = nl.item(0);
	for (StyleInfo stl : styles) {
	    stl.appendStyleTag(autostyles);
	}

	super.save(os, baseURI);

	//������� ��� ��������� �����, ����� �� ����� ����� ���� ��������
	while (autostyles.hasChildNodes()) {
	    autostyles.removeChild(autostyles.getFirstChild());
	}
     }
    
    /**
     * Implementation of the abstract method from
     * the OpenDocument base class returns a Stream
     * for an empty Text document
     */
    protected InputSource emptyDocumentTemplate() {
        EntityResolver resolver=getEntityResolver();
        InputSource is=null;
        try {
            is=resolver.resolveEntity(null,"resource:/org/openoffice/odf/template/TextDocument.odt");
        } catch ( Exception e ) {
        }
        return is;
    }
}
