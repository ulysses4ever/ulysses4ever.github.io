/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: ListItem.java,v $
 *
 *  $Revision: 1.7 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/
package org.openoffice.odf.text;

import org.openoffice.odf.OpenDocument;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import org.openoffice.odf.text.style.*;

public class ListItem extends TextContentElement{
    
    /** Creates a new instance of ListItem */
    public ListItem(Node node) {
        super(node);
        setDescription("ODF List Item");
    }
    
    public ListItem(OpenDocument od) {
        super(od,"text:list-item");
        /*try {            
            // create a new element in the DOM document
            Document doc = od.getDocument(OpenDocument.STREAMNAME_CONTENT);            
            Node node = doc.createElementNS(Namespaces.text, "text:list-item");
            // make the new node known to the base classes
            attach(node);            
        } catch (Exception ex) {
            throw new RuntimeException("FIXME!!!");
        }    */      
    }    
    
    public ListItem(OpenDocument od, String text) {
        this(od);
        Paragraph p = new Paragraph(od, text);
        add(p);
    }
    
    public ListItem(OpenDocument od, Paragraph p) {
        this(od);
        add(p);
    }
    
    public ListItem(TextDocument td, String text, ParagraphStyle style) {
        this(td);
        add( new Paragraph(td, text, style));
    }
    
    public void addParagraph(Paragraph p) {
        add(p);
    }
}
