
package org.openoffice.odf.text;

public interface TextContentContainer {
        
}
