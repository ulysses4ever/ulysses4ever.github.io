/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: Polyline.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:50 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.graphics;

import org.openoffice.odf.OpenDocument;
import org.w3c.dom.Node;
import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.StringTokenizer;
import java.awt.Point;
/**
 *
 * @author duyunfen
 */
public class Polyline extends GraphicElement{
    
    private ArrayList<Point> m_pointList;
    
    /** Creates a new instance of Polyline */
    public Polyline() {
        super();
    }
    
    public Polyline(Node node){
       super(node);
       if(node.getNodeName()!="draw:polyline"){
         throw new IllegalArgumentException("not a polyline node initialized");   
      } 
    }    
    
    public Polyline(OpenDocument od){
        super(od,"draw:polyline");
    }

    public ArrayList<Point> getPointslist(){
        String spoints = this.getAttriStringValue("draw:points");
        StringTokenizer st = new StringTokenizer(spoints," ");
        while( st.hasMoreElements() ){ 
             String[] sn = st.nextToken().split(",");
             Point cenPt = new Point(0,0);
             cenPt.setLocation(Integer.parseInt(sn[0]),Integer.parseInt(sn[1]));
             m_pointList.add(cenPt); 
        }

        return m_pointList;
    }
    
    public int pointListSize() {
        return m_pointList.size();
    }

    public boolean isPointListEmpty() {
        return m_pointList.isEmpty();
    }

    public Iterator<Point> pointIterator() {
        return m_pointList.iterator();
    }

    public boolean addPoint(Point e) {
        return m_pointList.add(e);
    }

    public boolean removePoint(Object o) {
        return m_pointList.remove(o);
    }

    public void clearPointList() {
        m_pointList.clear();
    }

    public Point getPoint(int index) {
        return m_pointList.get(index);
    }

    public Point setPoint(int index, Point p) {
        return m_pointList.set(index, p);
    }

    public void addPoint(int index, Point p) {
        m_pointList.add(index, p);
    }

    public Point removePoint(int index) {
        return m_pointList.remove(index);
    }

    public int pointIndexOf(Object o) {
        return m_pointList.indexOf(o);
    }

    public int pointLastIndexOf(Object o) {
        return m_pointList.lastIndexOf(o);
    }
}
