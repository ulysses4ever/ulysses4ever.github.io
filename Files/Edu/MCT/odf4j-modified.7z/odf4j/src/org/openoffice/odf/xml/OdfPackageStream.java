/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: OdfPackageStream.java,v $
 *
 *  $Revision: 1.1 $
 *
 *  last change: $Author: bei $ $Date: 2007/03/05 16:29:15 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

package org.openoffice.odf.xml;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import org.openoffice.odf.manifest.FileEntry;
import org.openoffice.odf.OdfPackage;

/**
 * OdfPackageStream is a representation of a stream that is part of an ODF file.
 * If a stream is written to through the output stream, this will be
 * reflected when the output stream is closed
 *
 */
public class OdfPackageStream extends StreamSource {
    
    private OdfPackage pkg;
    private String name;
    private InputStream inputStream;
    private OutputStream outputStream=null;
    private boolean bClosed;
    
    public OdfPackageStream(OdfPackage pkg, String name)
        throws IOException {

        super(pkg.getXMLInputStream(name), pkg.getBaseURI()+"/"+name);
        this.pkg=pkg;
        this.inputStream = inputStream;
        this.outputStream = outputStream;
        this.name=name;
    }
    
    public boolean isOutput() {
    // denote that the output stream has been requested
        return outputStream!=null;
    }
    
    public OutputStream getOutputStream() throws IOException {
        if (bClosed) throw new IOException("stream already closed");
        OutputStream outputStream = pkg.getOutputStream(name);
        return outputStream;
    }
        
    public FileEntry geFileEntry() {
        return pkg.getFileEntry(name);
    }

    public String getName() {
        return name;
    }
    
    public OdfPackage getPackage() {
        return pkg;
    }

    void close() throws IOException {
        bClosed = true;
        inputStream.close();
        outputStream.close();
    }
    
}
