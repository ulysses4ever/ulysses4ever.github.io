package org.openoffice.odf.text.style;

import org.w3c.dom.*;
import org.openoffice.odf.schema.Namespaces;

/**
 *
 * @author Eliseev
 */
public class Font {
    public static final int BOLD = 1,
			     ITALIC = 2,
			     UNDERLINED = 4;
    
    private int size = 12;
    private boolean bold = false, italic = false, underlined = false;
    private String fontName;
    
    /** Creates a new instance of Font */
    public Font() {
	this(12, 0);
    }
    
    public Font(String fontName, int size, int fontStyle) {
	this(size, fontStyle);
	this.fontName = fontName;
    }
    
    public Font(int size) {
        this(size, 0);
    }
    
    public Font(int size, int fontStyle) {
	this.size = size;
	this.fontName = fontName;
	bold = (fontStyle & BOLD) > 0;
	italic = (fontStyle & ITALIC) > 0;
	underlined = (fontStyle & UNDERLINED) > 0;
    }
    
    void appendFontTag(Node toElement) {
	Node result = toElement.getOwnerDocument().createElementNS(Namespaces.style, "style:text-properties");
	toElement.appendChild(result);
	
	addAttr("fo","font-weight",bold,"bold",result,Namespaces.fo);
	addAttr("style","font-weight-asian",bold,"bold",result,Namespaces.style);
	addAttr("style","font-weight-complex",bold,"bold",result,Namespaces.style);

	addAttr("fo","font-style",italic,"italic",result,Namespaces.fo);
	addAttr("style","font-style-asian",italic,"italic",result,Namespaces.style);
	addAttr("style","font-style-complex",italic,"italic",result,Namespaces.style);
	
	if (underlined) {
	    StyleInfo.addAttr("style","text-underline-style","solid", result,Namespaces.style);
	    StyleInfo.addAttr("style","text-underline-width","auto", result,Namespaces.style);
	    StyleInfo.addAttr("style","text-underline-color","font-color", result,Namespaces.style);
	} else {
	    StyleInfo.addAttr("style","text-underline-style","none", result,Namespaces.style);
	}
	
	String strSize = Integer.toString(size) + "pt";
	StyleInfo.addAttr("fo","font-size",strSize, result,Namespaces.fo);
	StyleInfo.addAttr("style","font-size-asian",strSize, result,Namespaces.style);
	StyleInfo.addAttr("style","font-size-complex",strSize, result,Namespaces.style);
	
	if (fontName != null) {
	    StyleInfo.addAttr("style","font-name",fontName, result,Namespaces.style);
	}
    }
    
    private void addAttr(String ns, String name, boolean value, String trueValue, Node n, String namespace) {
	Attr attr = n.getOwnerDocument().createAttributeNS(namespace, ns + ":" + name);
	attr.setNodeValue(value ? trueValue : "normal");
	n.getAttributes().setNamedItem(attr);
    }

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public boolean isBold() {
		return bold;
	}

	public void setBold(boolean bold) {
		this.bold = bold;
	}

	public boolean isItalic() {
		return italic;
	}

	public void setItalic(boolean italic) {
		this.italic = italic;
	}

	public boolean isUnderlined() {
		return underlined;
	}

	public void setUnderlined(boolean underlined) {
		this.underlined = underlined;
	}

	public String getFontName() {
		return fontName;
	}

	public void setFontName(String fontName) {
		this.fontName = fontName;
	}
    
}
