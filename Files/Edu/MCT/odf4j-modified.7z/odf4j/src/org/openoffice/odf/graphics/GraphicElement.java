/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: GraphicElement.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: bei $ $Date: 2008/02/22 14:34:49 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2007 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/


package org.openoffice.odf.graphics;
import org.openoffice.odf.OpenDocument;
import org.w3c.dom.Document;
import org.openoffice.odf.common.documenttype.Element;
import org.openoffice.odf.common.documenttype.ElementFactory;
import org.openoffice.odf.schema.Namespaces;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Attr;
import java.awt.Point;
import org.openoffice.odf.common.documenttype.BlockElement;

import org.w3c.dom.Node;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.openoffice.odf.text.TextContentElement;

/**
 *
 * @author duyunfen
 */
public class GraphicElement extends BlockElement{
    //protected Node drawNode = null;
    protected String shapeName = "GraphicShape";
    /** Creates a new instance of GraphicElement */
    public GraphicElement() {
        super();
    }
    
    public GraphicElement(Node node){
       attach(node);
    }
    
    public GraphicElement(Node node,List<Element> contentList){
        attach(node,contentList);
    }
    
    public void attach(Node node){
        this.attach(node,new GraphicDrawImpl(node));   
    }

    protected void attach(Node node,List<Element> contentList){
        super.attach(node,contentList);
        attachElement(node);
    }    

    private void attachElement(Node node){
        ElementFactory fac = getFactory(node.getOwnerDocument());
        fac.addElement(node, this);            
    }
  
    /**
     *get the factory associated with current element
     */
   public ElementFactory getFactory(Document doc){
        ElementFactory fac = null;
        fac = ElementFactory.getInstance(doc,GraphicsElementFactory.class);
        return fac;
    }
         
    protected GraphicElement(OpenDocument od, String name){
        Node node  = null;
        try {        
            Document doc = od.getDocument(OpenDocument.STREAMNAME_CONTENT);
            node = doc.createElementNS(Namespaces.draw,name);
            attach(node);
        } catch (Exception ex) {      
        }        
    }
 
    public Element getParent() {
       ElementFactory fac = null; 
       Node node = getNode();
       fac = getFactory(node.getOwnerDocument());
       return fac.getElement(node.getParentNode());
    }    
    
    public String getTextContent(){
       TextContentElement textcontent = new TextContentElement(getNode());
       return textcontent.getTextContent();
    }
    
   /*initial the default attributes node*/
    public void initial(){
        //setLayerName("layout");
    }   
    
   /**
    *shape's common function 
    */     
    public String getDrawName(){
        return getAttriStringValue("draw:name");
    }
    
    public String getDrawID(){
        return getAttriStringValue("draw:id");
    }
    
   public String getStyleName(){
       return getAttriStringValue("draw:style-name");
   }
   
   public String getTextStyleName(){
        return getAttriStringValue("draw:text-style-name");
   }  
   
    public String getLayerName(){
        return getAttriStringValue("draw:layer");
    }
    public void setLayerName(String slay){
        setAttribute(Namespaces.draw,"draw:layer",slay);        
    }
    
    /**
     * set the position attribute svg:x and svg:y 
     */   
    public float getPositionX(){
        return getAttriFloatValue("svg:x");
    }
    public void setPositionX(float x){
        setAttribute(Namespaces.draw,"svg:x",Float.toString(x));
    }
       
   public float getPositionY(){
        return getAttriFloatValue("svg:y");
    }
   public void setPositionY(float y){
       setAttribute(Namespaces.draw,"svg:x",Float.toString(y));
   }
   
   /** 
    * size 
    */
    public float getWidth(){
        return getAttriFloatValue("svg:width");
    }
    public void setWidth(float width){
        setAttribute(Namespaces.draw,"svg:width",Float.toString(width));
    }
    
   public double getHeight(){
        return getAttriFloatValue("svg:width");
   }
   public void setHeight(float height){
       setAttribute(Namespaces.draw,"svg:height",Float.toString(height));
   }
   /***/
   
    protected Point getAttriPointValue(String sxName,String syName){
         Point cenPt =  new Point(0,0);
         String cx = getAttriStringValue(sxName);  
         String cy = getAttriStringValue(syName);    
         cx = cx.substring(0,cx.length()-2);
         cy = cy.substring(0,cy.length()-2);
         cenPt.setLocation(Double.parseDouble(cx),Double.parseDouble(cy));
         return cenPt;        
    }
    
    protected float getAttriFloatValue(String srName){
       float r = -1;
       String sr = getAttriStringValue(srName);
       sr = sr.substring(0,sr.length()-2);
       r = Float.parseFloat(sr);
       return r;        
    }
    
    protected String getAttriStringValue(String sName){
       String sValue = null;
       Node drawNode = getNode();
       if(drawNode != null){
            sValue = this.getAttibute(drawNode,sName);
       }else{
           return null;
       }
       return sValue;        
    }   
    
    protected int getAttriIntValue(String sName){
        int ivalue = -1;
        String spid = getAttriStringValue(sName);
        spid = spid.substring(0,spid.length()-2);
        ivalue = Integer.parseInt(spid);        
        return ivalue;
    }
    public String getStyle(){
        return "odf graphics's style";
    }
}
