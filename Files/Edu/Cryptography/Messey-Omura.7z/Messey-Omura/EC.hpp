#pragma once
#include <iostream>
#include <cctype>
#include <string>
#include "GFTraits.hpp"
namespace MOP_NS {

template <typename GF, typename CardinalityT = long>
class EC {
	// elliptic curve over Galois field F, char(F) != 2, 3;
	/*static */GF a;
	/*static */GF b;
	/*static */CardinalityT n;
public:
	// ec-points
	class Point {
		const EC& curve;
		Point(const EC& curve_, const GF& x_, const GF& y_) : curve(curve_), x(x_), y(y_) {}

		Point(const EC& curve_, long x_, long y_) : curve(curve_),
				x(GFTraits<GF>::convertFromLong(x_)), y(GFTraits<GF>::convertFromLong(y_)) {}
		friend class EC;
	public:
		GF x;
		GF y;
		Point(const Point& p) : curve(p.curve), x(p.x), y(p.y) {}

		Point& operator=(const Point& p) {
			x = p.x;
			y = p.y;
			return *this;
		}
		
		const EC& getCurve() const {return curve;}

		friend inline
		bool operator==(const Point& a, const Point& b) {
			return (a.x == b.x)	&& (a.y == b.y);
		}
	};

	//static void init(const GF& a_, const GF& b_, const CardinalityT& n_ = 0) {
	EC(const GF& a_, const GF& b_, const CardinalityT& n_ = 0) :
		a(a_),
		b(b_),
		n(n_),
		O(*this, GFTraits<GF>::zero(), GFTraits<GF>::zero()) {}
		// O = EC<GF>(GFTraits<GF>::zero(), GFTraits<GF>::zero());

	Point newPoint(const GF& x, const GF& y) const {
		return Point(*this, x, y);
	}

	Point newPoint(long x, long y) const {
		return Point(*this, x, y);
	}

	Point newPoint(Point p) const {return Point(p);}

	CardinalityT getCardinality() const {
		return n;
	}

	Point add(const Point& a, const Point& b) const {
		if (a == b)
			return doubling(a);
		else {
			return addingDifferent(a, b);
		}
	}

	Point doubling(const Point& p) const {
		// generic doubling NIY
	};

	Point addingDifferent(const Point& a, const Point& b) const {
		// generic addingDifferent NIY
	}

	/*static EC<GF>*/ Point O; // point at infinity
private:
	friend /*template< typename GF, typename LongInt >*/
		typename EC<GF, CardinalityT>::Point exp(const /*typename EC<GF>::*/Point& x, const CardinalityT& pow);
};

template< typename GF, typename LongInt > inline
typename EC<GF>::Point exp(const typename EC<GF>::Point& x, const LongInt& pow) {
	typename EC<GF>::Point res = x.getCurve().newPoint(x);
	for(LongInt i = 0; i < pow; ++i) {
		x.getCurve().add(res, x);
	}
	return res;
}

template<> inline
typename EC<NTL::ZZ_p>::Point EC<NTL::ZZ_p>::doubling(const typename EC<NTL::ZZ_p>::Point& p) const {
	using namespace NTL;
	if (p.y == ZZ_p::zero() || !(p == O))
		return O;
	ZZ_p temp( (3*sqr(p.x) + p.getCurve().a) / (2*p.y));
	ZZ_p x(	sqr(temp) - 2*p.x );
	ZZ_p y( temp*(p.x - x) - p.y);
	return p.getCurve().newPoint(x, y);
};

template<> inline
typename EC<NTL::ZZ_p>::Point EC<NTL::ZZ_p>::addingDifferent
				(const typename EC<NTL::ZZ_p>::Point& a, const typename EC<NTL::ZZ_p>::Point& b) const {
	using namespace NTL;
	ZZ_p temp( (b.y - a.y) / (b.x - a.x) );
	ZZ_p x( sqr(temp) - a.x - b.y);
	ZZ_p y( temp*(a.x - x) - a.y);
	return a.getCurve().newPoint(x, y);
}


inline
std::ostream& operator<<(std::ostream& os, const MOP_NS::EC<NTL::ZZ_p, long>::Point& p) {
	os << "(" << p.x << ", " << p.y << ")";
	return os;
}

inline
std::istream& operator>>(std::istream& is, MOP_NS::EC<NTL::ZZ_p, long>::Point& p) {
	using namespace std;
	static char delimStub;
//	if (is.eof())
		is >> delimStub >> p.x >> delimStub >> p.y >> delimStub;
	//else 
	//	is >> delimStub;
	return is;
}


} // MOP_NS

//template< typename GF, typename LongInt> 
