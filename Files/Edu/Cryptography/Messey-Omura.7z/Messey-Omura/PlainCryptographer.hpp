#pragma once
#include <vector>
#include <utility>
#include <functional>
#include <algorithm>
#include <boost/bind.hpp>
#include <NTL/ZZ_p.h>
#include "EC.hpp"
#include "defines.hpp"

using std::vector;
using std::pair;
using std::transform;

namespace MOP_NS {

	typedef unsigned char byte;

// PlainCryptographer works only with EC-points
// so the text for him is just a collection of points
// algoithms of en(de)crypting and key generation are his concerns
template< typename GF, typename LongInt = long >
class PlainCryptographer : EcCryptosystemTraits<GF, LongInt> {
	typedef pair<LongInt, LongInt> KeyPair;

public:
	PlainCryptographer() : curve(GFTraits<GF>::convertFromLong(4), GFTraits<GF>::convertFromLong(20), 37), 
		a_() {}

	const ECOverGF& getCurve() const {return curve;}

	void chipherFirstPhase(PointContainer& plainText) {
		KeyPair k = genKey();
		LongInt a = k.first;
		a_= k.second;
		chipherAText(plainText, a);
		//for(long i = 0; i < plainText.size(); ++i) {
		//	plainText.push_back(exp<GF>(plainText[i],a));
		//}
	}

	void chipherSecondPhase(PointContainer& text) {
		chipherAText(text, a_);
	}

private:
	ECOverGF curve;
	LongInt a_;

	KeyPair genKey() {
		// generic random key generation NIY
	}

	void chipherAText(PointContainer& text, const LongInt& power) {
		transform(text.begin(), text.end(), text.begin(), 
			boost::bind(&exp<GF, LongInt>, _1, power));	
	}

}; // Cryptographer

template<> inline
PlainCryptographer<NTL::ZZ_p>::KeyPair PlainCryptographer<NTL::ZZ_p>::genKey() {
	using namespace NTL;
	ZZ_pBak bak;
	bak.save();

	long n = curve.getCardinality();
	ZZ_p::init(to_ZZ(n));
	long a = RandomBnd(n);
	long a_ = to_long( rep( inv(to_ZZ_p(a)) ) );	// assume n is prime, so random a is invertible mod n
	KeyPair k = KeyPair(a, a_);

	bak.restore();
	return k;
}

} // MOP_NS