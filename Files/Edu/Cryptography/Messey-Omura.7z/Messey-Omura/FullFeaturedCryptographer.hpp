#pragma once
#include <string>
#include <fstream>
#include <boost/shared_ptr.hpp>
#include "PlainCryptographer.hpp"
#include "IOManager.hpp"
#include "defines.hpp"

namespace MOP_NS {

using std::string;

// Environment-aware cryptographer; 
// stores results of job done by PlainCryptographer;
// receiving and sending raw data still are not in his concern 
// - see concrete sublcasses (Alice and Bob)
template< typename GF, typename LongInt = long >
class FullFeaturedCryptographer : EcCryptosystemTraits<GF, LongInt> {
	typedef typename IOManager<GF, LongInt> IOManager;

	static const char defaultIntermediateRepositoryName[];
	static const char defaultDestinationName[];

	boost::shared_ptr< IOManager > iomanager;

	string intermediateRepositoryName;
	string destinationName;
	
public:
	FullFeaturedCryptographer() : 
		cryptographer(),
		iomanager( new FileIOManager<GF, LongInt>()),
		intermediateRepositoryName(defaultIntermediateRepositoryName),
		destinationName(defaultDestinationName) {}

	void doChiper(const std::string& sourceName) {
		receiveData(sourceName);	// fill data-field
		cryptographer.chipherFirstPhase(data);
		storeData(intermediateRepositoryName);
		data.clear();
		wait();
		renewData(intermediateRepositoryName);
		cryptographer.chipherSecondPhase(data);
		sendData(destinationName);
 	}

	virtual ~FullFeaturedCryptographer() {}

protected:
	PointContainer data;
	PlainCryptographer<GF, LongInt> cryptographer;

	virtual void receiveData(const std::string& sourceName) = 0;
	virtual void sendData(const std::string& sourceName) = 0;
	virtual void wait() = 0;

	void storeData(const string& dest) {
		iomanager->openSource(dest, IOManager::write);
		iomanager->storePointsToSource(data);
		iomanager->closeSource();
	}

	void renewData(const string& src) {
		iomanager->openSource(src, IOManager::read);
		iomanager->collectPointsFromSource(data, cryptographer.getCurve().O);
		iomanager->closeSource();
	}
};

template< typename GF, typename LongInt >
const char FullFeaturedCryptographer<GF, LongInt>::defaultIntermediateRepositoryName[] = "chiphred";

template< typename GF, typename LongInt >
const char FullFeaturedCryptographer<GF, LongInt>::defaultDestinationName[] = "result";

}
