#pragma once
#include <NTL/ZZ_p.h>

namespace MOP_NS {

template <typename T>
class GFTraits {
public:
	static T zero() {
		return T();
	}

	static void init(long charGF) {}

	static T convertFromLong(long a) {
		return T(a);
	}
};

template<> inline
NTL::ZZ_p GFTraits<NTL::ZZ_p>::convertFromLong(long a) {
	return NTL::to_ZZ_p(a);
}

template<> inline
void GFTraits<NTL::ZZ_p>::init(long charGF) {
	NTL::ZZ_p::init(NTL::to_ZZ(charGF));
}

}