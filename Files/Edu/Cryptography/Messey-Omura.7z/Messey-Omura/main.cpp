#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iterator>
#include <sstream>
#include <stdexcept>
#include <cstdlib>
#include <boost/shared_ptr.hpp>
#include <NTL/ZZ_p.h>

#include "EC.hpp"
#include "PlainCryptographer.hpp"
#include "Alice.hpp"
#include "Bob.hpp"
#include "FullFeaturedCryptographer.hpp"

using namespace std;
using namespace NTL;
using namespace MOP_NS;

typedef EC<ZZ_p> ECOverGF;
typedef ECOverGF::Point Point;

 int main(int argc, char* argv[]) {

	if( argc < 3 ) {
		cout << "You must point out the mode (-A or -B for Alice and Bob)\n" 
				"and target file name.";
		return 1;
	}

	int p = 29;
	ZZ_p::init(to_ZZ(p));

	boost::shared_ptr<FullFeaturedCryptographer<ZZ_p> > cr;
	if( mode == 'A') {
		 cr = boost::shared_ptr<FullFeaturedCryptographer<ZZ_p> >(new Alice<ZZ_p>());
	} else {
		cr = boost::shared_ptr<FullFeaturedCryptographer<ZZ_p> >(new Bob<ZZ_p>());
	}

	cr->doChiper(string(sourceFileName));
}





