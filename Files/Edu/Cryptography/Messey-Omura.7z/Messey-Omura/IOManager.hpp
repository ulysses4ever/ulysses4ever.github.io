#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include "EC.hpp"
#include "defines.hpp"

namespace MOP_NS {

	template< typename GF, typename LongInt = long >
	class IOManager : public EcCryptosystemTraits<GF, LongInt> {
	public:
		enum {read = 1, write = 2, binary = 4};
		
		virtual void openSource(const std::string& name, int mode) = 0;
		virtual void closeSource() = 0;
		
		virtual /*int */void getBytesFromSource(byte* const buffer, int length) = 0;
		virtual void sendBytesToSource(const byte* const buffer, int length) = 0;
		
		// pointOnTheCurve - to locate upcoming points on a particular curve
		// it could be also done from additional information in source - NIY
		virtual void collectPointsFromSource(PointContainer& container, typename ECOverGF::Point pointOnTheCurve) = 0;
		virtual void storePointsToSource(const PointContainer& container) = 0;

		virtual bool isSourceEmpty() = 0;

		virtual ~IOManager() {};
	};

	template< typename GF, typename LongInt = long >
	class FileIOManager : public IOManager<GF, LongInt> {
		std::ios_base::open_mode mode;
		std::fstream file;
	public:
		void openSource(const std::string& name, int mode_) {
			mode = std::ios_base::open_mode();
			if (mode_ & read)
				mode |= std::ios::in;
			if (mode_ & write) {
				mode |= std::ios::out;
			}
			if (mode_ & binary)
				mode |= std::ios::binary;
			file.open(name.c_str(), mode);
			if (! file.is_open()) throw std::runtime_error("File not found");
		}

		void closeSource() {
			file.clear();
			file.close();
		}

		/*int */void getBytesFromSource(byte* const buffer, int length) {
			/*return */file.read/*some*/((char*)buffer, length);
		}

		void sendBytesToSource(const byte* const buffer, int length) {
			file.write((char*)buffer, length);
		}

		void collectPointsFromSource(PointContainer& container, typename ECOverGF::Point pointOnTheCurve) {
			while(file.peek() != std::istream::traits_type::eof()) {
				file >> pointOnTheCurve;
				container.push_back(pointOnTheCurve);
			}
		}

		void storePointsToSource(const PointContainer& container) {
			copy(container.begin(), container.end(),
				ostream_iterator<ECOverGF::Point>(file));
		}

		bool isSourceEmpty() {return !(bool)file;}
	};
}
