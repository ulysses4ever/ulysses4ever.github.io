#pragma once
#include <vector>
#include "EC.hpp"
namespace MOP_NS {
template< typename GF, typename LongInt = long>
class EcCryptosystemTraits {
public:
	typedef typename EC<GF, LongInt> ECOverGF;
	typedef std::vector< typename ECOverGF::Point > PointContainer;
};

typedef unsigned char byte;
}