#pragma once
#include <string>
#include <iostream>
#include <cstring>
#include <cmath>
#include <boost/shared_ptr.hpp>
#include <boost/foreach.hpp>
#include <boost/bind.hpp>
#include <boost/ref.hpp>
#include "IOManager.hpp"
#include "EC.hpp"
#include "defines.hpp"

namespace MOP_NS {

using std::string;

template< typename GF, typename LongInt = long>
class Coder : EcCryptosystemTraits<GF, LongInt> {
	static const int blockSize = 32;
	typedef typename IOManager<GF, LongInt> IOManager;

	boost::shared_ptr< IOManager > iomanager;

	byte blockBuffer[blockSize];
public:
	Coder() : curve(GFTraits<GF>::convertFromLong(4), GFTraits<GF>::convertFromLong(20), 37),
				iomanager(new FileIOManager<GF>){
		initMsgsMap();
	}

	void encodeSource(const std::string& sourceName, PointContainer& container) {
		iomanager->openSource(sourceName, IOManager::read | IOManager::binary);
		//int count = 42;
		while( !iomanager->isSourceEmpty() ) {  //(count = iomanager->getBytesFromSource(blockBuffer, blockSize)) == blockSize
			std::memset(blockBuffer, 0, blockSize);
			iomanager->getBytesFromSource(blockBuffer, blockSize);
			encodeBufferized(container);
		}
		iomanager->closeSource();
	}

	void encodeBufferized(PointContainer& codedText, int symsToEncode = blockSize) const {
		//byte* data = (byte*)blockBuffer;
		//for(long i = 0; i < symsToEncode; ++i) {
		//	codeAByte(*data, codedText);
		//	++data;
		//}
		std::for_each(blockBuffer, blockBuffer + symsToEncode, 
			boost::bind(&Coder<GF, LongInt>::codeAByte, 
				*this, _1, boost::ref(codedText)));
	}

	//void decode(const vector<typename ECOverGF::Point>& text, byte* data, long len) const {
	//	typename vector<typename ECOverGF::Point>::const_iterator it = text.begin();
	//	for(long i = 0; i < len; ++i) {
	//		decodeAByte(it, *data);
	//		++data;
	//	}
	//}

	//void decode(const string& source, const string& dest, typename ECOverGF::Point pointOnCurve) const {
	//	iomanager->openSource(source, IOManager::read);
	//	PointContainer data;
	//	iomanager->collectPointsFromSource(data, pointOnCurve);
	//	iomanager->closeSource();
	//	this->decode(data, dest, pointOnCurve);
	//}

	void decode(const PointContainer& data, const string& dest, typename ECOverGF::Point pointOnCurve) {
		iomanager->openSource(dest, IOManager::write | IOManager::binary);
		typename PointContainer::const_iterator it = data.begin();
		while( it != data.end() ) {
			//std::for_each(blockBuffer, blockBuffer + symsToEncode, 
			//	boost::bind(&Coder<GF, LongInt>::decodeAByte, 
			//		*this, boost::ref(codedText), _1));
			for( byte* buf = blockBuffer; buf != blockBuffer + blockSize; ++buf ) {
				decodeAByte(it, *buf);
			}
			iomanager->sendBytesToSource(blockBuffer, blockSize);
		}
		iomanager->closeSource();
	}

	void codeAByte(byte b, PointContainer& codedText) const {
		static const byte mask = (byte)pow((float)2, msgLen) - 1; // 0x0F for msgLen = 4 bits
		for( int j = 0; j < bitsInByte / msgLen; ++j ) {
			ECOverGF::Point p = msgsMap[b & mask];
			codedText.push_back(p);
			b >>= msgLen;
		}	
	}

	//void decodeAByte(typename vector<typename ECOverGF::Point>::const_iterator& sym, byte& b) const {
	//	byte shift = 0;
	//	b = 0;
	//	for( int j = 0; j < bitsInByte / msgLen; ++j ) {
	//		vector<typename ECOverGF::Point>::const_iterator it = std::find(msgsMap.begin(), msgsMap.end(), *sym);
	//		b |= (byte)(it - msgsMap.begin()) << shift;
	//		shift += msgLen;
	//		++sym;
	//	}
	//}

	void decodeAByte(typename PointContainer::const_iterator& symIt, byte& b) const {
		b = 0;
		typename PointContainer::const_iterator it = std::find(msgsMap.begin(), msgsMap.end(), *symIt++);
		b = (byte)(it - msgsMap.begin());
		it = std::find(msgsMap.begin(), msgsMap.end(), *symIt++);
		b |= (byte)(it - msgsMap.begin()) << msgLen;
	}

private:
	static const int msgLen = 4;
	
	static const int bitsInByte = 8;

	PointContainer msgsMap;

	ECOverGF curve;

	void initMsgsMap();

};

template< typename GF, typename LongInt> inline
void Coder<GF, LongInt>::initMsgsMap() {
	msgsMap.reserve((long)pow((float)2, msgLen)); 
	msgsMap.push_back(curve.newPoint(2,6));
	msgsMap.push_back(curve.newPoint(4,19)); 
	msgsMap.push_back(curve.newPoint(8,10));
	msgsMap.push_back(curve.newPoint(13,23));
	msgsMap.push_back(curve.newPoint(16,2)); 
	msgsMap.push_back(curve.newPoint(19,16));
	msgsMap.push_back(curve.newPoint(27,2));
	msgsMap.push_back(curve.newPoint(0,7));
	msgsMap.push_back(curve.newPoint(2,23));
	msgsMap.push_back(curve.newPoint(5,7)); 
	msgsMap.push_back(curve.newPoint(8,19));
	msgsMap.push_back(curve.newPoint(14,6));
	msgsMap.push_back(curve.newPoint(16,27));
	msgsMap.push_back(curve.newPoint(20,3));
	msgsMap.push_back(curve.newPoint(27,27));
	msgsMap.push_back(curve.newPoint(0,22));
}

}