#pragma once
#include <string>
#include <fstream>
#include <boost/shared_ptr.hpp>
#include "FullFeaturedCryptographer.hpp"
#include "Coder.hpp"
#include "defines.hpp"

namespace MOP_NS {

// Encoding-aware cryptographer;
// the concluder in Three-Pass protocol (Massey-Omura protocol, in particular)
template< typename GF, typename LongInt = long >
class Bob : public FullFeaturedCryptographer<GF, LongInt> {
	Coder<GF, LongInt> coder;
public:
	Bob() : FullFeaturedCryptographer<GF, LongInt>(), coder() {}

private:
	void receiveData(const std::string& sourceName) {
		renewData(sourceName);
	}

	void sendData(const std::string& destination) {
		coder.decode(data, destination, cryptographer.getCurve().O);
	}

	// not portable and even console environment-dependent implementation;
	// possible better implementation is as a callback
	void wait() {
		cout << "Waiting for Alice move...\n" << endl;
		system("pause");
	}
};
}