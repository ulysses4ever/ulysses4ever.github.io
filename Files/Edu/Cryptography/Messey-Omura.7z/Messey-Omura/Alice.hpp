#pragma once
#include <string>
#include <fstream>
#include <boost/shared_ptr.hpp>
#include "FullFeaturedCryptographer.hpp"
#include "Coder.hpp"
#include "defines.hpp"

namespace MOP_NS {

// Encoding-aware cryptographer;
// the beginner in Three-Pass protocol (Massey-Omura protocol, in particular)
template< typename GF, typename LongInt = long >
class Alice : public FullFeaturedCryptographer<GF, LongInt> {
	Coder<GF, LongInt> coder;
public:
	Alice() : FullFeaturedCryptographer<GF, LongInt>(), coder() {}

private:
	void receiveData(const std::string& sourceName) {
		coder.encodeSource(sourceName, data);	
	}

	void sendData(const std::string& destination) {
		storeData(destination);
	}

	// not portable and even console environment-dependent implementation;
	// possible better implementation is as a callback
	void wait() {
		cout << "Waiting for Bob move...\n" << endl;
		system("pause");
	}
};
}