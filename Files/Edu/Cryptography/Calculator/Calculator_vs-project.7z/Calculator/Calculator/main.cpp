#include <iostream>
#include <sstream>
#include <cstdlib>
#include <NTL/ZZ_p.h>
#include <NTL/ZZ_pE.h>
#include <NTL/ZZ_pX.h>
#include "GFCalculator.h"
#include "TemplateOperations.h"

using namespace std;
using namespace NTL;

int main() {
	/*GFCalculator::init("3", "1");
	std::cout << "GF[3]" << endl;
	string op1("1"), op2("2");
	std::cout << "1 + 2 = " << GFCalculator::operations->add(op1, op2) << std::endl;
	std::cout << "4 + 6 = " << GFCalculator::operations->add("4", "6") << std::endl;*/
	ZZ_p::init(to_ZZ(5));
	ZZ_pX poly1 = pushThroughStream<ZZ_pX>(string("[1 2]"));
	cout << poly1 << endl;
	ZZ_pX poly2 = pushThroughStream<ZZ_pX>(string("[1 1]"));
	cout << poly2 << endl
		<< pushThroughStream(poly1 + poly2) << endl;
	system("pause");

}