#include <boost/shared_ptr.hpp>
#include "GFCalculator.h"
#include "Operations.h"
#include "TemplateOperations.h"

// initializing with a stub - need explicit initialization with GFCalculator::init()
boost::shared_ptr<Operations> GFCalculator::operations(new TemplateOperations<void>()); 

bool GFCalculator::isPrimeField = true;