#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <string>

using std::string;

class Operations {
public:	
	virtual string add(const string& operand1, const string& operand2) = 0;
	virtual string sub(const string& operand1, const string& operand2) = 0;
	virtual string mul(const string& operand1, const string& operand2) = 0;
	virtual string div(const string& operand1, const string& operand2) = 0;
};
#endif //OPERATIONS_H