#ifndef TEMPLATE_OPERATIONS_H
#define TEMPLATE_OPERATIONS_H

#include <string>
#include <sstream>
#include <functional>
#include <iostream>

#include "Operations.h"

using std::string;
using std::stringstream;

template< typename ElemT>
class TemplateOperations : public Operations {
public:
	string add(const string& operand1, const string& operand2) {
		return eval<std::plus>(operand1,operand2);
	}

	string sub(const string& operand1, const string& operand2) {
		return eval<std::minus>(operand1,operand2);
	}
	string mul(const string& operand1, const string& operand2) {
		return eval<std::multiplies>(operand1,operand2);
	}
	string div(const string& operand1, const string& operand2) {
		return eval<std::divides>(operand1,operand2);
	}
private:
	template<template<typename> class BinaryOpT>
	string eval(const string& operand1, const string& operand2) {
		return pushThroughStream( BinaryOpT<ElemT>()(
			pushThroughStream<ElemT>(operand1),
			pushThroughStream<ElemT>(operand2)));
	}
};

template<typename TargetT, typename SourceT>
inline TargetT pushThroughStream(const SourceT& source) {
	static std::stringstream stream;
	fillStringStream(stream, source);
	TargetT result = TargetT();
	stream >> result;
	return result;	
}
template<typename SourceT>
inline string pushThroughStream(const SourceT& source) {
	static std::stringstream stream;
	fillStringStream(stream, source);
	return stream.str();	
}

template<typename T>
inline void fillStringStream(std::stringstream& stream, const T& source) {
	stream.clear();
	stream.str("");
	stream << source;
	stream.clear();
}

template<>
class TemplateOperations<void> : public Operations {
public:
	string add(const string& operand1, const string& operand2) {return string();}
	string sub(const string& operand1, const string& operand2) {return string();}
	string mul(const string& operand1, const string& operand2) {return string();}
	string div(const string& operand1, const string& operand2) {return string();}
};
#endif //GFPOPERATIONS_H