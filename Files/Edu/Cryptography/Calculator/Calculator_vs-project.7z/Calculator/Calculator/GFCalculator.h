#ifndef GFCALCULATOR_H
#define GFCALCULATOR_H

#include <boost/lexical_cast.hpp>
#include <boost/shared_ptr.hpp>
#include <NTL/ZZ_p.h>
#include <NTL/ZZ_pX.h>
#include <NTL/ZZ_pE.h>
#include <NTL/GF2.h>
#include <NTL/GF2X.h>
#include <NTL/GF2E.h>
#include <NTL/GF2XFactoring.h>
#include <NTL/ZZ_pXFactoring.h>

#include "Operations.h"
#include "TemplateOperations.h"

using namespace NTL;

class GFCalculator {
public:
	static boost::shared_ptr<Operations> operations;
	static bool isPrimeField;
	static void init(string base, string strDegree) {
		long degree = boost::lexical_cast<long>(strDegree); // supports only long int degree of field
		isPrimeField = (degree == 1L );
		bool base2 = (base.size() == 1) && (boost::lexical_cast<int>(base) == 2); // assumed one-byte symbols
		if (base2) {
			if (isPrimeField) {
				initOperations<GF2>();
			} else {
				initExtField<GF2X, GF2E>(degree);
				initOperations<GF2E>();
			}
		} else { // base > 2
			ZZ_p::init(to_ZZ(base.c_str()));
			if (isPrimeField) {
				initOperations<ZZ_p>();
			} else {
				initExtField<ZZ_pX, ZZ_pE>(degree);
				initOperations<ZZ_pE>();
			}
		}
	}

private:
	template <typename PolyT, typename ExtFieldT, typename DegreeT>
	static void initExtField(DegreeT degree) {
		PolyT poly;
		BuildIrred(poly, degree);
		ExtFieldT::init(poly);
	}

	template <typename ElemT>
	static void initOperations() {
		operations = boost::shared_ptr<Operations>(new TemplateOperations<ElemT>());
	}
};
#endif //GFCALCULATOR_H