#ifndef GFPOPERATIONS_H
#define GFPOPERATIONS_H

#include <string>
#include <functional>
#include <NTL/ZZ_p.h>

#include "GFOperations.h"

using NTL::ZZ_p;

using std::string;
using std::stringstream;
using std::plus;
using std::minus;
using std::multiplies;
using std::divides;

class GFpOperations : public GFOperations {
public:
	string add(const string& operand1, const string& operand2) {
		return eval<ZZ_p, std::plus>(operand1,operand2);
	}

	string sub(const string& operand1, const string& operand2) {
		return string();
	}
	string mul(const string& operand1, const string& operand2) {
		return string();
	}
	string div(const string& operand1, const string& operand2) {
		return string();
	}
};
#endif //GFPOPERATIONS_H