// #include <windows.h>
#include <jni.h>
#include <cstddef>
#include <string>

#include "edu_ulysses_calculator_NativeGFCalculator.h"
#include "GFCalculator.h"

using std::string;

string jstringToString(JNIEnv *env, jstring jStr);

extern "C" {

	JNIEXPORT 
	jstring JNICALL Java_edu_ulysses_calculator_NativeGFCalculator_add
	(JNIEnv *env, jobject self, jstring operand1, jstring operand2) {
		string result(GFCalculator::operations->add(
			jstringToString(env, operand1), jstringToString(env, operand2)));
		return env->NewStringUTF(result.c_str());
	}

	JNIEXPORT 
	jstring JNICALL Java_edu_ulysses_calculator_NativeGFCalculator_sub
	(JNIEnv *env, jobject self, jstring operand1, jstring operand2){
		string result(GFCalculator::operations->sub(
			jstringToString(env, operand1), jstringToString(env, operand2)));
		return env->NewStringUTF(result.c_str());
	}

	JNIEXPORT
	jstring JNICALL Java_edu_ulysses_calculator_NativeGFCalculator_mul
	(JNIEnv *env, jobject self, jstring operand1, jstring operand2) {
		string result(GFCalculator::operations->mul(
			jstringToString(env, operand1), jstringToString(env, operand2)));
		return env->NewStringUTF(result.c_str());
	}

	JNIEXPORT
	jstring JNICALL Java_edu_ulysses_calculator_NativeGFCalculator_div
	(JNIEnv *env, jobject self, jstring operand1, jstring operand2) {
		string result(GFCalculator::operations->div(
			jstringToString(env, operand1), jstringToString(env, operand2)));
		return env->NewStringUTF(result.c_str());
	}

	JNIEXPORT
	void JNICALL Java_edu_ulysses_calculator_NativeGFCalculator_init
	(JNIEnv *env, jobject self, jstring base, jstring degree){
		GFCalculator::init(jstringToString(env, base), jstringToString(env, degree));
	}

	JNIEXPORT
	jboolean JNICALL Java_edu_ulysses_calculator_NativeGFCalculator_isPrimeField
	(JNIEnv *, jobject) {
		return jboolean(GFCalculator::isPrimeField);
	}

	/*
	BOOL APIENTRY DllMain( HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
		printf("Hello, Calculator");
		return TRUE;
	}*/
}

string jstringToString(JNIEnv *env, jstring jStr) {
	const char* cStr = env->GetStringUTFChars(jStr, NULL);
	string result(cStr);
	env->ReleaseStringUTFChars(jStr, cStr);
	return result;
}