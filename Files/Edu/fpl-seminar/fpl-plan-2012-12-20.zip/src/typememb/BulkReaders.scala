package typememb

import java.io._

object BulkReaders {

}

abstract class BulkReader {
  type In           // <--------- abstract type member
  val source: In
  def read: String
}

class StringBulkReader(val source: String) extends BulkReader {
  type In = String  // <--------- concrete type member
  def read = source
}

class FileBulkReader(val source: File) extends BulkReader {
  type In = File    // <--------- concrete type member
  def read = {
    val in = new BufferedInputStream(new FileInputStream(source))
    val numBytes = in.available()
    val bytes = new Array[Byte](numBytes)
    in.read(bytes, 0, numBytes)
    new String(bytes)
  }
}
