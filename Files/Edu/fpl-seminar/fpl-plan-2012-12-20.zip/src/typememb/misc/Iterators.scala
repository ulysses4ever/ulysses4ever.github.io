package typememb.misc


abstract class Iterators {

  def myAlgorithm[It](it1: It, it2: It)(mit: MyIterator) {
    //val x = 
  }

}