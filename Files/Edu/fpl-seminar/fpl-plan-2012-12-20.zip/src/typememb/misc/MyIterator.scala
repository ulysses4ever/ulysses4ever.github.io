package typememb.misc

trait MyIterator {

  type value;// = T;
  
//  def deref: 
}