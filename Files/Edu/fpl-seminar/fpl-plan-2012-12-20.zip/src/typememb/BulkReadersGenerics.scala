package typememb

import java.io._

object BulkReadersGenerics {

}

abstract class BulkReaderGeneric[In] {
  val source: In
  /*...*/
}

class StringBulkReaderGeneric(val source: String) extends 
									BulkReaderGeneric[String] {/*...*/}

class FileBulkReaderGeneric(val source: File) extends 
									BulkReaderGeneric[File] {/*...*/}