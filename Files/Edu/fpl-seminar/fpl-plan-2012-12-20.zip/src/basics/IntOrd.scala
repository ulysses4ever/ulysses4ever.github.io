package basics

// model
object IntOrd extends MyOrd[Int] {
  def compare(a: Int, b: Int): Boolean = a <= b
}
