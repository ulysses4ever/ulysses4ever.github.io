package basics

// concept
trait MyOrd[T] {
	def compare(a: T, b: T): Boolean
}