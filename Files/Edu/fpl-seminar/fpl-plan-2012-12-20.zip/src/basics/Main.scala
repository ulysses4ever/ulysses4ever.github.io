package basics

object Main extends App {

  // usage
  def sort[T](xs: List[T])(ord: MyOrd[T]): List[T] = {
    // some implementation of sorting using ord…
    xs.sortWith(ord.compare)
  }

  println(sort(List(42, 1, 10, 5))(IntOrd))
}