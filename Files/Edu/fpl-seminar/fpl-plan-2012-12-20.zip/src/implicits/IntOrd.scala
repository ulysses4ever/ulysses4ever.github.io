package implicits

object IntOrd {
  val impl = new MyOrd[Int] {
    def compare(a: Int, b: Int): Boolean = a <= b
  }

  implicit object iord extends MyOrd[Int] {
    def compare(a: Int, b: Int): Boolean = a <= b
  }
}
