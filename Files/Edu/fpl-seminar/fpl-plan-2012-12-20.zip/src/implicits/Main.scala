package implicits
	
import IntOrd._  // explicit import for implicit usage!

object Main extends App {
	def sort [T](xs : List [T]) (implicit ord : MyOrd[T]): List[T] = {
	  xs.sortWith(ord.compare)
	}
	
	println(sort(List(42, 1, 10, 5)))
}