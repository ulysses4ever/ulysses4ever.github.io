package scopes

object IntOrd1 {
  implicit val impl = new MyOrd[Int] {
    def compare(a: Int, b: Int): Boolean = a <= b
  }
}

object IntOrd2 {
  implicit val impl = new MyOrd[Int] {
    def compare(a: Int, b: Int): Boolean = a >= b
  }
}