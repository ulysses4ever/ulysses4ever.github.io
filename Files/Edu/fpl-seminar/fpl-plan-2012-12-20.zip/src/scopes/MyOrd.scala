package scopes

trait MyOrd[T] {
	def compare(a: T, b: T): Boolean
}