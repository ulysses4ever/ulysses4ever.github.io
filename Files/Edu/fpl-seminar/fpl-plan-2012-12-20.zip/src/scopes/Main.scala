package scopes

object Main extends App {
	def sort [T](xs : List [T]) (implicit ord : MyOrd[T]): List[T] = {
	  xs.sortWith(ord.compare)
	}
	
	{
	  import IntOrd1._
	  println(sort(List(42, 1, 10, 5)))
	}

	{
	  import IntOrd2._
	  println(sort(List(42, 1, 10, 5)))
	}
}