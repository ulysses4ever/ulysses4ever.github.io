int __divsi3(int n, int d) {
	int res = 0;
	while (n > d) {
		++res;
		n -= d;
	}
	return res;
}

int __modsi3(int n, int d) {
	while (n > d) {
		n -= d;
	}
	return n;
}

