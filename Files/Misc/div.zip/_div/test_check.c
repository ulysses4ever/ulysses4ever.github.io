#include <stdio.h>
int main()
{
    int a[5];
    FILE* f;
    int i;
    a[0] =  31;
    a[1] = 8;
    a[2] = a[0]/a[1];
    a[3] = a[0] % a[1];
    a[4] = (a[0]*a[1]/(17-a[1])+a[0])%100;
    a[2] = (a[1]/(3*a[2]))*4-(a[1]*3*a[2])/a[0];
    f = fopen("memory_check.txt", "w");
    for (i=0; i<5; i++)
        fprintf(f,"%d\n",a[i]);
}
