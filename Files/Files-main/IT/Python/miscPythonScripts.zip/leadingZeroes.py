 # coding: cp1251
import os, re

MAX_DIGITS = 3

#root = r"D:\Coding\Works\Python\leadingZeroes"
root = os.curdir
pattern = r"^(\d+)(.*\.jpe?g)$"     # there will be two (explicit) groups
jpgNumberedNameRe = re.compile( pattern, re.IGNORECASE )    

def rename( mo ) :
    replacePattern = "0"*( MAX_DIGITS - len( mo.group(1) ) ) \
                        + r"\1\2"
    newName = jpgNumberedNameRe.sub( replacePattern, mo.string )
    #print newName
    os.rename( os.path.join( root, name ), 
               os.path.join( root, newName ) )

if __name__=='__main__':
    path, foldersList, files = os.walk(root).next()
    for name in files:
        matchedObject = jpgNumberedNameRe.match( name )
        if matchedObject != None:
            rename( matchedObject )
"""
    # low perfomance I suppose
    [ rename( matchedObject ) for matchedObject 
     in [jpgNumberedNameRe.match(file) for file in files]
     if matchedObject != None ]
"""