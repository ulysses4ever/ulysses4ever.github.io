 # coding: cp1251
import os, re, codecs, inspect

MAX_DIGITS = 3

#root = r"D:\Coding\Works\Python\leadingZeroes"
root = os.curdir
pattern = r"^(\d+)(.*)(\.jpe?g)$"
jpgNumberedNameRe = re.compile( pattern, re.IGNORECASE )    

def rename( mo ) :
    try:
        newName = fo.readline()
        
        os.rename( os.path.join( root, mo.string ), 
                   os.path.join( root, newName.rstrip() ) )
        
    finally:
        1 + 2

fname = r"crLeadingZeroes.py"
fo = open( os.path.join( root, fname ), "r" )
while True:
    line = fo.readline()
    if line.find("\"\"\" List Begins!") != -1:        
        break

if __name__=='__main__':
    path, foldersList, files = os.walk(root).next()
    for name in files:
        matchedObject = jpgNumberedNameRe.match( name )
        if matchedObject != None:
            rename( matchedObject )

fo.close()