 # coding: cp1251
import os, re, codecs, inspect

MAX_DIGITS = 3

#root = r"D:\Coding\Works\Python\leadingZeroes"
root = os.curdir
pattern = r"^(\d+)(.*)(\.jpe?g)$"
jpgNumberedNameRe = re.compile( pattern, re.IGNORECASE )    

str = "any text"
e = codecs.getencoder('cp1251')
ss = "".join(map( (lambda uc: e(uc)[0]), str ))
flist = []

def rename( mo ) :    
    replacePattern = "0"*( MAX_DIGITS - len( mo.group(1) ) ) \
                        + r"\1" + ". " + ss + r"\3"
    newName = jpgNumberedNameRe.sub( replacePattern, mo.string )
    rp = "0"*( MAX_DIGITS - len( mo.group(1) ) ) \
                        + r"\1" + r"\2" + r"\3"    
    rn = jpgNumberedNameRe.sub( rp, mo.string )
    flist.append( rn + "\n" )
    os.rename( os.path.join( root, name ), 
               os.path.join( root, newName ) )
    print newName

thisF = inspect.getsourcefile( rename ) #r"D:\Coding\Works\Python\leadingZeroes\test" 
fo = open( thisF, "a" )
fo.write("\n"*100 + "\"\"\" List Begins!\n")


if __name__=='__main__':
    path, foldersList, files = os.walk(root).next()
    for name in files:
        matchedObject = jpgNumberedNameRe.match( name )
        if matchedObject != None:
            rename( matchedObject )
    flist.sort()
    fo.writelines(flist)

fo.write("\"\"\"")
fo.close()