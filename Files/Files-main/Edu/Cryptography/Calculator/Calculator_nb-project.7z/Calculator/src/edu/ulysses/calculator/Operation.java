
package edu.ulysses.calculator;

/**
 *
 * @author Ulysses
 */
public enum Operation {
    Adding(2), Subtracting(2), Dividing(2), Multiplication(2);
    
    private String label;
    private int arity;
    
    static {
        for(Operation op : Operation.values()) {
            op.setLabel(op.toString());
        }
    }
    
    /*
    private Operation() {
        this.label = "";
    }
        
    private Operation(String label) {
        this.label = label;
    }
    */
    
    private Operation(int arity) {
        this.arity = arity;
    }
    
    private void setLabel(String label) {
        this.label = label;
    }
    
    public String getLabel() {
        return label;
    }
}
