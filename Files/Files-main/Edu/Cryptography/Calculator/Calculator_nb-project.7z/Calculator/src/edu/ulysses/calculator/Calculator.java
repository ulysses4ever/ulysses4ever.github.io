/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ulysses.calculator;

/**
 *
 * @author Ulysses
 */
public interface Calculator {
    public String eval(Operation op, String operand);
    public String eval(Operation op, String operand1, String operand2);
}
