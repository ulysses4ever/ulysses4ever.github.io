/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ulysses.calculator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Ulysses
 */
public class NativeGFCalculator extends AbstractCalculator implements GFCalculator {
    
    static {
        try {
            System.loadLibrary("Calculator");
            //System.load("C:\\Documents and Settings\\Ulysses.UL-PC\\Мои документы\\Visual Studio 2005\\Projects\\Calculator\\debug\\Calculator.dll");
        } catch(UnsatisfiedLinkError e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        polynomialRepresentationPattern = Pattern.compile("\\[(\\d+ )*\\d+\\]");
    }
    
    public static final int defaultBase = 3;
    public static final int defaultDegree = 1;
    private static final Pattern polynomialRepresentationPattern;

    public NativeGFCalculator() {
        init(Integer.toString(defaultBase), Integer.toString(defaultDegree));
    }
    
    protected native String add(String operand1, String operand2);
    protected native String sub(String operand1, String operand2);
    protected native String mul(String operand1, String operand2);
    protected native String div(String operand1, String operand2);
    
    public native void init(String base, String degree);
    public native boolean isPrimeField();
    
    public Pattern getExtFieldElementPattern() {
        return polynomialRepresentationPattern;
    }
}
