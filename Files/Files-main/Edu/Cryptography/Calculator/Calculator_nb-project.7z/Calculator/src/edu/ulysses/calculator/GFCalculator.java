/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ulysses.calculator;

import java.util.regex.Pattern;

/**
 *
 * @author Ulysses
 */
public interface GFCalculator extends Calculator {
    public void init(String base, String degree);
    public boolean isPrimeField();
    public Pattern getExtFieldElementPattern();
}
