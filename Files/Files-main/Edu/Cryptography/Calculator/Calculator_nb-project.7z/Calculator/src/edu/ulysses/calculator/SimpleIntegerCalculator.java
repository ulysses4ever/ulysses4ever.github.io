/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ulysses.calculator;

import static edu.ulysses.calculator.Operation.*;

/**
 *
 * @author Ulysses
 */
public class SimpleIntegerCalculator extends AbstractCalculator {
    
    protected String add(String operand1, String operand2) {
        return Integer.toString(
                Integer.parseInt(operand1) + Integer.parseInt(operand2));
    }
    
    protected String sub(String operand1, String operand2) {
        return Integer.toString(
                Integer.parseInt(operand1) - Integer.parseInt(operand2));
    }
    
    protected String mul(String operand1, String operand2) {
        return Integer.toString(
                Integer.parseInt(operand1) * Integer.parseInt(operand2));
    }
    
    protected String div(String operand1, String operand2) {
        return Integer.toString(
                Integer.parseInt(operand1) / Integer.parseInt(operand2));
    }
}
