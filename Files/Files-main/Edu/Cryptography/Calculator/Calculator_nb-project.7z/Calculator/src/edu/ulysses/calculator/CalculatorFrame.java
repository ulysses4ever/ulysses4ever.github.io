/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ulysses.calculator;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author Ulysses
 */
public class CalculatorFrame implements ActionListener {
    
    static String title = "Galois Fields' Calculator";
    static String firstOperandLabel = "Operand 1";
    static String secondOperandLabel = "Operand 2";
    static String resultLabel = "Result";
    static String evalButtonLabel = "Evaluate";
    static String setFieldButtonLabel = "Set Field";
    static String charLabel = "Char";
    static String degreeLabel = "Degree";
    static String setFieldCommand = "INIT";
    static String wrongFieldParamsMsg = "Wrong field parameters!";
    static String wrongFieldElementsForm = "<html>Wrong field elements form!<br>" + 
            "In extended field use \"[c b a]\" form for \"ax^2 + bx + c\",<br>" +
            "where a, b, c - elements of prime field.<br>" +
            "In prime field (degree=1) use non-negative integers.";
    static final int initialTextFieldWidth = 20;
    static final int initialIntFieldWidth = 5;
    
    JFrame frame;
    JTextField charField;
    JTextField degreeField;
    JTextField firstOperandField;
    JTextField secondOperandField;
    JTextField resultField;
    ButtonGroup operationsGroup;
    
    GFCalculator calculator;
    
    public CalculatorFrame() {
        frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // frame.setSize(400, 200);
        frame.setResizable(false);
        operationsGroup = new ButtonGroup();
        
        // setting field panel generation
        charField = new JTextField(initialIntFieldWidth);
        charField.setText(Integer.toString(NativeGFCalculator.defaultBase));
        Box setFieldPanel = Box.createHorizontalBox();
        setFieldPanel.add(buildVerticalBox(new JLabel(charLabel), charField));
        degreeField = new JTextField(initialIntFieldWidth);
        degreeField.setText(Integer.toString(NativeGFCalculator.defaultDegree));
        setFieldPanel.add(buildVerticalBox(new JLabel(degreeLabel), degreeField));
        JButton setFieldButton = new JButton(setFieldButtonLabel);
        setFieldButton.setAlignmentY(Container.TOP_ALIGNMENT);
        setFieldButton.addActionListener(this);
        setFieldButton.setActionCommand(setFieldCommand);
        setFieldPanel.add(setFieldButton);
        
        // input panel generation
        // JPanel inputPanel = new JPanel(new GridLayout(0,1));
        Box inputPanel = Box.createVerticalBox();
        firstOperandField = new JTextField(initialTextFieldWidth);
        inputPanel.add(buildVerticalBox(new JLabel(firstOperandLabel), 
                firstOperandField));
        inputPanel.add(Box.createRigidArea(new Dimension(initialIntFieldWidth, 10)));
        secondOperandField = new JTextField(initialTextFieldWidth);
        inputPanel.add(buildVerticalBox(new JLabel(secondOperandLabel), 
                secondOperandField));
        inputPanel.add(Box.createRigidArea(new Dimension(initialIntFieldWidth, 30)));
        
        // operations' panel generation
        // JPanel operationsPanel = new JPanel(new GridLayout(0,1));
        Container operationsPanel = Box.createVerticalBox(  );
        JRadioButton operationBtn;
        for(Operation op : Operation.values()) {
            operationsPanel.add(operationBtn = new JRadioButton(op.getLabel()));
            operationBtn.setActionCommand(op.toString());
            operationsGroup.add(operationBtn);
        }
        operationsGroup.getElements().nextElement().setSelected(true);
        JButton resultButton = new JButton(evalButtonLabel);
        resultButton.addActionListener(this);
        resultButton.setAlignmentY(Component.TOP_ALIGNMENT);
        operationsPanel.add(resultButton);
        
        // result panel generation
        // JPanel resultPanel = new JPanel(new GridLayout(0,1));
        Container resultPanel = Box.createVerticalBox();
        resultField = new JTextField(initialTextFieldWidth);
        resultField.setEditable(false);
        resultPanel.add(buildVerticalBox(new JLabel(resultLabel), resultField));
        
        // filling the frame
        frame.add(setFieldPanel, BorderLayout.NORTH);
        frame.add(inputPanel, BorderLayout.CENTER);
        frame.add(resultPanel, BorderLayout.SOUTH);
        frame.add(operationsPanel, BorderLayout.EAST);
        frame.pack();
        frame.setVisible(true);
        //==========================
        
        // calculator initialization
        // calculator = new SimpleIntegerCalculator();
        calculator = new NativeGFCalculator();
    }
    
    private Container buildVerticalBox(JLabel label, JTextField tField) {
        Box result = Box.createVerticalBox();
        result.add(label);
        result.add(tField);
        return result;
    }
    
    private Operation getOperation() {
        return Operation.valueOf(
                operationsGroup.getSelection().getActionCommand());
    }
    
    private String getFirstOperand() {
        return firstOperandField.getText();
    }
    
    private String getSecondOperand() {
        return secondOperandField.getText();
    }
    
    private String getChar() {
        return charField.getText();
    }
    
    private String getDegree() {
        return degreeField.getText();
    }
    
    private static boolean isPositiveInteger(String s) {
        try {
            BigInteger num = new BigInteger(s);
            return (num.compareTo(new BigInteger("0")) > 0);
        } catch(Exception e) {
            return false;
        }
    }
    
    private boolean isValidFieldParams() {
        String fieldChar = getChar();
        if(!isPositiveInteger(fieldChar) || fieldChar.charAt(0) == '-')
            return false;
        String fieldDegree = getDegree();
        if(!isPositiveInteger(fieldDegree) || fieldDegree.charAt(0) == '-')
            return false;
        return true;
    }
    
    private boolean isValidOperands() {
        if(calculator.isPrimeField()) {
            return isPositiveInteger(getFirstOperand())
                    && isPositiveInteger(getSecondOperand());
        }
        // extended field...
        Pattern operandPattern = calculator.getExtFieldElementPattern();
        return operandPattern.matcher(getFirstOperand()).matches()
                && operandPattern.matcher(getSecondOperand()).matches();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals(setFieldCommand)) {
            if (!isValidFieldParams()) {
                JOptionPane.showMessageDialog(frame, wrongFieldParamsMsg,
                    null, JOptionPane.ERROR_MESSAGE);
                return;
            }
            calculator.init(getChar(), getDegree());
            return;
        }
        
        if (!isValidOperands()) {
            JOptionPane.showMessageDialog(frame, wrongFieldElementsForm
                , null, JOptionPane.ERROR_MESSAGE);
            return;
        }
        String result = calculator.eval(getOperation(), getFirstOperand(),
                getSecondOperand());
        resultField.setText(result);
    }
}
