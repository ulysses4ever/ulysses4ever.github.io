/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ulysses.calculator;

/**
 *
 * @author Ulysses
 */
abstract public class AbstractCalculator implements Calculator {

    public String eval(Operation op, String operand) {
        return new String("");
    }

    final public String eval(Operation operation, String operand1, String operand2) {
        switch (operation) {
            case Adding:
                return add(operand1, operand2);
            case Subtracting:
                return sub(operand1, operand2);
            case Multiplication:
                return mul(operand1, operand2);
            case Dividing:
                return div(operand1, operand2);
            default:
                return new String("");
        }
    }

    abstract protected String add(String operand1, String operand2);
    
    abstract protected String sub(String operand1, String operand2);
    
    abstract protected String mul(String operand1, String operand2);
    
    abstract protected String div(String operand1, String operand2);
}