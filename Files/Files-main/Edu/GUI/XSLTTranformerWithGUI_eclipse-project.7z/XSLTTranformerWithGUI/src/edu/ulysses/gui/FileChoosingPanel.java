package edu.ulysses.gui;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FileChoosingPanel extends JPanel implements ActionListener {
	private static final int initialEditFieldWidth = 25;
	private static final String defaultButtonLabel = "Browse...";

	private JLabel label;
	private JTextField textField;
	private JButton browseButton;

	public FileChoosingPanel() {
		super();
		this.setLayout(new GridLayout(0,1));
		label = new JLabel();
		add(label);
		JPanel tempPanel = new JPanel();
		textField = new JTextField(initialEditFieldWidth);
		tempPanel.add(textField);
		
		ResourceBundle messages = ResourceBundle.getBundle("FileChoosingMessages");
		browseButton = new JButton(messages.getString("browse"));
		browseButton.addActionListener(this);
		tempPanel.add(browseButton);
		add(tempPanel);
	}

	public FileChoosingPanel(String labelText) {
		this();
		label.setText(labelText);
	}

	public FileChoosingPanel(String labelText, String defaultEditFieldText) {
		this(labelText);
		textField.setText(defaultEditFieldText);
	}

	public String getFileName() {
		return textField.getText();
	}

	public void actionPerformed(ActionEvent event) {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.CANCEL_OPTION) return;
        textField.setText(chooser.getSelectedFile().toString());
	}

}
