package edu.ulysses.gui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class XMLFileTransformer {

    private static final String saxonTransformerFactoryClassName = "net.sf.saxon.TransformerFactoryImpl";
    
	Transformer transformer;
	StreamSource styleSource;

	public XMLFileTransformer(String transfornation)
			throws TransformerConfigurationException {
		styleSource = new StreamSource(transfornation);
		TransformerFactory tFactory;
		try {
            Class.forName(saxonTransformerFactoryClassName);
            System.setProperty("javax.xml.transform.TransformerFactory",
                    saxonTransformerFactoryClassName);
		} catch (ClassNotFoundException e) {}
        tFactory = TransformerFactory.newInstance();
		transformer = tFactory.newTransformer(styleSource);
		transformer.setOutputProperty("indent", "yes");
	}

	public void transform(String source, String target)
			throws FileNotFoundException, TransformerException {
		transformer.transform(new StreamSource(source), new StreamResult(
				new FileOutputStream(target)));

	}
}
