package edu.ulysses.gui;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.xml.transform.TransformerException;


public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	    final ResourceBundle messagesBundle = ResourceBundle.getBundle("TextLabels");
	    
	    /*
		final String title = "XSLT-Transformer";
		final String srcFileLabelText = "Source XML File";
		final String transformationLabelText = "Transformation File";
		final String targetFileLabelText = "Target File";
		final String transformBtnText = "Transform";
		final String showResultText = "Show result";
		*/
	    
	    final String title = messagesBundle.getString("title");
	    final String srcFileLabelText = messagesBundle.getString("srcFileLabelText");
	    final String transformationLabelText = messagesBundle.getString("transformationLabelText");
	    final String targetFileLabelText = messagesBundle.getString("targetFileLabelText");
	    final String transformBtnText = messagesBundle.getString("transformBtnText");
	    final String showResultText = messagesBundle.getString("showResultText");
		
	    final String defaultTargetFile = System.getProperty("user.dir") + File.separator + "result.html";
		
		final JFrame frame = new JFrame(title);
		
		final FileChoosingPanel sourceFileChoosingPanel 		= new FileChoosingPanel(srcFileLabelText);
		final FileChoosingPanel transformationFileChoosingPanel = new FileChoosingPanel(transformationLabelText);
		final FileChoosingPanel targetFileChoosingPanel 		= new FileChoosingPanel(targetFileLabelText, defaultTargetFile);
		
		final JCheckBox showResultCheckBox = new JCheckBox(showResultText, true); //selected by default
		
		JButton transformBtn = new JButton(transformBtnText);
		transformBtn.addActionListener( 
			new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					try {
						XMLFileTransformer transformer = new XMLFileTransformer(
								transformationFileChoosingPanel.getFileName());
						transformer.transform(sourceFileChoosingPanel.getFileName(), targetFileChoosingPanel.getFileName());
						if (showResultCheckBox.isSelected())
							Desktop.getDesktop().open( new File(targetFileChoosingPanel.getFileName()) );
							//Desktop.getDesktop().browse(new URI("file://" + targetFileChoosingPanel.getFileName()));
						else
							JOptionPane.showMessageDialog(frame, messagesBundle.getString("succeed"), 
							        null, JOptionPane.INFORMATION_MESSAGE);
					} catch (IOException e) {
						JOptionPane.showMessageDialog(frame, messagesBundle.getString("fileNotFound")
						        , null, JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					} catch (TransformerException e) {
						JOptionPane.showMessageDialog(frame, messagesBundle.getString("transformerError"),
						        null, JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
//					} catch (URISyntaxException e) {
//						JOptionPane.showMessageDialog(frame, "File not found", null, JOptionPane.ERROR_MESSAGE);
//						e.printStackTrace();
					}
				}
			}
		);
		
		// setting frame
		JPanel mainPanel =new JPanel();
		//mainPanel.setLayout(new GridLayout(0,1));
//		((FlowLayout)mainPanel.getLayout()).setAlignment(FlowLayout.LEFT);
		mainPanel.add(sourceFileChoosingPanel/*, BorderLayout.NORTH*/);
		mainPanel.add(transformationFileChoosingPanel/*, BorderLayout.CENTER*/);
		mainPanel.add(targetFileChoosingPanel/*, BorderLayout.CENTER*/);

		JPanel bottomPanel =new JPanel();
		//bottomPanel.setLayout(new GridLayout(1,2));
		bottomPanel.add(showResultCheckBox);
		bottomPanel.add(transformBtn);
		//mainPanel.add(bottomPanel);
		//frame.add(new JScrollPane(mainPanel));
		frame.add(mainPanel, BorderLayout.CENTER);
		frame.add(bottomPanel, BorderLayout.SOUTH);
		frame.setSize(500, 300);
        //frame.pack(  );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        frame.setVisible(true);
	}

}
