/* $Header: comm8.c,v 2.4 87/03/10 10:11:06 ceriel Exp $ */
/*
 * (c) copyright 1987 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the ACK home directory, in the file "Copyright".
 */
/* @(#)comm8.c	1.1 */

#include	"comm0.h"
#include	"comm1.h"
#include	"y.tab.h"

/* ========== Machine dependent C routines ========== */

#include	"mach5.c"
