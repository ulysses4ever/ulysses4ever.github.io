cd trce_src
make
rm *.o 
cd ../as_src
make
rm *.o
cd ..
ls bin
