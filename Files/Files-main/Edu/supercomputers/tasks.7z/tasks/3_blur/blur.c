#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <math.h>

typedef unsigned short BIT;

void getStartAndRows( int *start, size_t* rows );
BIT** getMemory( size_t );
void freeMemory( BIT** data, size_t rows );
int getData( char* fname, int start, const size_t ROWS, BIT** data );
int getPatterns( BIT*** patterns, size_t *patternCountPtr, size_t *patternSizePtr);
void freePatterns( BIT*** patterns, size_t patternCount, size_t patternSize );

size_t G_ROWS = 10, G_COLS = 20;
int rank, size;
int FILE_NOT_FOUND = 42;
BIT ***patterns = NULL;

int main( int argc, char* argv[] ) {
//int myMain( int argc, char* argv[] ) {
    size_t rows, cols = G_COLS;
    int start = 0;
    BIT** data;
    char* fname = NULL;

    MPI_Init( &argc, &argv );
    
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    
    getStartAndRows( &start, &rows );
    
    data = getMemory( rows );
    
    if ( argc > 1 )
        fname = argv[1];
    else
	    fname = "test";
	
	if ( getData( fname, start,  rows, data ) == FILE_NOT_FOUND) {
	    freeMemory( data, rows );
	    return FILE_NOT_FOUND;
	}
	
	// getPatterns();
	
	freeMemory( data, rows );
}

void getStartAndRows( int *start, size_t* rows ) {
    div_t temp = div( G_ROWS, size );
    int baseArea = temp.quot;
    int rem = temp.rem;

    //div_t temp = div( G_ROWS, size );;
    //int baseArea = temp.quot;
    //int rem = temp.rem;
    //int start = 0;

    *rows = baseArea;
    if ( rank >= rem ) {
        *start = ( baseArea + 1 ) * rem + baseArea * ( rank - rem );
        *rows += 1;
    } else
        *start = ( baseArea + 1 ) * rank;
}

BIT** getMemory( size_t rows ) {
    size_t i;
    BIT** data = NULL;
    
    data = (BIT**)malloc( rows * sizeof(BIT*) );
    for( i = 0; i < rows; ++i)
        data[i] = (BIT*)malloc( G_COLS * sizeof(BIT) );
    return data;
}

void freeMemory( BIT** data, size_t rows ) {
    size_t i;
    for( i = 0; i < rows; ++i )
        free( data[i] );
    free( data );
}

int getData( char* fname, int start, const size_t ROWS, BIT** data ) {
    FILE * f = fopen( fname, "r" );
    // BIT ** rowptr, * colptr; // - perfomance enhancement
    int col, row;
    
    if (f == NULL)
        return FILE_NOT_FOUND;
    
    //skiping data foreign from current process
    for( row = 0; row < start; ++row ) {
        for( col = 0; col < G_COLS; ++col )
            fscanf(f, "%*hd");
    }

    // obtaining data
    for( row = 0; row < ROWS; ++row ) {
        for( col = 0; col < G_COLS; ++col )
            fscanf( f, "%hd", &(data[row][col]) );
    }

    fclose( f );
    return 0;
}

int getPatterns( BIT*** patterns, size_t *patternCountPtr, size_t *patternSizePtr) {

}