#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <math.h>

void fillArray( double* arr, size_t len, double x );
double summArray( double* beg, double* end );

int main() {
    size_t n = 100000;
    double* arr = (double *) malloc( sizeof(double) * n );

    double x = -1;
    double summ = 0;
    fillArray( arr, n, x );
    summ = summArray( arr, arr + n );
    printf( "exp( -%f ) = %f\n", x, summ );

    free( arr );
    return 0;
}

void testExp_Parall() {}


// exp( -x ):
// 	a[i] = ( ( -1 )^i * x^i ) / i!
void fillArray( double* arr, size_t len, double x ) {
    size_t i = 1;

    assert( arr != NULL );
    assert( len > 0 );

    *arr = 1;
    for ( ; i < len; ++arr, ++i ) {
    	*(arr + 1) = (-1) * x * (*arr) / i; 		// a[i + 1] = f( a[i] )
    }
}

double summArray( double* beg, double* end ) {
    double res = 0;

    assert( beg != NULL );
    assert( beg < end );

    for ( ; beg != end; ++beg ) {
        res += *beg;
    }
    return res;
}
