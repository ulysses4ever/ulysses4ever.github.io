#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <math.h>

void fillArray( double* arr, size_t len, int start );
double summArray( double* beg, double* end );

int main( int argc, char* argv[] ) {    
    size_t n = 100000;
    int rank = 0;
    double* arr = (double *) malloc( sizeof(double) * n );
    double begtime = 0, endtime = 0, time = 0;
    double summ = 0;
    FILE* result;
    
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    begtime = MPI_Wtime();

    fillArray( arr, n, 1 );
    summ = summArray( arr, arr + n );
    
    endtime = MPI_Wtime();
    time = endtime - begtime;
    if ( rank == 0 ) {
        result = fopen("result", "w");
        fprintf( result, "summ = %.10f\ntime = %.10f", summ, time );
        fclose( result );
    }
    
    free( arr );
    return 0;
}

void testExp_Parall() {}


/*
    a[i] = (-1)^i * ( i + 1 ) / i^3;
*/
void fillArray( double* arr, size_t len, int start ) {
    double i = 0;
    int sign = -1;

    assert( arr != NULL );
    assert( len > 0 );
    assert( start > 0 );

    if ( start % 2 )
	    sign = 1;
    for ( i = start; i <= len; ++arr, ++i ) {        
	    *arr = sign * ( i + 1 ) / i / i / i;      /* a[i + 1] = f( a[i] ) */
	    sign *= -1;
    }
}

double summArray( double* beg, double* end ) {
    double res = 0;

    assert( beg != NULL );
    assert( beg < end );

    for ( res = 0; beg != end; ++beg ) {
        res += *beg;
    }
    return res;
}
