#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <math.h>

int getStartPoint( int size, int rank, size_t arrLen, int* area );
void fillArray( double* arr, size_t len, int start );
double summArray( double* beg, double* end );

int main( int argc, char* argv[] ) {
    size_t n = 100000;
    int size = 0, rank = 0, err = 0, oldestProc = 0, i = 0;
    int start = 0, area = 0;
    double* arr = NULL;
    double* results = NULL;
    double* p = NULL;
    const char* fname = "result";
    double begtime = 0, endtime = 0, time = 0;    
    double summ = 0;
    FILE* resFile;
    MPI_Status status;

    /* MPI initialization */
    err = MPI_Init( &argc, &argv );
    assert( err == MPI_SUCCESS );
    begtime = MPI_Wtime();    

    /* get communicator info */
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    oldestProc = size - 1;

    /* initialization data to proccess */
    summ = 0;    
    start = getStartPoint( size, rank, n, &area );
    arr = (double *) malloc( sizeof(double) * area );
    fillArray( arr, n, start );

    /* calculating and managing results from different proccess*/
    area = n / size;
    if ( rank == oldestProc ) {
        results = ( double* )malloc( sizeof(double) * size );
        for ( i = 0, p = results; i < oldestProc; ++i, ++p) {            
            MPI_Recv( p, 1, MPI_DOUBLE, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,
                           &status );
        }
        for( i = 0; i < size; ++i ) {
            summ += results[i];
        }
    }
    else {
        summ = summArray( arr + area*rank, arr + area*( rank + 1 ) );
        MPI_Send( &summ, 1, MPI_DOUBLE, oldestProc, rank, MPI_COMM_WORLD );
    }
    endtime = MPI_Wtime();
    time = endtime - begtime;
    MPI_Finalize();

    /* print result */
    if ( rank == oldestProc ) {    
        resFile = fopen( fname, "w" );
        fprintf( resFile, "summ = %.10f\ntime", summ );
        fclose( resFile );
    }
    
    free( arr );
    return 0;
}

int getStartPoint( int size, int rank, size_t len, int* area ) {
    div_t temp = div( len, size );
    int baseArea = temp.quot;    
    int rem = temp.rem;
    int start = 0;
    
    *area = baseArea;
    if ( rank >= rem ) {
        start = ( baseArea + 1 )*rem + baseArea*( rank - rem );
        *area += 1;
    } else
        start = ( baseArea + 1 )*rank;
        
    return start;
}

/*
    a[i] = (-1)^i * ( i + 1 ) / i^3;
*/
void fillArray( double* arr, size_t len, int start ) {
    double i = 0;
    int sign = -1;

    assert( arr != NULL );
    assert( len > 0 );
    assert( start > 0 );

    if ( start % 2 )
	    sign = 1;
    for ( i = start; i <= len; ++arr, ++i ) {        
	    *arr = sign * ( i + 1 ) / i / i / i;      /* a[i + 1] = f( a[i] ) */
	    sign *= -1;
    }
}

double summArray( double* beg, double* end ) {
    double res = 0;

    assert( beg != NULL );
    assert( beg < end );

    for ( res = 0; beg != end; ++beg ) {
        res += *beg;
    }
    return res;
}