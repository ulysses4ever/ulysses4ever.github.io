#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <math.h>
#include "mpi.h"

void fillArray( double* arr, size_t len, double x );
double summArray( double* beg, double* end );

int main( int argc, char* argv[] ) {
    size_t n = 100000, area = 0;
    int size = 0, rank = 0, err = 0, oldestProc = 0, i = 0;
    double* arr = (double *) malloc( sizeof(double) * n );
    double* results = NULL;
    double* p = NULL;
    const char* fname = "result";
    FILE* f;
    MPI_Status status;

    /* initialization data to proccess */
    double x = 0;
    double summ = 0;
    fillArray( arr, n, x );

    /* MPI initialization */
    err = MPI_Init( &argc, &argv );
    assert( err == MPI_SUCCESS );

    /* get communicator info */
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    oldestProc = size - 1;

    /* calculating and managing results from different proccess*/
    area = n / size;
    if ( rank == oldestProc ) {
        results = ( double* )malloc( sizeof(double) * size );
        results[oldestProc] = summArray( arr + area*rank, arr + n );        
        for ( i = 0, p = results; i < oldestProc; ++i, ++p) {            
            MPI_Recv( p, 1, MPI_DOUBLE, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,
                           &status );
        }
        for( i = 0; i < size; ++i ) {
            summ += results[i];
        }
    }
    else {
        summ = summArray( arr + area*rank, arr + area*( rank + 1 ) );
        MPI_Send( &summ, 1, MPI_DOUBLE, oldestProc, rank, MPI_COMM_WORLD );
    }
    MPI_Finalize();

    /* print result */
    if ( rank == oldestProc ) {    
        // f = fopen( fname, "w" );
        /*f*/printf( /*f,*/ "exp( %f ) = %f", -x, summ );
        // fclose( f );
    }
    
    free( arr );
    return 0;
}

void testExp_Parall() {}


/* exp( -x ):
 	a[i] = ( ( -1 )^i * x^i ) / i!
*/
void fillArray( double* arr, size_t len, double x ) {
    size_t i = 1;

    assert( arr != NULL );
    assert( len > 0 );

    *arr = 1;
    for ( ; i < len; ++arr, ++i ) {
    	*(arr + 1) = (-1) * x * (*arr) / i; 		/* a[i + 1] = f( a[i] ) */
    }
}

double summArray( double* beg, double* end ) {
    double res = 0;

    assert( beg != NULL );
    assert( beg < end );

    for ( ; beg != end; ++beg ) {
        res += *beg;
    }
    return res;
}
