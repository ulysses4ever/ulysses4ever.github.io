#include <stdio.h>

double exp_( double );

int main() {

    double x = 4.5;
    double sum = exp_( x );
    printf("exp( -%f ) = %f\n", x, sum);
}

// exp( -x ):
// 	a[i] = ( ( -1 )^i * x^i ) / i! 
double exp_( double x ) {
    double eps = 0.0001;
    double a = 1;			// a[0]
    int i = 1;
    double sum = 1; 			// sum = a[0]
        
    while ( a > eps ) {
	a = (-1) * x * a / i; 		// a[i] = f( a[i-1] )
	sum += a;
	++i;
    }
    return sum;
}
