#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main( int argc, char** argv ) {
    int size = 0, rank = 0, err = 0;
   
    err = MPI_Init( &argc, &argv );
    assert( err == MPI_SUCCESS );
    
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );   
   
    printf( "Communicator size: %d, node rank: %d\n", size, rank );
       
    MPI_Finalize();
    system("pause");
}
