#include "date.h"

// return next month
Month inc(Month m)
{
    return (m == DEC) ? JAN : static_cast<Month> (m + 1);
}

// TODO: add implementation for dec and nextDate

// return previous month
Month dec(Month m)
{ 
    /* your implementation goes here... */ 
    return m;
}

// check if given year is leap
bool is_leap(int year)
{
    if (! (year % 400))
        return true;
    if (! (year % 100))
        return false;
    /* TODO: add one more if, 
             cf. http://en.wikipedia.org/wiki/Leap_year#Algorithm */
}

// set next date (account leap years)
void next_date(int & year, Month & month, Day & day)
{ 
    /* HINT: use inc, isLeap and switch statement in your implementation */ 
}
