// first: standard library headers:
#include <cassert>

// then: project headers:
#include "date.h"

int main()
{
    assert(JAN == inc(DEC));
    /* TODO: add one more assert for inc */

    assert(JAN == dec(FEB));
    /* TODO: add one more assert for dec */
    
    assert(is_leap(2000));
    assert(!is_leap(1900));
    /* TODO: add two more asserts for isLeap */
    
    
    int y = 2012;
    Month m = FEB;
    Day d = 28;
    
    next_date(y, m, d);
    assert(y == 2012);
    assert(m == FEB);
    assert(d == 29);
    
    /* TODO: add three more asserts for nextDate */    
}
