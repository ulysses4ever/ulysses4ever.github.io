#ifndef DATE_H
#define DATE_H

// type for representing day in a month: [1, 31]
typedef int Day;

// type for representing a month: JAN for January, etc.
enum Month {JAN /* TODO: initialize JAN constant... */, FEB, MAR, /* TODO: ... */ DEC};

// return next month
Month inc(Month m);

// return previous month
Month dec(Month m);

// check if given year is leap
bool is_leap(int year);

// set next date (account leap years)
void next_date(int & year, Month & month, Day & day);

/* DATE_H: */
#endif 

