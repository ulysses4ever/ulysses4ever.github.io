
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "7.0.0"

#define NTL_MAJOR_VERSION  (7)
#define NTL_MINOR_VERSION  (0)
#define NTL_REVISION       (0)

#endif

