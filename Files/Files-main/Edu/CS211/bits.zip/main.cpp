
/*

    main function should call all implemented test functions from bitsTest.cpp

    You sould create and use header file for bitsTest.cpp in order to be able to call its functions here.

*/

int main() {
    // testBitAnd(); // TODO: uncomment when add header file with testBitAnd
    
    // TODO: add calls to other tests
    
}

