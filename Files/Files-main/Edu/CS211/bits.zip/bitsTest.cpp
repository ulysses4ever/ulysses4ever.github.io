#include <cassert>

#if 0

In order to get your points for tasks from bits.cpp you should add test code.
For each function f() in bits.cpp create a function testF() in this file.
E.g.: bitAnd -> testBitAnd.
Each test function should contain a number of assert calls.

You should convert examples from bits.c to assert and add at least three more 
your own asserts.

You sould create and use header file for bits.cpp in order to be able to
call its functions here.

#endif

void testBitAnd() {
    // assert(4 == bitAnd(6, 5)); // uncomment when add header file with bitAnd
    // TODO: add at least three more asserts
}

// TODO: add test function for each implemented function from bits.cpp

