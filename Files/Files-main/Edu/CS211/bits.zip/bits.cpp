#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C++ code that implements the function. Your code 
  must conform to the following style:
 
  int f(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >> -
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Use any other operations, such as &&, ||, or ?:
  5. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. 32-bit representations of integers.
  2. Performs right shifts arithmetically ( http://en.wikipedia.org/wiki/Arithmetic_shift ) 
  3. Has unpredictable behavior when shifting an integer by more
     than the word size (32 bits).

EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }


/*
 * STEP 2: Modify the following functions according the coding rules.
 */


#endif

/* 
 * bitAnd - x&y using only ~ and | 
 *   Example: bitAnd(6, 5) = 4
 *   Legal ops: ~ |
 *   Max ops: 8
 *   Hint: recall De Morgan's laws
 */
int bitAnd(int x, int y) {
    // TODO: your implementation goes here
}

/* 
 * nthBit - return n-th bit in x; bits indexed from 0
 *   Example: nthBit(4, 0) = 0, nthBit(4, 2) = 1
 *   Legal ops: >> &
 *   Max ops: 4
 */
int nthBit(int x, int n) {
    // TODO: your implementation goes here
}

/*******************************************************************
 * 
 * Rating: 1
 * 
 * Solutions for the previous tasks bring you 1 point if you:
 *      * create necessary headers,
 *      * add tests with asserts
 *      * run tests in main()
 * 
 * *****************************************************************/

/* 
 * setFirstNBits - returns a number with first (least significant) 
 *                 bits n set
 *   Example: setFirstNBits(3) = 7, setFirstNBits(0) = 0
 *   Legal ops: << -
 *   Max ops: 4
 *   Hint: 2^n - 1
 */
int setFirstNBits(int n) {
    // TODO: your implementation goes here
}

/* 
 * fromNtoMBits - returns a number composed from bits n to m; bits 
 *                indexed from 0
 *   Example: fromNtoMBits(4, 2, 4) = 1, fromNtoMBits(12, 2, 4) = 3
 *   Legal ops: >> & - setFirstNBits
 *   Max ops: 4
 */
int fromNtoMBits(int x, int n, int m) {
    // TODO: your implementation goes here
}

/* 
 * thirdBits - return an int with every third bit (starting from the  
               least significant bit, LSB) set to 1 and the rest set to 0,
               i.e. ...1001001001001;
 *   thirdBits() & 1 == 1, thirdBits() & 8 == 8, etc.
 *   Legal ops: ! ~ & ^ | + << >>; 
 *   Legal constants: 0 through 255 as usual
 *   Max ops: 8
 */
int thirdBits(void) {
    // TODO: your implementation goes here
}

/******************************************************************
 * 
 * Rating: 2  (solutions for the previous tasks bring you 2 points)
 * 
 * If you are really a brave one, you may proceed here and get
 * two more points for next four tasks.
 * 
 * Otherwise you should go back to Moodle task page and do second
 * task there.
 * 
 *****************************************************************/

/* 
 * bitXor - x^y using only ~ and & 
 *   Example: bitXor(4, 5) = 1
 *   Legal ops: ~ &
 *   Max ops: 10
 *   Hint: compare the result of (0 xor 1) with (~0 & 1), then (0 & ~1). 
            The idea is already emerged here. Just test it over other 
            combinations ((1 xor 0), (0 xor 0), etc.).
 */
int bitXor(int x, int y) {
    // TODO: your implementation goes here
}

/* 
 * fitsBits - return 1 if x can be represented as an 
 *  n-bit, two's complement integer.
 *   1 <= n <= 32
 *   Examples: fitsBits(5,3) = 0, fitsBits(-4,3) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 */
int fitsBits(int x, int n) {
    // TODO: your implementation goes here
}

/* 
 * sign - return 1 if positive, 0 if zero, and -1 if negative
 *  Examples: sign(130) = 1
 *            sign(-23) = -1
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 10
 */
int sign(int x) {
    // TODO: your implementation goes here
}
/* 
 * getByte - Extract byte n from word x
 *   Bytes numbered from 0 (LSB) to 3 (MSB)
 *   Examples: getByte(0x12345678,1) = 0x56
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 6
 */
int getByte(int x, int n) {
    // TODO: your implementation goes here
}

/* 
 * logicalShift - shift x to the right by n, using a logical shift
 *   Can assume that 0 <= n <= 31
 *   Examples: logicalShift(0x87654321,4) = 0x08765432
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 20
 */

int logicalShift(int x, int n) {
    // TODO: your implementation goes here
}
/* 
 * addOK - Determine if can compute x+y without overflow
 *   Example: addOK(0x80000000,0x80000000) = 0,
 *            addOK(0x80000000,0x70000000) = 1, 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 */
int addOK(int x, int y) {
    // TODO: your implementation goes here
}

/* 
 * bang - Compute !x without using !
 *   Examples: bang(3) = 0, bang(0) = 1
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 12
 */
int bang(int x) {
    // TODO: your implementation goes here
}

/* 
 * conditional - same as x ? y : z 
 *   Example: conditional(2,4,5) = 4
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 */
int conditional(int x, int y, int z) {
    // TODO: your implementation goes here
}

/*
 * isPower2 - returns 1 if x is a power of 2, and 0 otherwise
 *   Examples: isPower2(5) = 0, isPower2(8) = 1, isPower2(0) = 0
 *   Note that no negative number is a power of 2.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 */
int isPower2(int x) {
    // TODO: your implementation goes here
}

