#include "node.h"

int main() 
{
    /* dynamically allocate a node<int> */
    node<int> * n1 = new node<int> { nullptr  // prev
                                   , nullptr  // next
                                   , 41};     // data

    node<int> * n2;
    // TODO: insert initialization for n2 to get:
    // 41 -> 42 -> 43 -> |

    node<int> * n3 = new node<int> {n1, nullptr, 43};
    n1->next = n3;

    print_nodes(n1);     /* print list with two nodes; 
                            NOTE: template argument deduction (T=int) */
    
    purge_nodes(n1);     /* don't forget freeing manually allocated memory! */
    
}

