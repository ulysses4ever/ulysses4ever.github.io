#ifndef NODE_H
#define NODE_H

#include <iostream>
//  this include is due to usage of cout/endl inside the header

/* `node` for doubly-linked list of T's */
template<typename T>
struct node {
    node * prev; // NOTE: no explicit template parameter (<T>) needed
    node * next; 
    T data;
};

/* print list in forward and reverse orders */
template<typename T>
void print_nodes(node<T> * head)
{
    node<T> * last = head;
    while (head)
    {
        last = head;
        std::cout << head->data << " -> ";
        head = head->next;
    }
    std::cout << "|\n|";
    while (last)
    {
        std::cout << " <- " << last->data;
        last = last->prev;
    }    
    std::cout << std::endl;
}

/* free memory for all nodes in a list */
template<typename T>
void purge_nodes(node<T> * head)
{
    while (head)
    {
        node<T> * p = head->next;
        delete head;
        head = p;
    }
}

/* NODE_H */
#endif 

